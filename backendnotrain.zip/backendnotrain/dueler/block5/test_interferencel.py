
import numpy as np
import json
from ray.rllib.algorithms.ppo import PPO
from train_interference import Interference5BlocksEnv
import os

def test_interference_model(
    checkpoint_path="interference_5blocks_checkpoints/checkpoint_000400",
    data_path="block_world_interference_5blocks_100k.json",
    num_episodes=100
):
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    print("=" * 80)
    print("5-Block Interference Expert Model Test")
    print("=" * 80)
    print(f"\nModel path: {checkpoint_path}")
    print(f"Test episodes: {num_episodes}")
    print("\nLoading model...")
    
    if not os.path.isabs(checkpoint_path):
        checkpoint_path = os.path.join(script_dir, checkpoint_path)
    checkpoint_path = os.path.abspath(checkpoint_path)
    if not os.path.exists(checkpoint_path):
        print(f"[ERROR] Checkpoint not found: {checkpoint_path}")
        return
    
    if not os.path.isabs(data_path):
        data_path = os.path.join(script_dir, data_path)
    
    env_config = {
        "max_steps": 200,
        "grid_size": 20,
        "data_path": data_path,
        "reward_prevent_player": 100.0,
        "reward_ai_complete": 80.0,
        "reward_player_complete": -150.0,
        "reward_interference_timing": 50.0,  
        "reward_wrong_timing": -30.0,  
        "reward_effective_interference": 15.0,  
        "reward_progress_ai": 5.0,
        "reward_step": -0.1
    }
    
    try:
        algo = PPO.from_checkpoint(checkpoint_path)
        print("✓ Model loaded successfully\n")
    except Exception as e:
        print(f"[ERROR] Model loading failed: {e}")
        return
    
    env = Interference5BlocksEnv(env_config)
    
    rl_module = algo.get_module()
    
    total_reward = 0
    total_steps = 0
    player_wins = 0
    ai_wins = 0
    timeouts = 0
    
    interference_counts = []
    player_progresses = []
    episode_lengths = []
    episode_rewards = []
    
    interference_when_progress_3 = 0
    interference_when_progress_4 = 0
    interference_when_progress_other = 0
    
    detailed_logs = []
    
    print("Starting test...")
    print("-" * 80)
    
    for episode in range(num_episodes):
        obs, info = env.reset()
        episode_reward = 0
        episode_step = 0
        done = False
        
        episode_log = {
            "episode": episode + 1,
            "player_target": info["player_target"],
            "ai_target": info["ai_target"],
            "actions": [],
            "player_progresses": [],
            "interference_count": 0
        }
        
        while not done:
            
            import torch
            obs_batch = torch.from_numpy(obs).unsqueeze(0).float()  
            output = rl_module.forward_inference({"obs": obs_batch})
            
            if "actions" in output:
                action = output["actions"][0].item()
            elif "action_dist_inputs" in output:
                
                from ray.rllib.models.torch.torch_action_dist import TorchCategorical
                action_dist = TorchCategorical(output["action_dist_inputs"])
                action = action_dist.sample()[0].item()
            else:
                
                action = output["action_dist_inputs"].argmax(dim=-1)[0].item()
            
            if episode < 10:
                action_type = "No interference" if action == 0 else (
                    f"Interfere {chr(ord('A') + action - 1)}" if 1 <= action <= 5 else
                    f"Move {chr(ord('A') + action - 6)}"
                )
                episode_log["actions"].append({
                    "step": episode_step,
                    "action": int(action),
                    "action_type": action_type
                })
            
            obs, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated
            
            episode_reward += reward
            episode_step += 1
            
            if episode < 10:
                episode_log["player_progresses"].append(info.get("player_progress", 0))
            
            if 1 <= action <= 5:
                episode_log["interference_count"] += 1
                player_prog = info.get("player_progress", 0)
                if player_prog == 3:
                    interference_when_progress_3 += 1
                elif player_prog == 4:
                    interference_when_progress_4 += 1
                else:
                    interference_when_progress_other += 1
        
        total_reward += episode_reward
        total_steps += episode_step
        episode_rewards.append(episode_reward)
        episode_lengths.append(episode_step)
        interference_counts.append(info.get("interference_count", 0))
        player_progresses.append(info.get("player_progress", 0))
        
        if info.get("player_complete", False):
            player_wins += 1
            result = "Player wins"
        elif info.get("ai_complete", False):
            ai_wins += 1
            result = "AI wins"
        else:
            timeouts += 1
            result = "Timeout"
        
        episode_log["result"] = result
        episode_log["final_player_progress"] = info.get("player_progress", 0)
        episode_log["final_ai_progress"] = info.get("ai_progress", 0)
        episode_log["episode_reward"] = episode_reward
        episode_log["episode_steps"] = episode_step
        
        if episode < 10:
            detailed_logs.append(episode_log)
        
        if (episode + 1) % 10 == 0:
            print(f"Tested {episode + 1}/{num_episodes} episodes | "
                  f"Current avg reward: {np.mean(episode_rewards[-10:]):.2f}")
    
    avg_reward = total_reward / num_episodes
    avg_steps = total_steps / num_episodes
    avg_interference = np.mean(interference_counts)
    avg_player_progress = np.mean(player_progresses)
    
    print("\n" + "=" * 80)
    print("Test Results Summary")
    print("=" * 80)
    
    print(f"\nBasic Metrics:")
    print(f"  Average reward: {avg_reward:.2f}")
    print(f"  Average steps: {avg_steps:.1f}")
    print(f"  Average interference count: {avg_interference:.1f}")
    print(f"  Average player final progress: {avg_player_progress:.2f}/5")
    
    print(f"\nWin/Loss Statistics:")
    print(f"  AI successfully prevented player: {ai_wins + timeouts}/{num_episodes} ({(ai_wins + timeouts)/num_episodes*100:.1f}%)")
    print(f"    - AI completed goal: {ai_wins}/{num_episodes} ({ai_wins/num_episodes*100:.1f}%)")
    print(f"    - Prevented by timeout: {timeouts}/{num_episodes} ({timeouts/num_episodes*100:.1f}%)")
    print(f"  Player completed goal: {player_wins}/{num_episodes} ({player_wins/num_episodes*100:.1f}%)")
    
    print(f"\nInterference Timing Analysis:")
    total_interferences = interference_when_progress_3 + interference_when_progress_4 + interference_when_progress_other
    if total_interferences > 0:
        print(f"  Interference when player progress=3: {interference_when_progress_3}/{total_interferences} "
              f"({interference_when_progress_3/total_interferences*100:.1f}%)")
        print(f"  Interference when player progress=4: {interference_when_progress_4}/{total_interferences} "
              f"({interference_when_progress_4/total_interferences*100:.1f}%)")
        print(f"  Interference at other times: {interference_when_progress_other}/{total_interferences} "
              f"({interference_when_progress_other/total_interferences*100:.1f}%)")
        
        correct_timing = interference_when_progress_3 + interference_when_progress_4
        print(f"  Correct timing interference rate: {correct_timing/total_interferences*100:.1f}%")
    
    print("\n" + "=" * 80)
    print("Detailed Records of First 10 Episodes")
    print("=" * 80)
    
    for log in detailed_logs[:5]:  
        print(f"\nEpisode {log['episode']}:")
        print(f"  Player target: {log['player_target']} | AI target: {log['ai_target']}")
        print(f"  Result: {log['result']} | Reward: {log['episode_reward']:.1f} | Steps: {log['episode_steps']}")
        print(f"  Interference count: {log['interference_count']}")
        print(f"  Final progress - Player: {log['final_player_progress']:.1f}/5 | AI: {log['final_ai_progress']:.1f}/5")
        
        key_actions = [a for a in log['actions'] if a['action'] != 0][:5]
        if key_actions:
            print(f"  Key actions: ", end="")
            for a in key_actions:
                print(f"[Step{a['step']}: {a['action_type']}] ", end="")
            print()
    
    print("\n" + "=" * 80)
    print("Performance Evaluation")
    print("=" * 80)
    
    success_rate = (ai_wins + timeouts) / num_episodes
    
    if success_rate >= 0.9:
        grade = "Excellent ⭐⭐⭐"
        comment = "Model performs excellently, can effectively prevent player from completing goal"
    elif success_rate >= 0.7:
        grade = "Good ⭐⭐"
        comment = "Model performance is good, can successfully interfere in most cases"
    elif success_rate >= 0.5:
        grade = "Pass ⭐"
        comment = "Model is basically usable, but still needs improvement"
    else:
        grade = "Fail"
        comment = "Model performance is insufficient, recommend continuing training or adjusting parameters"
    
    print(f"\nOverall Rating: {grade}")
    print(f"Comment: {comment}")
    
    if total_interferences > 0:
        correct_timing_rate = (interference_when_progress_3 + interference_when_progress_4) / total_interferences
        if correct_timing_rate >= 0.7:
            print("Interference timing: Good ✓")
        elif correct_timing_rate >= 0.5:
            print("Interference timing: Average")
        else:
            print("Interference timing: Needs improvement")
    
    if ai_wins / num_episodes >= 0.5:
        print("AI completion ability: Strong ✓")
    elif ai_wins / num_episodes >= 0.3:
        print("AI completion ability: Medium")
    else:
        print("AI completion ability: Weak")
    
    print("\n" + "=" * 80)
    
    results = {
        "checkpoint": checkpoint_path,
        "num_episodes": num_episodes,
        "avg_reward": float(avg_reward),
        "avg_steps": float(avg_steps),
        "success_rate": float(success_rate),
        "ai_wins": ai_wins,
        "player_wins": player_wins,
        "timeouts": timeouts,
        "detailed_logs": detailed_logs
    }
    
    output_file = os.path.join(script_dir, "test_results_interference_5blocks.json")
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    print(f"\nDetailed results saved to: {output_file}")
    
    algo.stop()
    return results

if __name__ == "__main__":
    import sys
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    data_file = os.path.join(script_dir, "block_world_interference_5blocks_100k.json")
    if not os.path.exists(data_file):
        print(f"[ERROR] Data file not found: {data_file}")
        sys.exit(1)
    
    checkpoint = os.path.join(script_dir, "interference_5blocks_checkpoints/checkpoint_000400")
    
    if len(sys.argv) > 1:
        checkpoint = sys.argv[1]
    
    print(f"\nPreparing to test model: {checkpoint}\n")
    
    test_interference_model(
        checkpoint_path=checkpoint,
        data_path=data_file,
        num_episodes=100
    )
