import json
import random
import os
from typing import List, Dict, Tuple
from itertools import permutations

NUM_BLOCKS = 5  
TARGET_BLOCKS = ["A", "B", "C", "D", "E"]  

TARGET_PERMUTATIONS = ["".join(p) for p in permutations(TARGET_BLOCKS)]
NUM_SAMPLES = 100000  
BOARD_SIZE = 20  

INTERFERENCE_MIN_PROGRESS = 3  
INTERFERENCE_MAX_PROGRESS = 4  
INTERFERENCE_WINDOW = 20  
MIN_STEPS_BEFORE_INTERFERENCE = 5  
MAX_STEPS_BEFORE_INTERFERENCE = 15  

def is_position_valid(block_pos: Dict, all_blocks: List[Dict]) -> bool:
    
    for b in all_blocks:
        if b["block"] == block_pos["block"]:
            continue
        if b["x"] == block_pos["x"] and b["y"] == block_pos["y"] and b["z"] == block_pos["z"]:
            return False
    
    if block_pos["z"] > 0:
        has_support = False
        for b in all_blocks:
            if b["x"] == block_pos["x"] and b["y"] == block_pos["y"] and b["z"] == block_pos["z"] - 1:
                has_support = True
                break
        if not has_support:
            return False
    return True

def is_block_movable(block_id: str, blocks: List[Dict]) -> bool:
    
    target_block = next(b for b in blocks if b["block"] == block_id)
    for b in blocks:
        if b["x"] == target_block["x"] and b["y"] == target_block["y"] and b["z"] == target_block["z"] + 1:
            return False
    return True

def select_target_permutation() -> str:
    
    return random.choice(TARGET_PERMUTATIONS)

def generate_initial_positions() -> List[Dict]:
    
    positions = []
    used_coords = set()
    for block in TARGET_BLOCKS:
        
        while True:
            x = random.randint(1, BOARD_SIZE)
            y = random.randint(1, BOARD_SIZE)
            if (x, y) not in used_coords:
                used_coords.add((x, y))
                break
        positions.append({
            "block": block,
            "x": x,
            "y": y,
            "z": 0
        })
    return positions

def get_progress_towards_target(blocks: List[Dict], target_perm: str) -> int:
    
    pos_map = {b["block"]: b for b in blocks if b["block"] in TARGET_BLOCKS}
    if len(pos_map) != 5:
        return 0
    
    for i in range(5):
        expected_z = i
        expected_block = target_perm[4 - i]  
        
        if pos_map[expected_block]["z"] != expected_z:
            return i  
        
        if i > 0:
            base_x = pos_map[target_perm[4]]["x"]  
            base_y = pos_map[target_perm[4]]["y"]  
            if pos_map[expected_block]["x"] != base_x or pos_map[expected_block]["y"] != base_y:
                return i
    
    return 5  

def is_target_achieved(blocks: List[Dict], target_perm: str) -> bool:
    
    return get_progress_towards_target(blocks, target_perm) == 5

def move_block(blocks: List[Dict], block_id: str, target_x: int, target_y: int, target_z: int) -> List[Dict]:
    
    new_blocks = []
    for b in blocks:
        if b["block"] == block_id:
            new_block = {
                "block": block_id,
                "x": target_x,
                "y": target_y,
                "z": target_z
            }
            new_blocks.append(new_block)
        else:
            new_blocks.append(b.copy())
    return new_blocks

def generate_player_progress_steps(
    initial_blocks: List[Dict], 
    player_target: str,
    target_progress: int
) -> Tuple[List[List[Dict]], int]:
    
    steps = [initial_blocks.copy()]
    current_blocks = initial_blocks.copy()
    
    target_base_x = random.randint(1, BOARD_SIZE)
    target_base_y = random.randint(1, BOARD_SIZE)
    
    blocks_to_stack = []
    for i in range(target_progress):
        blocks_to_stack.append((player_target[4 - i], i))  
    
    num_steps = random.randint(MIN_STEPS_BEFORE_INTERFERENCE, MAX_STEPS_BEFORE_INTERFERENCE)
    steps_per_block = max(1, num_steps // target_progress)
    
    for block_id, target_z in blocks_to_stack:
        
        for _ in range(steps_per_block):
            if len(steps) >= num_steps:
                break
            
            if is_block_movable(block_id, current_blocks):
                
                current_blocks = move_block(current_blocks, block_id, target_base_x, target_base_y, target_z)
                steps.append(current_blocks.copy())
                
                current_progress = get_progress_towards_target(current_blocks, player_target)
                if current_progress >= target_progress:
                    return steps, current_progress
        
        if len(steps) >= num_steps:
            break
    
    final_progress = get_progress_towards_target(current_blocks, player_target)
    return steps, final_progress

def generate_ai_interference_steps(
    blocks_after_player: List[Dict],
    player_target: str,
    ai_target: str
) -> List[List[Dict]]:
    
    steps = []
    current_blocks = blocks_after_player.copy()
    
    player_progress = get_progress_towards_target(current_blocks, player_target)
    if player_progress >= 3:
        
        top_block_id = player_target[4 - player_progress + 1]  
        if is_block_movable(top_block_id, current_blocks):
            
            new_x = random.randint(1, BOARD_SIZE)
            new_y = random.randint(1, BOARD_SIZE)
            current_blocks = move_block(current_blocks, top_block_id, new_x, new_y, 0)
            steps.append(current_blocks.copy())
    
    ai_base_x = random.randint(1, BOARD_SIZE)
    ai_base_y = random.randint(1, BOARD_SIZE)
    
    for i in range(5):
        block_id = ai_target[4 - i]  
        target_z = i
        
        if is_block_movable(block_id, current_blocks):
            current_blocks = move_block(current_blocks, block_id, ai_base_x, ai_base_y, target_z)
            steps.append(current_blocks.copy())
            
            if is_target_achieved(current_blocks, ai_target):
                return steps
    
    return steps

def generate_game_data_with_interference(num_samples: int) -> List[Dict]:
    
    game_data = []
    valid_count = 0
    total_attempts = 0
    
    while valid_count < num_samples:
        total_attempts += 1
        try:
            
            initial_blocks = generate_initial_positions()
            
            player_target = select_target_permutation()
            ai_target = select_target_permutation()
            
            while ai_target == player_target:
                ai_target = select_target_permutation()
            
            player_target_progress = random.randint(INTERFERENCE_MIN_PROGRESS, INTERFERENCE_MAX_PROGRESS)
            
            player_steps, actual_progress = generate_player_progress_steps(
                initial_blocks, 
                player_target,
                player_target_progress
            )
            
            if actual_progress < INTERFERENCE_MIN_PROGRESS or actual_progress > INTERFERENCE_MAX_PROGRESS:
                continue
            
            ai_steps = generate_ai_interference_steps(
                player_steps[-1],
                player_target,
                ai_target
            )
            
            final_state = ai_steps[-1] if ai_steps else player_steps[-1]
            player_completed = is_target_achieved(final_state, player_target)
            ai_completed = is_target_achieved(final_state, ai_target)
            
            if player_completed or not ai_completed:
                continue  
            
            all_steps = player_steps + ai_steps
            
            valid = True
            for step in all_steps:
                for b in step:
                    if not (1 <= b["x"] <= BOARD_SIZE and 1 <= b["y"] <= BOARD_SIZE):
                        valid = False
                        break
                    if not is_position_valid(b, step):
                        valid = False
                        break
                if not valid:
                    break
            
            if not valid:
                continue
            
            game_record = {
                "id": valid_count + 1,
                "num_blocks": NUM_BLOCKS,
                "player_target": player_target,
                "ai_target": ai_target,
                "player_progress_before_interference": actual_progress,
                "interference_step": len(player_steps),  
                "total_steps": len(all_steps),
                "player_steps": len(player_steps),
                "ai_steps": len(ai_steps),
                "initial_positions": initial_blocks,
                "steps": all_steps,
                "player_completed": player_completed,
                "ai_completed": ai_completed,
                "board_size": f"{BOARD_SIZE}×{BOARD_SIZE}"
            }
            game_data.append(game_record)
            valid_count += 1
            
            if valid_count % 1000 == 0:
                print(f" {valid_count}/{num_samples}  {total_attempts})")
        
        except Exception as e:
            
            continue
    
 
    return game_data

if __name__ == "__main__":

    
    game_data = generate_game_data_with_interference(NUM_SAMPLES)
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_file = os.path.join(script_dir, "block_world_interference_5blocks_100k.json")
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(game_data, f, indent=2, ensure_ascii=False)

    
    progress_dist = {3: 0, 4: 0}
    for record in game_data:
        progress = record["player_progress_before_interference"]
        if progress in progress_dist:
            progress_dist[progress] += 1
    

    for progress, count in progress_dist.items():
        print(f"  {progress}：{count} ({count/NUM_SAMPLES*100:.2f}%)")
    
    total_steps_list = [r["total_steps"] for r in game_data]
    player_steps_list = [r["player_steps"] for r in game_data]
    ai_steps_list = [r["ai_steps"] for r in game_data]
    

    
    player_win_count = sum(1 for r in game_data if r["player_completed"])
    ai_win_count = sum(1 for r in game_data if r["ai_completed"])

    
    player_targets = set(r["player_target"] for r in game_data)
    ai_targets = set(r["ai_target"] for r in game_data)
    

