﻿import numpy as np

class HeuristicBlockAgent:
    
    def __init__(self, num_blocks=5, target_blocks=None):
        self.num_blocks = num_blocks
        self.grid_size = 20   
        self.max_height = 10  
        
        if target_blocks:
            self.block_names = list(target_blocks)
        else:
            self.block_names = [chr(ord('A') + i) for i in range(num_blocks)]
    
    def _calculate_distance(self, pos1, pos2):
        
        return abs(pos1['x'] - pos2['x']) + abs(pos1['y'] - pos2['y']) + abs(pos1['z'] - pos2['z'])
    
    def _is_position_occupied(self, x, y, z, positions, exclude_block=None):
        
        for pos in positions:
            if exclude_block and pos['block'] == exclude_block:
                continue
            if round(pos['x']) == round(x) and round(pos['y']) == round(y) and round(pos['z']) == round(z):
                return True, pos['block']
        return False, None
    
    def _is_block_pressed(self, block_name, positions):
        
        block_pos = None
        for pos in positions:
            if pos['block'] == block_name:
                block_pos = pos
                break
        
        if not block_pos:
            return False
        
        above_z = block_pos['z'] + 1
        occupied, _ = self._is_position_occupied(
            block_pos['x'], block_pos['y'], above_z, positions, exclude_block=block_name
        )
        return occupied
    
    def _has_support(self, x, y, z, positions, exclude_block=None):
        
        if z == 0:
            return True  
        
        below_z = z - 1
        occupied, _ = self._is_position_occupied(x, y, below_z, positions, exclude_block)
        return occupied
    
    def _find_clear_position(self, current_positions, avoid_x, avoid_y):
        
        for x in range(self.grid_size):
            for y in range(self.grid_size):
                if x == avoid_x and y == avoid_y:
                    continue
                occupied, _ = self._is_position_occupied(x, y, 0, current_positions)
                if not occupied:
                    return x, y, 0
        return 0, 0, 0
    
    def _can_move_to(self, block_name, new_x, new_y, new_z, current_positions, check_support=True):
        
        occupied, occupier = self._is_position_occupied(
            new_x, new_y, new_z, current_positions, exclude_block=block_name
        )
        if occupied:
            return False, f""
        
        if check_support and not self._has_support(new_x, new_y, new_z, current_positions, exclude_block=block_name):
            return False, ""
        
        return True, "OK"
    
    def _move_block_to_position(self, block_name, target_pos, current_positions, goal_positions):
        
        actions = []
        current_pos = None
        current_idx = None
        
        for i, pos in enumerate(current_positions):
            if pos['block'] == block_name:
                current_pos = pos.copy()
                current_idx = i
                break
        
        if not current_pos:
            return actions
        
        if self._is_block_pressed(block_name, current_positions):
            
            return actions
        
        safe_height = max(5, target_pos['z'] + 2)  
        
        while current_pos['z'] < safe_height:
            new_z = current_pos['z'] + 1
            if new_z >= self.max_height:
                break
            can_move, reason = self._can_move_to(
                block_name, current_pos['x'], current_pos['y'], new_z, current_positions,
                check_support=False  
            )
            if can_move:
                actions.append((block_name, 0, 0, 1))
                current_pos['z'] = new_z
                current_positions[current_idx] = current_pos.copy()
            else:
                
                break
        
        steps_x = int(target_pos['x'] - current_pos['x'])
        dx = 1 if steps_x > 0 else -1 if steps_x < 0 else 0
        for _ in range(abs(steps_x)):
            new_x = current_pos['x'] + dx
            can_move, reason = self._can_move_to(
                block_name, new_x, current_pos['y'], current_pos['z'], current_positions,
                check_support=False  
            )
            if can_move:
                actions.append((block_name, dx, 0, 0))
                current_pos['x'] = new_x
                current_positions[current_idx] = current_pos.copy()
            else:
                
                break
        
        steps_y = int(target_pos['y'] - current_pos['y'])
        dy = 1 if steps_y > 0 else -1 if steps_y < 0 else 0
        for _ in range(abs(steps_y)):
            new_y = current_pos['y'] + dy
            can_move, reason = self._can_move_to(
                block_name, current_pos['x'], new_y, current_pos['z'], current_positions,
                check_support=False  
            )
            if can_move:
                actions.append((block_name, 0, dy, 0))
                current_pos['y'] = new_y
                current_positions[current_idx] = current_pos.copy()
            else:
                
                break
        
        final_z = target_pos['z']
        for test_z in range(target_pos['z'], current_pos['z']):
            
            occupied, _ = self._is_position_occupied(
                current_pos['x'], current_pos['y'], test_z, current_positions, block_name
            )
            if occupied:
                continue  
            
            if test_z == 0 or self._has_support(
                current_pos['x'], current_pos['y'], test_z, current_positions, block_name
            ):
                final_z = test_z
                break  
        
        steps_down = current_pos['z'] - final_z
        if steps_down > 0:
            
            for _ in range(steps_down):
                actions.append((block_name, 0, 0, -1))
            current_pos['z'] = final_z
            current_positions[current_idx] = current_pos.copy()
        
        return actions
    
    def _free_pressed_blocks(self, current_positions, all_actions):
        
        freed_blocks = []
        
        pressed_blocks = set()
        for pos in current_positions:
            block_name = pos['block']
            if pos['z'] > 0 and self._is_block_pressed(block_name, current_positions):
                pressed_blocks.add(block_name)
        
        if not pressed_blocks:
            return freed_blocks
        
        for block_name in list(pressed_blocks):
            if block_name not in freed_blocks:
                self._free_block_recursively(block_name, current_positions, all_actions, freed_blocks)
        
        return freed_blocks
    
    def _free_block_recursively(self, block_name, current_positions, all_actions, freed_blocks):
        
        if block_name in freed_blocks:
            return
        
        block_pos = None
        for pos in current_positions:
            if pos['block'] == block_name:
                block_pos = pos
                break
        
        if not block_pos:
            return
        
        blocks_above = []
        for pos in current_positions:
            other_name = pos['block']
            if other_name != block_name:
                if (pos['x'] == block_pos['x'] and 
                    pos['y'] == block_pos['y'] and 
                    pos['z'] > block_pos['z']):
                    blocks_above.append((pos['z'], other_name))
        
        blocks_above.sort(reverse=True)
        for _, upper_block in blocks_above:
            self._free_block_recursively(upper_block, current_positions, all_actions, freed_blocks)
        
        clear_x, clear_y, _ = self._find_clear_position(current_positions, -999, -999)
        target_pos = {'block': block_name, 'x': clear_x, 'y': clear_y, 'z': 0}
        
        move_actions = self._move_block_to_position(
            block_name, target_pos, current_positions, None
        )
        all_actions.extend(move_actions)
        
        for i, pos in enumerate(current_positions):
            if pos['block'] == block_name:
                current_positions[i] = target_pos.copy()
                break
        
        freed_blocks.append(block_name)
    
    def plan(self, initial_positions, goal_positions):
        
        current_positions = [pos.copy() for pos in initial_positions]
        all_actions = []
        
        goal_blocks = [g['block'] for g in goal_positions]
        
        for goal_block in goal_blocks:
            if self._is_block_pressed(goal_block, current_positions):
                
                freed = self._free_pressed_blocks(current_positions, all_actions)
                break  
        
        blocks_by_goal_height = sorted(
            [(goal_positions[i]['z'], goal_blocks[i], i) for i in range(len(goal_positions))]
        )
        
        for goal_z, block_name, block_idx in blocks_by_goal_height:
            target_pos = goal_positions[block_idx]
            
            current_block_idx = None
            current_block_pos = None
            for i, pos in enumerate(current_positions):
                if pos['block'] == block_name:
                    current_block_idx = i
                    current_block_pos = pos
                    break
            
            if current_block_pos is None:
                
                continue
            
            occupied, occupier = self._is_position_occupied(
                target_pos['x'], target_pos['y'], target_pos['z'],
                current_positions, exclude_block=block_name
            )
            
            if occupied:
                
                if self._is_block_pressed(occupier, current_positions):
                    
                    freed = self._free_pressed_blocks(current_positions, all_actions)
                    
                temp_x, temp_y, temp_z = self._find_clear_position(
                    current_positions, target_pos['x'], target_pos['y']
                )
                temp_pos = {'block': occupier, 'x': temp_x, 'y': temp_y, 'z': temp_z}
                
                for i, pos in enumerate(current_positions):
                    if pos['block'] == occupier:
                        move_actions = self._move_block_to_position(
                            occupier, temp_pos, current_positions, goal_positions
                        )
                        all_actions.extend(move_actions)
                        current_positions[i] = temp_pos.copy()
                        
                        break
            
            move_actions = self._move_block_to_position(
                block_name, target_pos, current_positions, goal_positions
            )
            all_actions.extend(move_actions)
            
            current_positions[current_block_idx] = target_pos.copy()
            
        return all_actions

def parse_target_string(target_str, num_blocks, target_x=10, target_y=10):
    
    goal_positions = []
    
    for index_in_str, block_name in enumerate(target_str):
        
        z_index = len(target_str) - 1 - index_in_str
        
        goal_positions.append({
            "block": block_name,
            "x": target_x,
            "y": target_y,
            "z": z_index
        })
    
    return goal_positions

def heuristic_agent(current_positions, target, num_blocks):
    
    goal_positions = parse_target_string(target, num_blocks)
    
    agent = HeuristicBlockAgent(num_blocks=num_blocks, target_blocks=list(target))
    
    actions = agent.plan(current_positions, goal_positions)
    
    def is_valid_state(positions):
        
        for p in positions:
            if p['z'] == 0:
                continue  
            
            has_support = False
            for other in positions:
                if other['block'] != p['block']:
                    
                    if (other['x'] == p['x'] and 
                        other['y'] == p['y'] and 
                        other['z'] == p['z'] - 1):
                        has_support = True
                        break
            
            if not has_support:
                return False  
        
        return True
    
    steps = []
    current = [p.copy() for p in current_positions]
    
    if is_valid_state(current):
        initial_snapshot = [
            {
                "block": p['block'],
                "x": int(p['x']),
                "y": int(p['y']),
                "z": int(p['z'])
            }
            for p in current
        ]
        steps.append(initial_snapshot)
    
    for block_name, dx, dy, dz in actions:
        
        for p in current:
            if p['block'] == block_name:
                p['x'] += dx
                p['y'] += dy
                p['z'] += dz
                break
        
        if is_valid_state(current):
            step_snapshot = [
                {
                    "block": p['block'],
                    "x": int(p['x']),
                    "y": int(p['y']),
                    "z": int(p['z'])
                }
                for p in current
            ]
            steps.append(step_snapshot)
    
    return steps

if __name__ == "__main__":
    
    
    agent = HeuristicBlockAgent(num_blocks=5)
    
    initial = [
        {"block": "A", "x": 8, "y": 7, "z": 1},
        {"block": "B", "x": 8, "y": 7, "z": 0},
        {"block": "C", "x": 8, "y": 7, "z": 2},
        {"block": "D", "x": 8, "y": 7, "z": 3},
        {"block": "E", "x": 8, "y": 7, "z": 4},
    ]
    
    goal = [
        {"block": "A", "x": 10, "y": 10, "z": 0},
        {"block": "B", "x": 10, "y": 10, "z": 2},
        {"block": "C", "x": 10, "y": 10, "z": 1},
        {"block": "D", "x": 10, "y": 10, "z": 3},
        {"block": "E", "x": 10, "y": 10, "z": 4},
    ]
    

    for p in initial: print(f"  {p['block']}: ({p['x']},{p['y']},{p['z']})")

    for p in goal: print(f"  {p['block']}: ({p['x']},{p['y']},{p['z']})")
    print()
    
    actions = agent.plan(initial, goal)
    

    

    current = [p.copy() for p in initial]
    step_count = 0
    current_block = None
    
    for name, dx, dy, dz in actions:
        
        if current_block != name:
            if current_block is not None:
         
                for p in current:
                    print(f"{p['block']}({p['x']:.0f},{p['y']:.0f},{p['z']:.0f}) ", end="")
                print()
            current_block = name
        
        for p in current:
            if p['block'] == name:
                p['x'] += dx
                p['y'] += dy
                p['z'] += dz
                break
        step_count += 1
    
    if current_block:
      
        for p in current:
            print(f"{p['block']}({p['x']:.0f},{p['y']:.0f},{p['z']:.0f}) ", end="")
        print()
    

    for i, p in enumerate(current):
        g = goal[i]
        d = agent._calculate_distance(p, g)
        s = "✓" if d < 0.5 else "✗"
        print(f"{s} {p['block']}: ({p['x']:.0f},{p['y']:.0f},{p['z']:.0f}) vs ({g['x']},{g['y']},{g['z']}) {d:.0f}")
    
    print("\n" + "=" * 60)

    print("=" * 60)
    
    current_positions = [
        {"block": "A", "x": 2, "y": 3, "z": 0},
        {"block": "B", "x": 8, "y": 7, "z": 0},
        {"block": "C", "x": 5, "y": 5, "z": 0},
        {"block": "D", "x": 3, "y": 4, "z": 0},
        {"block": "E", "x": 6, "y": 6, "z": 0},
    ]
    
    target_string = "EDCBA"  
    num_blocks = 5
    

    print()
    
    steps = heuristic_agent(current_positions, target_string, num_blocks)
    

    
    for i in [0, 1, 2]:
        if i < len(steps):

            for block_pos in steps[i]:
                print(f"  {block_pos}")
    
    if len(steps) > 6:
        print(f"\n... ({len(steps)-6}) ...\n")
    
    for i in range(max(3, len(steps)-3), len(steps)):
        if i >= 0:

            for block_pos in steps[i]:
                print(f"  {block_pos}")
    

    final_step = steps[-1] if steps else current_positions
    for p in final_step:
        print(f"  {p['block']}: ({p['x']},{p['y']},{p['z']})")
    
    expected_goal = parse_target_string(target_string, num_blocks)

    for g in expected_goal:
        print(f"  {g['block']}: ({g['x']},{g['y']},{g['z']})")
    
 
    for final_pos in final_step:
        
        expected = next((g for g in expected_goal if g['block'] == final_pos['block']), None)
        if expected:
            dx = abs(final_pos['x'] - expected['x'])
            dy = abs(final_pos['y'] - expected['y'])
            dz = abs(final_pos['z'] - expected['z'])
            d = dx + dy + dz
            s = "✓" if d < 0.5 else "✗"
            print(f"{s} {final_pos['block']}: ({final_pos['x']},{final_pos['y']},{final_pos['z']}) vs ({expected['x']},{expected['y']},{expected['z']}) {d}")