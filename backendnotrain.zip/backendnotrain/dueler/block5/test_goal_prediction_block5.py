
import json
import os
import random
import copy
from test_goal_prediction import GoalPredictor
from collections import Counter

script_dir = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(script_dir, "block_world_data_no_interference_30k_abcde_30perms.json")

with open(data_path, 'r') as f:
    data = json.load(f)

print("="*70)

print("="*70)

print()

model_path = os.path.join(script_dir, 'goal_prediction_best.pth')
predictor = GoalPredictor(model_path)
print()

TRAINED_TARGETS = [
    "ABCDE", "EDCBA", "ABCED", "ABDCE", "ABCDE", "ACDBE",
    "ACBDE", "ABDEC", "BACDE", "BACED", "BDECA", "CBAED",
    "CBADE", "CDABE", "DABCE", "DBACE", "EABCD", "EBACD",
    "ECABD", "EDABC", "DEABC", "AEBCD", "ABECD", "ACEBD",
    "ADEBC", "AEDBC", "BCDAE", "BDEAC", "CDAEB", "DCABE"
]

UNSEEN_TARGETS = [
    "DEABC", "CDEAB", "BCDEA", "ACDEB", "BCDAE"
]

samples_by_target = {}
for sample in data:
    target = sample['target_permutation']
    if target not in samples_by_target:
        samples_by_target[target] = []
    samples_by_target[target].append(sample)


for target in TRAINED_TARGETS:
    count = len(samples_by_target.get(target, []))
    print(f"  {target}: {count} samples")
print()

def perturb_initial_state(steps, target_perm):
    
    if not steps:
        return steps
    
    new_steps = copy.deepcopy(steps)
    
    initial_state = new_steps[0]
    block_offsets = {}
    
    for block_pos in initial_state:
        block = block_pos['block']
        
        offset_x = random.randint(-2, 2)
        offset_y = random.randint(-2, 2)
        block_offsets[block] = (offset_x, offset_y)
    
    for step in new_steps:
        for block_pos in step:
            block = block_pos['block']
            if block in block_offsets:
                offset_x, offset_y = block_offsets[block]
                block_pos['x'] = max(0, min(9, block_pos['x'] + offset_x))
                block_pos['y'] = max(0, min(9, block_pos['y'] + offset_y))
    
    return new_steps

def generate_unseen_sample(target_perm, base_sample):
    
    new_sample = copy.deepcopy(base_sample)
    
    new_sample['target_permutation'] = target_perm
    
    new_sample['steps'] = perturb_initial_state(new_sample['steps'], target_perm)
    
    return new_sample



memory_total = 0
memory_top1 = 0
memory_top3 = 0
memory_top5 = 0

for target in TRAINED_TARGETS:
    if target not in samples_by_target:
        print(f"⚠️  {target}: No samples found, skipping")
        continue
    
    samples = samples_by_target[target]
    test_samples = random.sample(samples, min(3, len(samples)))
    
    target_top1 = 0
    target_top3 = 0
    target_top5 = 0
    
    for sample in test_samples:
        
        history = sample['steps'][:-1]
        
        predictions = predictor.predict(history, top_k=5)
        
        for i, pred in enumerate(predictions):
            if pred['goal'] == target:
                if i == 0:
                    target_top1 += 1
                if i < 3:
                    target_top3 += 1
                if i < 5:
                    target_top5 += 1
                break
        
        memory_total += 1
    
    memory_top1 += target_top1
    memory_top3 += target_top3
    memory_top5 += target_top5
    
    symbol = "✓" if target_top1 == len(test_samples) else ("~" if target_top1 > 0 else "✗")
    print(f"{symbol} {target}: Top-1={target_top1}/{len(test_samples)}, "
          f"Top-3={target_top3}/{len(test_samples)}, "
          f"Top-5={target_top5}/{len(test_samples)}")

print()

print(f"  Top-1: {memory_top1}/{memory_total} = {memory_top1/memory_total*100:.1f}%")
print(f"  Top-3: {memory_top3}/{memory_total} = {memory_top3/memory_total*100:.1f}%")
print(f"  Top-5: {memory_top5}/{memory_total} = {memory_top5/memory_total*100:.1f}%")

print()
print("="*70)

print("="*70)

gen_same_total = 0
gen_same_top1 = 0
gen_same_top3 = 0
gen_same_top5 = 0

for target in TRAINED_TARGETS[:10]:  
    if target not in samples_by_target:
        continue
    
    samples = samples_by_target[target]
    base_sample = random.choice(samples)
    
    target_top1 = 0
    target_top3 = 0
    target_top5 = 0
    
    for _ in range(3):
        perturbed_steps = perturb_initial_state(base_sample['steps'][:-1], target)
        
        predictions = predictor.predict(perturbed_steps, top_k=5)
        
        for i, pred in enumerate(predictions):
            if pred['goal'] == target:
                if i == 0:
                    target_top1 += 1
                if i < 3:
                    target_top3 += 1
                if i < 5:
                    target_top5 += 1
                break
        
        gen_same_total += 1
    
    gen_same_top1 += target_top1
    gen_same_top3 += target_top3
    gen_same_top5 += target_top5
    
    symbol = "✓" if target_top1 == 3 else ("~" if target_top1 > 0 else "✗")
    print(f"{symbol} {target}: Top-1={target_top1}/3, Top-3={target_top3}/3, Top-5={target_top5}/3")

print()

print(f"  Top-1: {gen_same_top1}/{gen_same_total} = {gen_same_top1/gen_same_total*100:.1f}%")
print(f"  Top-3: {gen_same_top3}/{gen_same_total} = {gen_same_top3/gen_same_total*100:.1f}%")
print(f"  Top-5: {gen_same_top5}/{gen_same_total} = {gen_same_top5/gen_same_total*100:.1f}%")

print()
print("="*70)

print("="*70)

gen_new_total = 0
gen_new_top1 = 0
gen_new_top3 = 0
gen_new_top5 = 0

for new_target in UNSEEN_TARGETS:
    
    base_sample = random.choice(data)
    
    target_top1 = 0
    target_top3 = 0
    target_top5 = 0
    
    for _ in range(3):
        new_sample = generate_unseen_sample(new_target, base_sample)
        history = new_sample['steps'][:-1]
        
        predictions = predictor.predict(history, top_k=5)
        
        for i, pred in enumerate(predictions):
            if pred['goal'] == new_target:
                if i == 0:
                    target_top1 += 1
                if i < 3:
                    target_top3 += 1
                if i < 5:
                    target_top5 += 1
                break
        
        gen_new_total += 1
    
    gen_new_top1 += target_top1
    gen_new_top3 += target_top3
    gen_new_top5 += target_top5
    
    symbol = "✓" if target_top1 > 0 else "✗"
    print(f"{symbol} {new_target} new: Top-1={target_top1}/3, Top-3={target_top3}/3, Top-5={target_top5}/3")
    
    if target_top1 == 0:
        sample_preds = predictor.predict(new_sample['steps'][:-1], top_k=3)
        pred_str = ", ".join([f"{p['goal']}({p['confidence']:.1f}%)" for p in sample_preds])
        print(f"    : {pred_str}")

print()

if gen_new_total > 0:
    print(f"  Top-1: {gen_new_top1}/{gen_new_total} = {gen_new_top1/gen_new_total*100:.1f}%")
    print(f"  Top-3: {gen_new_top3}/{gen_new_total} = {gen_new_top3/gen_new_total*100:.1f}%")
    print(f"  Top-5: {gen_new_top5}/{gen_new_total} = {gen_new_top5/gen_new_total*100:.1f}%")

print()
print("="*70)

print("="*70)

print(f"   Top-1: {memory_top1}/{memory_total} = {memory_top1/memory_total*100:.1f}%")
print()

print(f"   Top-1: {gen_same_top1}/{gen_same_total} = {gen_same_top1/gen_same_total*100:.1f}%")
print()

if gen_new_total > 0:
    print(f"   Top-1: {gen_new_top1}/{gen_new_total} = {gen_new_top1/gen_new_total*100:.1f}%")
else:
    print(f"   Top-1: N/A (no unseen samples tested)")
print("="*70)

