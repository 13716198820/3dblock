
import torch
import torch.nn as nn

from .train_goal_prediction import GoalPredictionModel

class GoalPredictor:
    
    def __init__(self, model_path='goal_prediction_best.pth', device='cpu'):
        
        self.device = device
        
        checkpoint = torch.load(model_path, map_location=device)
        
        self.idx_to_perm = checkpoint['idx_to_perm']
        
        self.perm_to_idx = checkpoint['perm_to_idx']
        
        num_classes = len(self.idx_to_perm)  
        
        self.model = GoalPredictionModel(
            max_blocks=15,
            hidden_dim=256,
            num_heads=8,
            num_layers=4,
            num_classes=num_classes
        ).to(device)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        
        self.model.eval()
    
    def predict(self, history, top_k=3):
        
        positions, mask = self._prepare_input(history)
        
        with torch.no_grad():
            
            logits = self.model(positions, mask)
            
            probabilities = torch.softmax(logits, dim=1)[0]
            
            top_k = min(top_k, len(probabilities))
            top_probs, top_indices = torch.topk(probabilities, k=top_k)
            
            results = []
            for prob, idx in zip(top_probs, top_indices):
                results.append({
                    'goal': self.idx_to_perm[idx.item()],     
                    'confidence': prob.item() * 100           
                })
        
        return results
    
    def _prepare_input(self, history, max_blocks=15, max_steps=50):
        
        num_steps = min(len(history), max_steps)
        
        positions = torch.zeros(1, max_steps, max_blocks, 3)
        mask = torch.zeros(1, max_steps, dtype=torch.bool)
        
        for step_idx, step_positions in enumerate(history[:num_steps]):
            mask[0, step_idx] = True  
            
            sorted_blocks = sorted(step_positions, key=lambda x: x['block'])
            
            for block_idx, block_pos in enumerate(sorted_blocks[:max_blocks]):
                
                positions[0, step_idx, block_idx] = torch.tensor([
                    (block_pos['x'] - 1) / 19.0,  
                    (block_pos['y'] - 1) / 19.0,  
                    block_pos['z'] / 4.0           
                ], dtype=torch.float32)
        
        return positions.to(self.device), mask.to(self.device)

def test_example():
    
    print("="*60)

    print("="*60)
    
    predictor = GoalPredictor('goal_prediction_best.pth')
    

    print("-"*60)
    
    history1 = [
        
        [
            {'block': 'A', 'x': 2, 'y': 3, 'z': 0},
            {'block': 'B', 'x': 8, 'y': 7, 'z': 0},
            {'block': 'C', 'x': 5, 'y': 5, 'z': 0},
            {'block': 'D', 'x': 12, 'y': 4, 'z': 0},
            {'block': 'E', 'x': 15, 'y': 8, 'z': 0}
        ],
        
        [
            {'block': 'A', 'x': 2, 'y': 3, 'z': 0},
            {'block': 'B', 'x': 8, 'y': 7, 'z': 0},
            {'block': 'C', 'x': 5, 'y': 5, 'z': 0},
            {'block': 'D', 'x': 12, 'y': 4, 'z': 0},
            {'block': 'E', 'x': 10, 'y': 10, 'z': 0}
        ],
        
        [
            {'block': 'A', 'x': 2, 'y': 3, 'z': 0},
            {'block': 'B', 'x': 8, 'y': 7, 'z': 0},
            {'block': 'C', 'x': 5, 'y': 5, 'z': 0},
            {'block': 'D', 'x': 10, 'y': 10, 'z': 1},
            {'block': 'E', 'x': 10, 'y': 10, 'z': 0}
        ],
        
        [
            {'block': 'A', 'x': 2, 'y': 3, 'z': 0},
            {'block': 'B', 'x': 8, 'y': 7, 'z': 0},
            {'block': 'C', 'x': 10, 'y': 10, 'z': 2},
            {'block': 'D', 'x': 10, 'y': 10, 'z': 1},
            {'block': 'E', 'x': 10, 'y': 10, 'z': 0}
        ]
    ]
    

    for i, step in enumerate(history1):
        print(f"  {i}: {step}")
    
    predictions1 = predictor.predict(history1, top_k=3)
    

    for i, pred in enumerate(predictions1, 1):
        print(f"  {i}. {pred['goal']} (: {pred['confidence']:.2f}%)")
    

    print("-"*60)
    
    history2 = [
        
        [
            {'block': 'A', 'x': 1, 'y': 1, 'z': 0},
            {'block': 'B', 'x': 5, 'y': 5, 'z': 0},
            {'block': 'C', 'x': 9, 'y': 9, 'z': 0},
            {'block': 'D', 'x': 13, 'y': 13, 'z': 0},
            {'block': 'E', 'x': 17, 'y': 17, 'z': 0}
        ],
        
        [
            {'block': 'A', 'x': 1, 'y': 1, 'z': 0},
            {'block': 'B', 'x': 5, 'y': 5, 'z': 0},
            {'block': 'C', 'x': 9, 'y': 9, 'z': 0},
            {'block': 'D', 'x': 13, 'y': 13, 'z': 0},
            {'block': 'E', 'x': 15, 'y': 15, 'z': 0}
        ],
        
        [
            {'block': 'A', 'x': 1, 'y': 1, 'z': 0},
            {'block': 'B', 'x': 5, 'y': 5, 'z': 0},
            {'block': 'C', 'x': 9, 'y': 9, 'z': 0},
            {'block': 'D', 'x': 15, 'y': 15, 'z': 1},
            {'block': 'E', 'x': 15, 'y': 15, 'z': 0}
        ],
        
        [
            {'block': 'A', 'x': 1, 'y': 1, 'z': 0},
            {'block': 'B', 'x': 5, 'y': 5, 'z': 0},
            {'block': 'C', 'x': 15, 'y': 15, 'z': 2},
            {'block': 'D', 'x': 15, 'y': 15, 'z': 1},
            {'block': 'E', 'x': 15, 'y': 15, 'z': 0}
        ]
    ]
    

    for i, step in enumerate(history2):
        print(f"  {i}: {step}")
    
    predictions2 = predictor.predict(history2, top_k=3)
    

    for i, pred in enumerate(predictions2, 1):
        print(f"  {i}. {pred['goal']} (: {pred['confidence']:.2f}%)")
    

    print("-"*60)
    
    history3 = [
        
        [
            {'block': 'A', 'x': 1, 'y': 1, 'z': 0},
            {'block': 'B', 'x': 3, 'y': 3, 'z': 0},
            {'block': 'C', 'x': 5, 'y': 5, 'z': 0},
            {'block': 'D', 'x': 7, 'y': 7, 'z': 0},
            {'block': 'E', 'x': 9, 'y': 9, 'z': 0},
            {'block': 'F', 'x': 11, 'y': 11, 'z': 0},
            {'block': 'G', 'x': 13, 'y': 13, 'z': 0}
        ],
        
        [
            {'block': 'A', 'x': 1, 'y': 1, 'z': 0},
            {'block': 'B', 'x': 3, 'y': 3, 'z': 0},
            {'block': 'C', 'x': 5, 'y': 5, 'z': 0},
            {'block': 'D', 'x': 7, 'y': 7, 'z': 0},
            {'block': 'E', 'x': 9, 'y': 9, 'z': 0},
            {'block': 'F', 'x': 2, 'y': 2, 'z': 0},
            {'block': 'G', 'x': 13, 'y': 13, 'z': 0}
        ],
        
        [
            {'block': 'A', 'x': 18, 'y': 18, 'z': 0},
            {'block': 'B', 'x': 3, 'y': 3, 'z': 0},
            {'block': 'C', 'x': 5, 'y': 5, 'z': 0},
            {'block': 'D', 'x': 7, 'y': 7, 'z': 0},
            {'block': 'E', 'x': 9, 'y': 9, 'z': 0},
            {'block': 'F', 'x': 2, 'y': 2, 'z': 0},
            {'block': 'G', 'x': 13, 'y': 13, 'z': 0}
        ],
        
        [
            {'block': 'A', 'x': 18, 'y': 18, 'z': 0},
            {'block': 'B', 'x': 18, 'y': 18, 'z': 1},
            {'block': 'C', 'x': 5, 'y': 5, 'z': 0},
            {'block': 'D', 'x': 7, 'y': 7, 'z': 0},
            {'block': 'E', 'x': 9, 'y': 9, 'z': 0},
            {'block': 'F', 'x': 2, 'y': 2, 'z': 0},
            {'block': 'G', 'x': 13, 'y': 13, 'z': 0}
        ],
        
        [
            {'block': 'A', 'x': 18, 'y': 18, 'z': 0},
            {'block': 'B', 'x': 18, 'y': 18, 'z': 1},
            {'block': 'C', 'x': 18, 'y': 18, 'z': 2},
            {'block': 'D', 'x': 7, 'y': 7, 'z': 0},
            {'block': 'E', 'x': 9, 'y': 9, 'z': 0},
            {'block': 'F', 'x': 2, 'y': 2, 'z': 0},
            {'block': 'G', 'x': 13, 'y': 13, 'z': 0}
        ],
        
        [
            {'block': 'A', 'x': 18, 'y': 18, 'z': 0},
            {'block': 'B', 'x': 18, 'y': 18, 'z': 1},
            {'block': 'C', 'x': 18, 'y': 18, 'z': 2},
            {'block': 'D', 'x': 18, 'y': 18, 'z': 3},
            {'block': 'E', 'x': 9, 'y': 9, 'z': 0},
            {'block': 'F', 'x': 2, 'y': 2, 'z': 0},
            {'block': 'G', 'x': 13, 'y': 13, 'z': 0}
        ]
    ]
    

    for i, step in enumerate(history3):
        moved_blocks = [b['block'] for b in step if any(
            b['x'] != s['x'] or b['y'] != s['y'] or b['z'] != s['z'] 
            for s in history3[i-1] if i > 0 and b['block'] == s['block']
        )]
        if i == 0:
            print(f"  step {i}")
        else:
            print(f"  step{i}: move {moved_blocks}")
    
    predictions3 = predictor.predict(history3, top_k=3)
    

    for i, pred in enumerate(predictions3, 1):
        print(f"  {i}. {pred['goal']} (: {pred['confidence']:.2f}%)")
    
    print("\n" + "="*60)

if __name__ == "__main__":
    test_example()
