
import json
import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
from pathlib import Path
from tqdm import tqdm
import itertools

class BlockWorldDataset(Dataset):
    
    def __init__(self, json_file, max_blocks=15, max_steps=50):
        
        self.max_blocks = max_blocks
        self.max_steps = max_steps
        
        with open(json_file, 'r', encoding='utf-8') as f:
            self.data = json.load(f)
        
        all_perms = set()
        for game in self.data:
            all_perms.add(game['target_permutation'])
        
        all_perms = sorted(all_perms)  
        self.perm_to_idx = {perm: idx for idx, perm in enumerate(all_perms)}
        self.idx_to_perm = {idx: perm for idx, perm in enumerate(all_perms)}
        self.num_classes = len(all_perms)
        

    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        
        game = self.data[idx]
        
        target_perm = game['target_permutation']
        target_label = self.perm_to_idx[target_perm]
        
        steps = game['steps'][:-1]  
        
        if len(steps) == 0:
            steps = game['steps'][:1]  
        
        num_steps = min(len(steps), self.max_steps)
        
        positions = torch.zeros(self.max_steps, self.max_blocks, 3)
        mask = torch.zeros(self.max_steps, dtype=torch.bool)
        
        for step_idx, step_positions in enumerate(steps[:num_steps]):
            mask[step_idx] = True
            
            sorted_blocks = sorted(step_positions, key=lambda x: x['block'])
            
            for block_idx, block_pos in enumerate(sorted_blocks[:self.max_blocks]):
                
                positions[step_idx, block_idx] = torch.tensor([
                    (block_pos['x'] - 1) / 19.0,  
                    (block_pos['y'] - 1) / 19.0,  
                    block_pos['z'] / 6.0           
                ], dtype=torch.float32)
        
        return positions, mask, target_label

class GoalPredictionModel(nn.Module):
    
    def __init__(self, max_blocks=15, hidden_dim=256, num_heads=8, num_layers=4, num_classes=30):
        
        super().__init__()
        
        self.max_blocks = max_blocks
        self.hidden_dim = hidden_dim
        
        self.position_encoder = nn.Sequential(
            nn.Linear(3, 128),
            nn.ReLU(),
            nn.Linear(128, hidden_dim)
        )
        
        self.block_aggregator = nn.Sequential(
            nn.Linear(hidden_dim * max_blocks, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1)
        )
        
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=num_heads,
            dim_feedforward=hidden_dim * 4,
            dropout=0.1,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, num_classes)
        )
    
    def forward(self, positions, mask):
        
        batch_size, max_steps, max_blocks, _ = positions.shape
        
        positions_flat = positions.reshape(-1, 3)
        encoded = self.position_encoder(positions_flat)  
        
        encoded = encoded.reshape(batch_size, max_steps, max_blocks, self.hidden_dim)
        
        encoded_flat = encoded.reshape(batch_size, max_steps, -1)
        step_features = self.block_aggregator(encoded_flat)  
        
        padding_mask = ~mask
        transformer_out = self.transformer(step_features, src_key_padding_mask=padding_mask)
        
        last_valid_indices = mask.sum(dim=1) - 1  
        batch_indices = torch.arange(batch_size, device=positions.device)
        final_features = transformer_out[batch_indices, last_valid_indices]  
        
        logits = self.classifier(final_features)  
        
        return logits

def train_model(data_file='block_world_data_no_interference_100k_abcdefg_30perms.json', 
                epochs=50, 
                batch_size=32,
                learning_rate=1e-4,
                device='cuda' if torch.cuda.is_available() else 'cpu'):
    

    
    if not os.path.isabs(data_file):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        data_file = os.path.join(script_dir, data_file)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))
    
    dataset = BlockWorldDataset(data_file)
    
    train_size = int(0.9 * len(dataset))
    val_size = len(dataset) - train_size
    train_dataset, val_dataset = torch.utils.data.random_split(
        dataset, [train_size, val_size]
    )
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=0)
    

    
    model = GoalPredictionModel(
        max_blocks=15,
        hidden_dim=256,
        num_heads=8,
        num_layers=4,
        num_classes=dataset.num_classes
    ).to(device)
    
 
    
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=0.01)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    
    best_val_acc = 0.0
    
    for epoch in range(epochs):
        
        model.train()
        train_loss = 0.0
        train_correct = 0
        train_total = 0
        
        pbar = tqdm(train_loader, desc=f'Epoch {epoch+1}/{epochs} [train]')
        for positions, mask, targets in pbar:
            positions = positions.to(device)
            mask = mask.to(device)
            targets = targets.to(device)
            
            optimizer.zero_grad()
            logits = model(positions, mask)
            loss = criterion(logits, targets)
            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            train_loss += loss.item()
            predictions = torch.argmax(logits, dim=1)
            train_correct += (predictions == targets).sum().item()
            train_total += targets.size(0)
            
            pbar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'acc': f'{100*train_correct/train_total:.2f}%'
            })
        
        train_loss /= len(train_loader)
        train_acc = 100 * train_correct / train_total
        
        model.eval()
        val_loss = 0.0
        val_correct = 0
        val_total = 0
        
        with torch.no_grad():
            for positions, mask, targets in tqdm(val_loader, desc=f'Epoch {epoch+1}/{epochs} [vaild]'):
                positions = positions.to(device)
                mask = mask.to(device)
                targets = targets.to(device)
                
                logits = model(positions, mask)
                loss = criterion(logits, targets)
                
                val_loss += loss.item()
                predictions = torch.argmax(logits, dim=1)
                val_correct += (predictions == targets).sum().item()
                val_total += targets.size(0)
        
        val_loss /= len(val_loader)
        val_acc = 100 * val_correct / val_total
        
        scheduler.step()
        
        print(f'\nEpoch {epoch+1}/{epochs}:')

        
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            model_save_path = os.path.join(script_dir, 'goal_prediction_best.pth')
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_acc': val_acc,
                'perm_to_idx': dataset.perm_to_idx,
                'idx_to_perm': dataset.idx_to_perm
            }, model_save_path)

        
        print()
    

    return model

def test_model(model_path='goal_prediction_best.pth', 
               data_file='block_world_data_no_interference_100k_abcdefg_30perms.json',
               num_samples=10,
               device='cuda' if torch.cuda.is_available() else 'cpu'):
    
    if not os.path.isabs(data_file):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        data_file = os.path.join(script_dir, data_file)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))
    
    if not os.path.isabs(model_path):
        model_path = os.path.join(script_dir, model_path)
        
    dataset = BlockWorldDataset(data_file)
    
    checkpoint = torch.load(model_path, map_location=device)
    model = GoalPredictionModel(
        max_blocks=15,
        num_classes=dataset.num_classes
    ).to(device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    
    idx_to_perm = checkpoint['idx_to_perm']
    

    
    indices = np.random.choice(len(dataset), num_samples, replace=False)
    
    with torch.no_grad():
        for i, idx in enumerate(indices):
            positions, mask, target_label = dataset[idx]
            
            positions = positions.unsqueeze(0).to(device)
            mask = mask.unsqueeze(0).to(device)
            
            logits = model(positions, mask)
            pred_label = torch.argmax(logits, dim=1).item()
            
            game = dataset.data[idx]
            

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Train the object prediction model')
    parser.add_argument('--data', type=str, default='block_world_data_no_interference_100k_abcdefg_30perms.json',
                       help='Data file path')
    parser.add_argument('--epochs', type=int, default=100,
                       help='Training rounds (up from 50 to 100)')
    parser.add_argument('--batch-size', type=int, default=32,
                       help='Batch size')
    parser.add_argument('--lr', type=float, default=1e-4,
                       help='Learning rate')
    parser.add_argument('--test', action='store_true',
                       help='Test pattern')
    parser.add_argument('--model', type=str, default='goal_prediction_best.pth',
                       help='Model file path')
    
    args = parser.parse_args()
    
    if args.test:
        test_model(model_path=args.model, data_file=args.data)
    else:
        train_model(
            data_file=args.data,
            epochs=args.epochs,
            batch_size=args.batch_size,
            learning_rate=args.lr
        )
