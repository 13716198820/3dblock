
import numpy as np
import gymnasium as gym           
from gymnasium import spaces      
from ray.rllib.algorithms.ppo import PPOConfig  
from ray.rllib.env.env_context import EnvContext  
import json
import os
from typing import Dict, List, Tuple, Optional

class Interference6BlocksEnv(gym.Env):
    
    def __init__(self, config: EnvContext):
        super().__init__()
        
        self.num_blocks = 6  
        self.max_steps = config.get("max_steps", 200)   
        self.grid_size = config.get("grid_size", 20)    
        
        data_path = config.get("data_path", "block_world_interference_6blocks_100k.json")
        
        if not os.path.isabs(data_path):
            script_dir = os.path.dirname(os.path.abspath(__file__))
            data_path = os.path.join(script_dir, data_path)
        with open(data_path, 'r', encoding='utf-8') as f:
            self.game_data = json.load(f)
        
        print(f"[6 squares interference] loads {len(self.game_data)} training data ")
        
        self.block_names = ["A", "B", "C", "D", "E", "F"]
        
        state_dim = 18 + 18 + 12 + 12 + 1 + 1 + 1 + 1  
        
        self.observation_space = spaces.Box(
            low=-1, high=1,
            shape=(state_dim,),
            dtype=np.float32
        )
        
        self.action_space = spaces.Discrete(13)
        
        self.reward_prevent_player = config.get("reward_prevent_player", 100.0)      
        self.reward_ai_complete = config.get("reward_ai_complete", 80.0)             
        self.reward_player_complete = config.get("reward_player_complete", -150.0)   
        self.reward_interference_timing = config.get("reward_interference_timing", 50.0)  
        self.reward_wrong_timing = config.get("reward_wrong_timing", -30.0)          
        self.reward_effective_interference = config.get("reward_effective_interference", 15.0)  
        self.reward_progress_ai = config.get("reward_progress_ai", 5.0)             
        self.reward_step = config.get("reward_step", -0.1)                           
        
        self.current_game = None       
        self.player_positions = []     
        self.ai_positions = []         
        self.player_target = ""        
        self.ai_target = ""            
        self.total_steps = 0           
        self.interference_count = 0    
        self.game_step_index = 0       
    
    def reset(self, *, seed=None, options=None):
        
        super().reset(seed=seed)
        
        self.current_game = np.random.choice(self.game_data)
        
        initial_positions = self.current_game['initial_positions']
        self.player_positions = [p.copy() for p in initial_positions]  
        self.ai_positions = [p.copy() for p in initial_positions]      
        
        self.player_target = self.current_game['player_target']
        self.ai_target = self.current_game['ai_target']
        
        self.total_steps = 0           
        self.interference_count = 0    
        self.game_step_index = 1       
        self.last_player_progress = 0  
        self.last_ai_progress = 0      
        self.last_action = 0           
        
        obs = self._get_observation()
        info = {
            "player_target": self.player_target,
            "ai_target": self.ai_target,
            "player_progress_in_data": self.current_game['player_progress_before_interference']
        }
        
        return obs, info
    
    def step(self, action: int):
        
        self.total_steps += 1
        reward = self.reward_step  
        
        player_progress_before = self._get_player_progress(self.player_positions, self.player_target)
        ai_progress_before = self._get_player_progress(self.ai_positions, self.ai_target)
        
        is_interference = False   
        is_self_move = False      
        
        if 1 <= action <= 6:
            
            block_idx = action - 1          
            block_name = self.block_names[block_idx]
            success = self._interfere_player_block(block_name)
            
            if success:
                is_interference = True
                self.interference_count += 1
                
                if 4 <= player_progress_before <= 5:
                    
                    reward += self.reward_interference_timing  
                elif player_progress_before < 4:
                    
                    reward += self.reward_wrong_timing          
                else:
                    
                    reward += self.reward_wrong_timing * 0.5   
        
        elif 7 <= action <= 12:
            
            block_idx = action - 7          
            block_name = self.block_names[block_idx]
            self._move_ai_block_to_target(block_name)
            is_self_move = True
        
        self._simulate_player_move()
        
        player_progress_after = self._get_player_progress(self.player_positions, self.player_target)
        ai_progress_after = self._get_player_progress(self.ai_positions, self.ai_target)
        
        if is_interference:
            
            if player_progress_after < player_progress_before - 0.5:
                
                if 4 <= player_progress_before <= 5:
                    reward += self.reward_effective_interference        
                    
                    if player_progress_before >= 5 and player_progress_after < 4:
                        reward += self.reward_effective_interference * 1.5  
        
        if is_self_move:
            
            progress_gain = ai_progress_after - ai_progress_before
            if progress_gain > 0:
                reward += self.reward_progress_ai * progress_gain
        
        player_complete = self._check_goal_complete(self.player_positions, self.player_target)
        ai_complete = self._check_goal_complete(self.ai_positions, self.ai_target)
        
        terminated = False
        
        if player_complete:
            
            reward += self.reward_player_complete  
            terminated = True
        elif ai_complete:
            
            reward += self.reward_ai_complete       
            
            if not player_complete:
                reward += self.reward_prevent_player  
            terminated = True
        elif self.total_steps >= self.max_steps:
            
            if not player_complete:
                reward += self.reward_prevent_player * 0.5  
                reward += ai_progress_after * 10            
            terminated = True
        
        reward += (6 - player_progress_after) * 0.5   
        reward += ai_progress_after * 0.3              
        
        self.last_player_progress = player_progress_after
        self.last_ai_progress = ai_progress_after
        self.last_action = action
        
        obs = self._get_observation()
        info = {
            "player_complete": player_complete,
            "ai_complete": ai_complete,
            "player_progress": player_progress_after,
            "ai_progress": ai_progress_after,
            "interference_count": self.interference_count
        }
        
        return obs, reward, terminated, False, info
    
    def _simulate_player_move(self):
        
        steps = self.current_game['steps']
        player_steps = self.current_game['player_steps']
        
        if self.game_step_index < player_steps and self.game_step_index < len(steps):
            
            self.player_positions = [p.copy() for p in steps[self.game_step_index]]
            self.game_step_index += 1
        else:
            
            self._move_towards_target(self.player_positions, self.player_target)
    
    def _move_towards_target(self, positions: List[Dict], target: str):
        
        current_progress = self._get_player_progress(positions, target)
        
        if current_progress >= 6:
            return  
        
        next_block_index = current_progress  
        next_block_name = target[5 - next_block_index]  
        
        current_pos = next((p for p in positions if p['block'] == next_block_name), None)
        if not current_pos:
            return
        
        if next_block_index == 0:
            
            goal_x, goal_y, goal_z = 10, 10, 0
        else:
            
            base_block_name = target[5]  
            base_pos = next((p for p in positions if p['block'] == base_block_name), None)
            if not base_pos:
                return
            goal_x, goal_y, goal_z = base_pos['x'], base_pos['y'], next_block_index
        
        dx = abs(current_pos['x'] - goal_x)
        dy = abs(current_pos['y'] - goal_y)
        dz = abs(current_pos['z'] - goal_z)
        
        if dx > 0.5:
            current_pos['x'] += 1 if current_pos['x'] < goal_x else -1
        elif dy > 0.5:
            current_pos['y'] += 1 if current_pos['y'] < goal_y else -1
        elif dz > 0.5:
            current_pos['z'] += 1 if current_pos['z'] < goal_z else -1
    
    def _interfere_player_block(self, block_name: str) -> bool:
        
        block_idx = None
        for i, pos in enumerate(self.player_positions):
            if pos['block'] == block_name:
                block_idx = i
                break
        
        if block_idx is None:
            return False  
        
        player_goal = self._parse_target(self.player_target)
        target_pos = next((g for g in player_goal if g['block'] == block_name), None)
        
        if target_pos:
            
            new_x = self.grid_size - 1 - target_pos['x']
            new_y = self.grid_size - 1 - target_pos['y']
            new_z = 0
            
            self.player_positions[block_idx] = {
                "block": block_name,
                "x": max(1, min(self.grid_size, new_x)),
                "y": max(1, min(self.grid_size, new_y)),
                "z": new_z
            }
            return True  
        
        return False
    
    def _move_ai_block_to_target(self, block_name: str):
        
        block_idx = None
        for i, pos in enumerate(self.ai_positions):
            if pos['block'] == block_name:
                block_idx = i
                break
        
        if block_idx is None:
            return
        
        ai_goal = self._parse_target(self.ai_target)
        target_pos = next((g for g in ai_goal if g['block'] == block_name), None)
        
        if target_pos:
            pos = self.ai_positions[block_idx]
            
            dx = target_pos['x'] - pos['x']
            dy = target_pos['y'] - pos['y']
            dz = target_pos['z'] - pos['z']
            
            distance = (dx**2 + dy**2 + dz**2) ** 0.5
            if distance > 0.5:
                step_size = min(3.0, distance)  
                pos['x'] += dx / distance * step_size
                pos['y'] += dy / distance * step_size
                pos['z'] += dz / distance * step_size
    
    def _parse_target(self, target: str) -> List[Dict]:
        
        base_x = 10
        base_y = 10
        
        positions = []
        for i, block_char in enumerate(reversed(target)):  
            positions.append({
                "block": block_char,
                "x": base_x,
                "y": base_y,
                "z": i  
            })
        
        return positions
    
    def _get_player_progress(self, positions: List[Dict], target: str) -> int:
        
        pos_map = {p["block"]: p for p in positions}
        if len(pos_map) != 6:
            return 0  
        
        for i in range(6):
            expected_z = i
            expected_block = target[5 - i]  
            
            if expected_block not in pos_map:
                return i
            
            block_pos = pos_map[expected_block]
            
            if abs(block_pos["z"] - expected_z) > 0.5:
                return i  
            
            if i > 0:
                base_block = target[5]  
                base_pos = pos_map[base_block]
                if abs(block_pos["x"] - base_pos["x"]) > 0.5 or abs(block_pos["y"] - base_pos["y"]) > 0.5:
                    return i  
        
        return 6  
    
    def _check_goal_complete(self, positions: List[Dict], target: str) -> bool:
        
        return self._get_player_progress(positions, target) >= 6
    
    def _get_observation(self) -> np.ndarray:
        
        obs = []
        
        for pos in self.player_positions:
            obs.extend([
                pos['x'] / self.grid_size,   
                pos['y'] / self.grid_size,   
                pos['z'] / 10.0              
            ])
        
        for pos in self.ai_positions:
            obs.extend([
                pos['x'] / self.grid_size,
                pos['y'] / self.grid_size,
                pos['z'] / 10.0
            ])
        
        player_target_hash = self._target_to_embedding(self.player_target)
        obs.extend(player_target_hash)
        
        ai_target_hash = self._target_to_embedding(self.ai_target)
        obs.extend(ai_target_hash)
        
        player_progress = self._get_player_progress(self.player_positions, self.player_target)
        obs.append(player_progress / 6.0)
        
        obs.append(min(self.interference_count / 10.0, 1.0))
        
        obs.append(self.total_steps / self.max_steps)
        
        obs.append(self.last_action / 10.0)
        
        return np.array(obs, dtype=np.float32)
    
    def _target_to_embedding(self, target: str) -> List[float]:
        
        embedding = [0.0] * 12  
        for i, char in enumerate(target):
            if i < 12:
                
                embedding[i] = (ord(char) - ord('A')) / 26.0
        return embedding

def train_interference_6blocks(
    data_path="block_world_interference_6blocks_100k.json",
    num_iterations=1000,
    checkpoint_dir="interference_6blocks_checkpoints",
):
    
    print("=" * 80)
    print(" 6-square interferometer training ")
    print("=" * 80)
    print("\n training data: 100,000 real-life adversarial scenarios ")
    print(" Target permutations: 720 (ABCDEF full permutations) ")
    print("\n learning objective: ")
    print(" 1. identify player progress (stacked blocks) ")
    print(" 2. Intervene at the right time (after 4-5 squares) ")
    print(" 3. Effectively breaking player progress ")
    print(" 4. Complete the AI's own goals ")
    print("\n reward design: ")
    print(" Successfully blocked player: +100")
    print(" AI complete goal: +80")
    print(" Player finish: -150")
    print(" Correct time to intervene: +20")
    print(" Effective interference: +25")
    print(" AI progress: +5/step")
    print(f"\n iterations: {num_iterations}")
    print("=" * 80 + "\n")
    
    env_config = {
        "max_steps": 200,                    
        "grid_size": 20,                     
        "data_path": data_path,              
        "reward_prevent_player": 100.0,      
        "reward_ai_complete": 80.0,          
        "reward_player_complete": -150.0,    
        "reward_interference_timing": 50.0,  
        "reward_wrong_timing": -30.0,        
        "reward_effective_interference": 15.0,  
        "reward_progress_ai": 5.0,           
        "reward_step": -0.1                  
    }
    
    config = (
        PPOConfig()
        .environment(Interference6BlocksEnv, env_config=env_config)
        .framework("torch")                 
        .training(
            lr=0.0003,                      
            train_batch_size=8000,          
            minibatch_size=256,             
            num_epochs=15,                  
            gamma=0.99,                     
            lambda_=0.95,                   
            clip_param=0.2,                 
            entropy_coeff=0.01,             
        )
        .env_runners(
            num_env_runners=6,              
            num_envs_per_env_runner=1,
        )
        .resources(
            num_gpus=0,                     
        )
        .evaluation(
            evaluation_interval=20,         
            evaluation_duration=20,         
            evaluation_num_env_runners=1,
        )
    )
    
    if not os.path.isabs(checkpoint_dir):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        checkpoint_dir = os.path.join(script_dir, checkpoint_dir)
    
    algo = config.build()  
    
    best_reward = -float('inf')  
    
    for i in range(num_iterations):
        result = algo.train()  
        
        reward_mean = result.get("env_runners", {}).get("episode_return_mean", 
                      result.get("episode_reward_mean", 0))
        len_mean = result.get("env_runners", {}).get("episode_len_mean",
                   result.get("episode_len_mean", 0))
        
        print(f"\n iterations {i+1}/{num_iterations}")
        print(f" Average rewards: {reward_mean:.2f}")
        print(f" Average steps: {len_mean:.1f}")
        
        if (i + 1) % 50 == 0 or reward_mean > best_reward:
            checkpoint_path = os.path.abspath(os.path.join(checkpoint_dir, f"checkpoint_{i+1:06d}"))
            os.makedirs(checkpoint_path, exist_ok=True)
            algo.save_checkpoint(checkpoint_path)
            
            if reward_mean > best_reward:
                best_reward = reward_mean
                print(f" [best] new record! Saved to: {checkpoint_path}")
            else:
                print(f" [checkpoint] saved to: {checkpoint_path}")
        
        if (i + 1) % 100 == 0:
            print("\n" + "=" * 80)
            print(f" Training progress: {(i+1)/num_iterations*100:.1f}%")
            print(f" Current best reward: {best_reward:.2f}")
            print("=" * 80)
    
    print("\n training complete!" )
    print(f" best average reward: {best_reward:.2f}")
    
    final_checkpoint_path = os.path.abspath(os.path.join(f"{checkpoint_dir}_final", "checkpoint_final"))
    os.makedirs(final_checkpoint_path, exist_ok=True)
    algo.save_checkpoint(final_checkpoint_path)
    print(f"The final model is saved: {final_checkpoint_path}")
    
    algo.stop()  
    return algo

if __name__ == "__main__":
    import sys
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_file = os.path.join(script_dir, "block_world_interference_6blocks_100k.json")
    if not os.path.exists(data_file):
        print(f"[error] data file not found: {data_file}")
        print(" Please run makePlayHistory_interference.py to generate data first ")
        sys.exit(1)
    
    print(f"\n Start training the 6-square interferometer..." )
    train_interference_6blocks(
        data_path=data_file,
        num_iterations=1000  
    )
