
import json
import random
import os
from typing import List, Dict, Tuple

MIN_BLOCKS = 6   
MAX_BLOCKS = 15  
from itertools import permutations
TARGET_BLOCKS = ["A", "B", "C", "D", "E", "F"]  

TARGET_PERMUTATIONS = [
    "ABCDEF",  
    "FEDCBA",  
    "ABCDFE",  
    "ABCEDF",  
    "ABCFED",  
    "ABDCEF",  
    "ACBDEF",  
    "ABDEFC",  
    "BACDEF",  
    "BACEDF",  
    "BDEFCA",  
    "CBAEDF",  
    "CBADEF",  
    "CDABEF",  
    "DABCEF",  
    "DBFACE",  
    "EABCDF",  
    "EBACDF",  
    "ECABDF",  
    "EDABCF",  
    "DEABCF",  
    "FABCDE",  
    "FBACED",  
    "FCABDE",  
    "FDABCE",  
    "FEABCD",  
    "ABFCDE",  
    "ACFBDE",  
    "ADFBCE",  
    "AEFBCD"   
]
NUM_SAMPLES = 100000  
BOARD_SIZE = 20       
ALL_BLOCK_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"  

def is_position_valid(block_pos: Dict, all_blocks: List[Dict]) -> bool:
    
    for b in all_blocks:
        if b["block"] == block_pos["block"]:
            continue
        if b["x"] == block_pos["x"] and b["y"] == block_pos["y"] and b["z"] == block_pos["z"]:
            return False
    
    if block_pos["z"] > 0:
        has_support = False
        for b in all_blocks:
            if b["x"] == block_pos["x"] and b["y"] == block_pos["y"] and b["z"] == block_pos["z"] - 1:
                has_support = True
                break
        if not has_support:
            return False
    return True

def is_block_movable(block_id: str, blocks: List[Dict]) -> bool:
    
    target_block = next(b for b in blocks if b["block"] == block_id)
    for b in blocks:
        if b["x"] == target_block["x"] and b["y"] == target_block["y"] and b["z"] == target_block["z"] + 1:
            return False
    return True

def generate_random_block_list() -> List[str]:
    
    num_blocks = random.randint(MIN_BLOCKS, MAX_BLOCKS)
    
    block_list = ["A", "B", "C", "D", "E", "F"]
    
    if num_blocks > 6:
        extra_blocks = [c for c in ALL_BLOCK_CHARS if c not in block_list]  
        random.shuffle(extra_blocks)
        block_list += extra_blocks[:num_blocks - 6]
    return block_list

def select_target_permutation() -> str:
    
    return random.choice(TARGET_PERMUTATIONS)

def generate_initial_positions(block_list: List[str]) -> List[Dict]:
    
    positions = []
    used_coords = set()
    for block in block_list:
        
        while True:
            x = random.randint(1, BOARD_SIZE)
            y = random.randint(1, BOARD_SIZE)
            if (x, y) not in used_coords:
                used_coords.add((x, y))
                break
        positions.append({
            "block": block,
            "x": x,
            "y": y,
            "z": 0
        })
    return positions

def is_target_achieved(blocks: List[Dict], target_perm: str) -> bool:
    
    pos_map = {b["block"]: b for b in blocks if b["block"] in TARGET_BLOCKS}
    if len(pos_map) != 6:
        return False  

    first_x = pos_map[target_perm[0]]["x"]
    first_y = pos_map[target_perm[0]]["y"]
    for i in range(6):
        if pos_map[target_perm[i]]["x"] != first_x or pos_map[target_perm[i]]["y"] != first_y:
            return False  

    for i in range(6):
        expected_z = 5 - i  
        if pos_map[target_perm[i]]["z"] != expected_z:
            return False

    return True

def move_block(blocks: List[Dict], block_id: str, target_x: int, target_y: int, target_z: int) -> List[Dict]:
    
    new_blocks = []
    for b in blocks:
        if b["block"] == block_id:
            new_block = {
                "block": block_id,
                "x": target_x,
                "y": target_y,
                "z": target_z
            }
            new_blocks.append(new_block)
        else:
            new_blocks.append(b.copy())
    return new_blocks

def generate_steps_to_target(initial_blocks: List[Dict], target_perm: str) -> List[List[Dict]]:
    
    steps = [initial_blocks.copy()]   
    current_blocks = initial_blocks.copy()

    if is_target_achieved(current_blocks, target_perm):
        return steps

    non_target_blocks = [b["block"] for b in current_blocks if b["block"] not in TARGET_BLOCKS]

    target_base_x = random.randint(1, BOARD_SIZE)
    target_base_y = random.randint(1, BOARD_SIZE)

    def safe_move_non_target():
        
        if not non_target_blocks:
            return False  
        
        movable = [b for b in non_target_blocks if is_block_movable(b, current_blocks)]
        if not movable:
            return False
        selected = random.choice(movable)  
        
        for _ in range(50):
            tx = random.randint(1, BOARD_SIZE)
            ty = random.randint(1, BOARD_SIZE)
            temp = move_block(current_blocks, selected, tx, ty, 0)
            if all(is_position_valid(b, temp) for b in temp):
                return temp  
        return False

    num_initial_distractions = random.randint(1, 3)
    for _ in range(num_initial_distractions):
        result = safe_move_non_target()
        if result:
            current_blocks = result
            steps.append(current_blocks.copy())

    bottom_block = target_perm[5]  
    if random.random() < 0.3 and is_block_movable(bottom_block, current_blocks):
        
        fake_x = random.randint(1, BOARD_SIZE)
        fake_y = random.randint(1, BOARD_SIZE)
        if (fake_x != target_base_x or fake_y != target_base_y):
            current_blocks = move_block(current_blocks, bottom_block, fake_x, fake_y, 0)
            steps.append(current_blocks.copy())
    
    if is_block_movable(bottom_block, current_blocks):
        current_blocks = move_block(current_blocks, bottom_block, target_base_x, target_base_y, 0)
        steps.append(current_blocks.copy())
        if is_target_achieved(current_blocks, target_perm):
            return steps  

    if random.random() < 0.5:
        result = safe_move_non_target()
        if result:
            current_blocks = result
            steps.append(current_blocks.copy())

    second_block = target_perm[4]
    if random.random() < 0.2 and is_block_movable(second_block, current_blocks):
        
        fake_x = random.randint(1, BOARD_SIZE)
        fake_y = random.randint(1, BOARD_SIZE)
        if (fake_x != target_base_x or fake_y != target_base_y):
            current_blocks = move_block(current_blocks, second_block, fake_x, fake_y, 0)
            steps.append(current_blocks.copy())
    
    if is_block_movable(second_block, current_blocks):
        current_blocks = move_block(current_blocks, second_block, target_base_x, target_base_y, 1)
        steps.append(current_blocks.copy())
        if is_target_achieved(current_blocks, target_perm):
            return steps

    third_block = target_perm[3]
    if random.random() < 0.2 and is_block_movable(third_block, current_blocks):
        fake_x = random.randint(1, BOARD_SIZE)
        fake_y = random.randint(1, BOARD_SIZE)
        if (fake_x != target_base_x or fake_y != target_base_y):
            current_blocks = move_block(current_blocks, third_block, fake_x, fake_y, 0)
            steps.append(current_blocks.copy())
    
    if is_block_movable(third_block, current_blocks):
        current_blocks = move_block(current_blocks, third_block, target_base_x, target_base_y, 2)
        steps.append(current_blocks.copy())
        if is_target_achieved(current_blocks, target_perm):
            return steps

    num_mid_distractions = random.randint(0, 2)
    for _ in range(num_mid_distractions):
        result = safe_move_non_target()
        if result:
            current_blocks = result
            steps.append(current_blocks.copy())

    fourth_block = target_perm[2]
    if is_block_movable(fourth_block, current_blocks):
        current_blocks = move_block(current_blocks, fourth_block, target_base_x, target_base_y, 3)
        steps.append(current_blocks.copy())
        if is_target_achieved(current_blocks, target_perm):
            return steps

    fifth_block = target_perm[1]
    if is_block_movable(fifth_block, current_blocks):
        current_blocks = move_block(current_blocks, fifth_block, target_base_x, target_base_y, 4)
        steps.append(current_blocks.copy())
        if is_target_achieved(current_blocks, target_perm):
            return steps

    top_block = target_perm[0]
    if is_block_movable(top_block, current_blocks):
        current_blocks = move_block(current_blocks, top_block, target_base_x, target_base_y, 5)
        steps.append(current_blocks.copy())
        if is_target_achieved(current_blocks, target_perm):
            return steps

    if not is_target_achieved(current_blocks, target_perm):
        current_blocks = move_block(current_blocks, target_perm[5], target_base_x, target_base_y, 0)  
        current_blocks = move_block(current_blocks, target_perm[4], target_base_x, target_base_y, 1)
        current_blocks = move_block(current_blocks, target_perm[3], target_base_x, target_base_y, 2)
        current_blocks = move_block(current_blocks, target_perm[2], target_base_x, target_base_y, 3)
        current_blocks = move_block(current_blocks, target_perm[1], target_base_x, target_base_y, 4)
        current_blocks = move_block(current_blocks, target_perm[0], target_base_x, target_base_y, 5)  
        steps.append(current_blocks.copy())

    return steps

def generate_game_data(num_samples: int) -> List[Dict]:
    
    game_data = []
    valid_count = 0    
    total_attempts = 0  

    while valid_count < num_samples:
        total_attempts += 1
        try:
            
            block_list = generate_random_block_list()
            
            target_perm = select_target_permutation()
            
            initial_blocks = generate_initial_positions(block_list)
            
            steps = generate_steps_to_target(initial_blocks, target_perm)

            final_step = steps[-1]
            assert is_target_achieved(final_step, target_perm), "ABCDEF failed in the last step"
            
            for step in steps[:-1]:
                assert not is_target_achieved(step, target_perm), "ABCDEF is ahead of schedule"

            valid = True
            for step in steps:
                for b in step:
                    if not (1 <= b["x"] <= BOARD_SIZE and 1 <= b["y"] <= BOARD_SIZE):
                        
                        valid = False
                        break
                    if not is_position_valid(b, step):
                        
                        valid = False
                        break
                if not valid:
                    break

            if valid:
                
                game_record = {
                    "id": valid_count + 1,
                    "total_blocks": len(block_list),       
                    "target_blocks": TARGET_BLOCKS,        
                    "target_permutation": target_perm,     
                    "initial_positions": initial_blocks,   
                    "steps": steps,                        
                    "num_steps": len(steps),               
                    "board_size": f"{BOARD_SIZE}×{BOARD_SIZE}"
                }
                game_data.append(game_record)
                valid_count += 1

                if valid_count % 1000 == 0:
                    print(f" {valid_count}/{num_samples} valid records were generated ")

        except Exception as e:
            
            continue

    print(f"\n The data is generated! {total_attempts}, valid records: {valid_count}")
    return game_data

if __name__ == "__main__":
    print(f" Start generating {NUM_SAMPLES} Block World data ({len(TARGET_PERMUTATIONS)} for ABCDEF)..." )
    game_data = generate_game_data(NUM_SAMPLES)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_file = os.path.join(script_dir, "block_world_data_no_interference_30k_abcdef_30perms.json")
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(game_data, f, indent=2, ensure_ascii=False)

    block_count_dist = {i: 0 for i in range(MIN_BLOCKS, MAX_BLOCKS + 1)}
    for record in game_data:
        block_count_dist[record["total_blocks"]] += 1

    target_perm_count = {perm: 0 for perm in TARGET_PERMUTATIONS}
    for record in game_data:
        perm = record["target_permutation"]
        target_perm_count[perm] += 1

    print("\n=== statistics ===")
    print(f" Total valid records: {len(game_data)}")
    print("\ nInitial number of squares distribution: ")
    for cnt, num in block_count_dist.items():
        print(f" {cnt} squares (including ABCDEF) : {num} squares ")
    print("\nABCDEF target permutation distribution: ")
    for perm, cnt in target_perm_count.items():
        print(f" {perm} : {cnt} bar (share {cnt/NUM_SAMPLES * 100:.2f}%) ")
    print(f"\n data saved to: {output_file}")