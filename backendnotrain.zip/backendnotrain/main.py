
import random          
from flask import Flask, request, jsonify  
from flask_cors import CORS               
import uuid            
import numpy as np    
import os             
import string         
from collections import deque  

import torch          
from ray.rllib.algorithms.algorithm import Algorithm  

from dueler.block5.test_goal_prediction import GoalPredictor

from dueler.block5.heuristic_agent_Vs import heuristic_agent

from dueler.block6.test_goal_prediction import GoalPredictor as GoalPredictor6
from dueler.block6.heuristic_agent_Vs import heuristic_agent as heuristic_agent_6

from dueler.block7.test_goal_prediction import GoalPredictor as GoalPredictor7
from dueler.block7.heuristic_agent_Vs import heuristic_agent as heuristic_agent_7

BLOCK_HEIGHT = 1.0  

BLOCK_TO_INDEX = {char: i for i, char in enumerate(string.ascii_uppercase)}  
INDEX_TO_BLOCK = {i: char for i, char in enumerate(string.ascii_uppercase)}  

app = Flask(__name__)  
CORS(app)              

game_hall = []

dueler_games = {}  

vsai_games = {}  

_final_model = None       
_goal_predictor = None    

_final_model_6 = None
_goal_predictor_6 = None

_final_model_7 = None
_goal_predictor_7 = None

def load_models(blocksamount=5):
    
    global _final_model, _goal_predictor, _final_model_6, _goal_predictor_6, _final_model_7, _goal_predictor_7
    
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    if blocksamount == 7:
        
        if _final_model_7 is None:
            
            checkpoint_path = os.path.join(base_dir, "dueler", "block7", "interference_7blocks_checkpoints", "checkpoint_000400")
            try:
                from ray.rllib.algorithms.ppo import PPO
                
                algo = PPO.from_checkpoint(checkpoint_path)
                
                _final_model_7 = algo.get_module()
                print("[AI] Interference model loaded (7-block, checkpoint_000400)")
            except Exception as e:
                print(f"[AI] Interference model failed to load: {e}")
                import traceback
                traceback.print_exc()
                print("[AI] Using heuristic interference strategy")
                _final_model_7 = None
        
        if _goal_predictor_7 is None:
            try:
                
                model_path = os.path.join(base_dir, "dueler", "block7", "goal_prediction_best.pth")
                _goal_predictor_7 = GoalPredictor7(model_path, device='cpu')
                print("[AI] Goal predictor loaded (7-block)")
            except Exception as e:
                print(f"[AI] Goal predictor failed to load: {e}")
                _goal_predictor_7 = None
    elif blocksamount == 6:
        
        if _final_model_6 is None:
            checkpoint_path = os.path.join(base_dir, "dueler", "block6", "interference_6blocks_checkpoints", "checkpoint_000450")
            try:
                from ray.rllib.algorithms.ppo import PPO
                algo = PPO.from_checkpoint(checkpoint_path)
                _final_model_6 = algo.get_module()
                print("[AI] Interference model loaded (6-block, checkpoint_000450)")
            except Exception as e:
                print(f"[AI] Interference model failed to load: {e}")
                import traceback
                traceback.print_exc()
                print("[AI] Using heuristic interference strategy")
                _final_model_6 = None
        
        if _goal_predictor_6 is None:
            try:
                model_path = os.path.join(base_dir, "dueler", "block6", "goal_prediction_best.pth")
                _goal_predictor_6 = GoalPredictor6(model_path, device='cpu')
                print("[AI] Goal predictor loaded (6-block)")
            except Exception as e:
                print(f"[AI] Goal predictor failed to load: {e}")
                _goal_predictor_6 = None
    else:
        
        if _final_model is None:
            checkpoint_path = os.path.join(base_dir, "dueler", "checkpoints_interference_5blocks", "checkpoint_000171")
            
            try:
                from ray.rllib.algorithms.ppo import PPO
                
                algo = PPO.from_checkpoint(checkpoint_path)
                _final_model = algo.get_module()  
                print("[AI] Interference model loaded (5-block, checkpoint_000171)")
            except Exception as e:
                print(f"[AI] Interference model failed to load: {e}")
                import traceback
                traceback.print_exc()
                print("[AI] Using heuristic interference strategy")
                _final_model = None
        
        if _goal_predictor is None:
            try:
                model_path = os.path.join(base_dir, "dueler", "goal_prediction_best.pth")
                _goal_predictor = GoalPredictor(model_path, device='cpu')
                print("[AI] Goal predictor loaded")
            except Exception as e:
                print(f"[AI] Goal predictor failed to load: {e}")
                _goal_predictor = None

def get_vs_dueler_next_move(game_id, current_positions, player_move_history, ai_target=None):
    
    if ai_target is None:
        
        target_game = dueler_games.get(game_id)

        if not target_game:
            target_game = vsai_games.get(game_id)

        if not target_game:
            return {
                'code': 404,
                'error': 'Game not found',
                'message': f'game_id {game_id} does not exist'
            }

        if 'target' in target_game:
            
            ai_target = target_game['target']
            blocksamount = target_game.get('blocksamount', 3)
            is_vsai_mode = False
        elif 'target_ai' in target_game:
            
            ai_target = target_game['target_ai']
            blocksamount = target_game.get('blocksamount', 3)
            is_vsai_mode = True
        else:
            return {
                'code': 400,
                'error': 'Invalid game configuration',
                'message': 'Unable to retrieve AI target'
            }
    else:
        
        blocksamount = len(ai_target) if ai_target else 3
        is_vsai_mode = False
        target_game = None

    load_models(blocksamount)

    predicted_target = None
    confidence = 0.0

    if blocksamount == 7:
        current_goal_predictor = _goal_predictor_7
    elif blocksamount == 6:
        current_goal_predictor = _goal_predictor_6
    else:
        current_goal_predictor = _goal_predictor

    if current_goal_predictor and player_move_history and len(player_move_history) > 0:
        try:
            
            predictions = current_goal_predictor.predict(player_move_history, top_k=1)
            if predictions and len(predictions) > 0:
                predicted_target = predictions[0].get('goal', None)
                confidence = predictions[0].get('confidence', 0.0) / 100.0  
                
                if predicted_target and len(predicted_target) != blocksamount:
                    print(f"[AI] Warning: predicted target '{predicted_target}' block count ({len(predicted_target)}) does not match game setting ({blocksamount})")
                    
                    if len(predicted_target) < blocksamount:
                        
                        all_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                        available = [c for c in all_letters[:blocksamount] if c not in predicted_target]
                        predicted_target += ''.join(available[:blocksamount - len(predicted_target)])
                    else:
                        
                        predicted_target = predicted_target[:blocksamount]
                    print(f"[AI] Adjusted predicted target: {predicted_target}")
                
                print(f"[AI] Predicted player target: {predicted_target} (confidence: {confidence * 100:.1f}%)")
        except Exception as e:
            print(f"[AI] Goal prediction failed: {e}")
    
    obs = []
    
    num_blocks = blocksamount if blocksamount in [5, 6, 7] else 5
    
    target_emb_dim = 14 if blocksamount == 7 else (12 if blocksamount == 6 else 10)  
    
    for i in range(num_blocks):
        if i < len(current_positions):
            pos = current_positions[i]
            obs.extend([
                pos['x'] / 20.0,  
                pos['y'] / 20.0,  
                pos['z'] / 10.0   
            ])
        else:
            obs.extend([0.0, 0.0, 0.0])  
    
    for i in range(num_blocks):
        if i < len(current_positions):
            pos = current_positions[i]
            obs.extend([
                pos['x'] / 20.0,
                pos['y'] / 20.0,
                pos['z'] / 10.0
            ])
        else:
            obs.extend([0.0, 0.0, 0.0])
    
    player_target_emb = [0.0] * target_emb_dim
    for i, char in enumerate(predicted_target[:target_emb_dim] if predicted_target else ""):
        player_target_emb[i] = (ord(char) - ord('A')) / 26.0
    obs.extend(player_target_emb)
    
    ai_target_emb = [0.0] * target_emb_dim
    for i, char in enumerate(ai_target[:target_emb_dim]):
        ai_target_emb[i] = (ord(char) - ord('A')) / 26.0
    obs.extend(ai_target_emb)
    
    player_progress_count = calculate_player_progress(current_positions, predicted_target) if predicted_target else 0
    player_progress = player_progress_count / float(num_blocks)
    obs.append(player_progress)
    
    obs.append(0.0)
    
    obs.append(0.5)
    
    obs.append(0.0)
    
    obs_array = np.array(obs, dtype=np.float32)
    
    ai_action = 0  
    
    if blocksamount == 7:
        current_model = _final_model_7
        expected_obs_dim = 74
        current_goal_predictor = _goal_predictor_7
    elif blocksamount == 6:
        current_model = _final_model_6
        expected_obs_dim = 64
        current_goal_predictor = _goal_predictor_6
    else:
        current_model = _final_model
        expected_obs_dim = 54
        current_goal_predictor = _goal_predictor
    
    print(f"[Debug] Block count: {blocksamount}")
    print(f"[Debug] Model state: {'loaded' if current_model else 'not loaded'} ({'6-block model' if blocksamount == 6 else '5-block model'})")
    print(f"[Debug] Observation dim: {len(obs_array)} (expected {expected_obs_dim})")
    print(f"[Debug] Predicted target: {predicted_target}")
    print(f"[Debug] Player progress: {player_progress_count}/{num_blocks} ({player_progress_count} blocks in correct position)")

    if current_model:
        
        try:
            
            obs_tensor = torch.from_numpy(obs_array).unsqueeze(0).float()
            
            batch = {"obs": obs_tensor}
            
            with torch.no_grad():
                
                output = current_model.forward_inference(batch)
                
                print(f"[Debug] Model output keys: {list(output.keys())}")
                print(f"[Debug] Model output: {output}")
                
                if not output or len(output) == 0:
                    print(f"[Debug] forward_inference returned empty, trying forward_exploration...")
                    output = current_model.forward_exploration(batch)
                    print(f"[Debug] forward_exploration output keys: {list(output.keys())}")

                ai_action = None
                
                if "actions" in output:
                    
                    ai_action = output["actions"][0].item()
                    print(f"[Debug] Got action from output['actions']: {ai_action}")
                elif "action_dist_inputs" in output:
                    
                    action_dist_input = output["action_dist_inputs"]
                    print(f"[Debug] action_dist_inputs shape: {action_dist_input.shape}")
                    print(f"[Debug] action_dist_inputs type: {type(action_dist_input)}")
                    
                    ai_action = action_dist_input.argmax(dim=-1)[0].item()
                    print(f"[Debug] Got action from action_dist_inputs via argmax: {ai_action}")
                    
                    action_probs = torch.softmax(action_dist_input[0], dim=0)
                    action_range = num_blocks + 1
                    print(f"[Debug] Action probability distribution:")
                    print(f"  no-interference(0): {action_probs[0].item()*100:.1f}%")
                    if len(action_probs) > action_range:
                        print(f"  interfere blocks(1-{num_blocks}): {action_probs[1:action_range].sum().item()*100:.1f}%")
                        print(f"  move blocks({action_range}-{2*num_blocks}): {action_probs[action_range:2*action_range].sum().item()*100:.1f}%")
                else:
                    
                    print(f"[Debug] Unexpected output format, trying other approaches...")
                    if hasattr(output, 'items'):
                        for key, value in output.items():
                            print(f"  {key}: shape={getattr(value, 'shape', 'N/A')}, type={type(value)}")
                            if hasattr(value, 'argmax'):
                                try:
                                    ai_action = value.argmax(dim=-1)[0].item() if value.dim() > 1 else value.argmax().item()
                                    print(f"  Trying to extract action from {key}: {ai_action}")
                                    break
                                except Exception as ex:
                                    print(f"  Failed to extract action from {key}: {ex}")
                    
                    if ai_action is None:
                        raise ValueError("Unexpected model output format, falling back to heuristic strategy")

            ai_action = int(ai_action)
            print(f"[AI] Model action: {ai_action} (0=no-interfere, 1-{num_blocks}=interfere block, {num_blocks+1}-{2*num_blocks}=move block)")
        except Exception as e:
            print(f"[AI] Interference model inference failed: {e}")
            import traceback
            traceback.print_exc()
            
            print("[AI] Switching to heuristic interference strategy")
            player_progress_count = int(player_progress * num_blocks)
            
            critical_threshold = num_blocks - 1  
            partial_threshold = num_blocks - 2   
            
            if player_progress_count >= critical_threshold:
                ai_action = 1
                print(f"[Heuristic] Player progress {player_progress_count}/{num_blocks} >= {critical_threshold}, executing interference!")
            elif player_progress_count >= partial_threshold:
                rand_val = random.random()
                if rand_val < 0.5:
                    ai_action = random.randint(1, num_blocks)
                    print(f"[Heuristic] Player progress {player_progress_count}/{num_blocks} >= {partial_threshold}, rand={rand_val:.2f}<0.5, interfering block {chr(ord('A')+ai_action-1)}")
                else:
                    ai_action = 0
                    print(f"[Heuristic] Player progress {player_progress_count}/{num_blocks} >= {partial_threshold}, rand={rand_val:.2f}>=0.5, continuing stacking")
            else:
                ai_action = 0
                print(f"[Heuristic] Player progress {player_progress_count}/{num_blocks} < {partial_threshold}, focusing on own target")
    else:
        
        print("[AI] Using heuristic interference strategy (model not loaded)")
        player_progress_count = int(player_progress * num_blocks)
        
        critical_threshold = num_blocks - 1  
        partial_threshold = num_blocks - 2   
        
        print(f"player_progress={player_progress:.3f}, count={player_progress_count}")
        
        if player_progress_count >= critical_threshold:
            
            ai_action = 1  
         
        elif player_progress_count >= partial_threshold:
            
            rand_val = random.random()
            if rand_val < 0.5:
                ai_action = random.randint(1, num_blocks)
            
                ai_action = 0

        else:
            ai_action = 0


    interference_decision = 1 <= ai_action <= num_blocks  

    try:
        
        if interference_decision:
            
            target_block_index = ai_action - 1  
            block_names = [chr(ord('A') + i) for i in range(num_blocks)]
            target_block = block_names[target_block_index] if target_block_index < len(block_names) else "A"
            
            next_positions = apply_interference_to_block(current_positions, predicted_target, target_block)
            action_desc = f"Interfere player block {target_block}"
            steps = [next_positions]
            print(f"[AI Priority 1 - Interfere] Executing interference: disrupting player block {target_block}")
        
        elif (num_blocks + 1) <= ai_action <= (2 * num_blocks):
            
            target_block_index = ai_action - (num_blocks + 1)  
            block_names = [chr(ord('A') + i) for i in range(num_blocks)]
            target_block = block_names[target_block_index] if target_block_index < len(block_names) else "A"
            
            if blocksamount == 7:
                
                all_steps = heuristic_agent_7(current_positions, ai_target, int(blocksamount))
            elif blocksamount == 6:
                
                all_steps = heuristic_agent_6(current_positions, ai_target, int(blocksamount))
            else:
                
                all_steps = heuristic_agent(current_positions, ai_target, int(blocksamount))
            
            steps = all_steps if all_steps else [current_positions]
            action_desc = f"Move block {target_block} toward goal"
            print(f"[AI Priority 2 - Stack] Moving own block {target_block}, {len(steps)} steps total")
        
        else:
            
            player_progress_count = calculate_player_progress(current_positions, predicted_target) if predicted_target else 0
            player_critical = player_progress_count >= (num_blocks - 1)  
            
            ai_progress = calculate_ai_progress(current_positions, ai_target)
            ai_progress_ratio = ai_progress / len(ai_target) if ai_target else 0
            
            print(f"[AI Strategy] AI progress: {ai_progress}/{len(ai_target)} ({ai_progress_ratio*100:.1f}%)")
            print(f"[AI Strategy] Player progress: {player_progress_count}/{num_blocks} {'\u26a0\ufe0f DANGER' if player_critical else 'safe'}")
            
            should_deceive = False
            if player_critical:
                
                should_deceive = False
                print(f"[AI Strategy] Player in danger zone, cancelling deception, responding with full effort")
            elif ai_progress_ratio < 0.4:
                
                should_deceive = random.random() < 0.6
            elif ai_progress_ratio < 0.7:
                
                should_deceive = random.random() < 0.3
            else:
                
                should_deceive = False
            
            if should_deceive:
                
                deception_steps = generate_deception_move(current_positions, ai_target, blocksamount)
                steps = deception_steps if deception_steps else [current_positions]
                action_desc = f"Deception move (hiding real target {ai_target})"
                print(f"[AI Priority 3 - Deceive] Executing deception move, {len(steps)} steps")
            else:
                
                if blocksamount == 7:
                    
                    all_steps = heuristic_agent_7(current_positions, ai_target, int(blocksamount))
                elif blocksamount == 6:
                    
                    all_steps = heuristic_agent_6(current_positions, ai_target, int(blocksamount))
                else:
                    
                    all_steps = heuristic_agent(current_positions, ai_target, int(blocksamount))
                
                steps = all_steps if all_steps else [current_positions]
                action_desc = f"Stack own target ({ai_target})"
                print(f"[AI Priority 3 - Normal] Stacking toward own target {ai_target}, {len(steps)} steps")

        formatted_steps = [
            [
                {
                    'block': p['block'],
                    'x': int(p['x']),
                    'y': int(p['y']),
                    'z': int(p['z'])
                }
                for p in step
            ]
            for step in steps
        ]

        def get_block_position(positions, block_name):
            
            for p in positions:
                if p['block'] == block_name:
                    return p
            return None
        
        def count_moved_blocks(pos1, pos2):
            
            moved_count = 0
            for block1 in pos1:
                block2 = get_block_position(pos2, block1['block'])
                if block2:
                    if (block1['x'] != block2['x'] or 
                        block1['y'] != block2['y'] or 
                        block1['z'] != block2['z']):
                        moved_count += 1
            return moved_count
        
        def is_constructive_move(current_pos, next_pos, target_str):
            
            target_blocks = list(target_str)
            target_positions = {}
            for i, block in enumerate(target_blocks):
                z = len(target_blocks) - 1 - i
                target_positions[block] = {'x': 10, 'y': 10, 'z': z}
            
            for block_name in [b['block'] for b in current_pos]:
                curr_block = get_block_position(current_pos, block_name)
                next_block = get_block_position(next_pos, block_name)
                
                if not curr_block or not next_block:
                    continue
                
                if (curr_block['x'] != next_block['x'] or 
                    curr_block['y'] != next_block['y'] or 
                    curr_block['z'] != next_block['z']):
                    
                    if block_name in target_positions:
                        target = target_positions[block_name]
                        
                        if (next_block['x'] == target['x'] and 
                            next_block['y'] == target['y'] and 
                            next_block['z'] == target['z']):
                            return True
                    else:
                        
                        if curr_block['x'] == 10 and curr_block['y'] == 10:
                            if next_block['x'] != 10 or next_block['y'] != 10:
                                return True
            
            return False
        
        current_formatted = [
            {
                'block': p['block'],
                'x': int(p['x']),
                'y': int(p['y']),
                'z': int(p['z'])
            }
            for p in current_positions
        ]
        
        ai_now_step = current_formatted  
        for i, step in enumerate(formatted_steps):
            moved_count = count_moved_blocks(current_formatted, step)
            
            if moved_count == 1 and is_constructive_move(current_formatted, step, ai_target):
                ai_now_step = step
                print(f"[AI] Found single-step move: steps[{i}] (total {len(formatted_steps)} steps, {moved_count} block(s) moved)")
                break
        else:
            
            for i, step in enumerate(formatted_steps):
                moved_count = count_moved_blocks(current_formatted, step)
                if moved_count == 1:
                    ai_now_step = step
                    print(f"[AI] Found single-step move (fallback): steps[{i}] (total {len(formatted_steps)} steps)")
                    break

        if is_vsai_mode and target_game:
            target_game['current_turn'] = 'player'
            print(f"[Game] Turn switched: AI has acted, now it's the player's turn")

        ai_now_step = validate_and_fix_positions(ai_now_step)
        
        formatted_steps = [validate_and_fix_positions(step) for step in formatted_steps]

        return {
            'code': 200,
            'action': 'move',
            'steps': formatted_steps,  
            'ai_now_step': ai_now_step,  
            'interference_decision': interference_decision,
            'predicted_target': predicted_target,
            'confidence': float(confidence),
            'ai_target': ai_target,
            'message': action_desc
        }

    except Exception as e:
        print(f"[AI] Failed to execute move: {e}")
        return {
            'code': 500,
            'error': f'Failed to execute move: {str(e)}',
            'steps': [current_positions],
            'message': 'Execution failed'
        }
def calculate_player_progress(positions, target):
    
    if not target:
        print("[calculate_player_progress] Warning: target is empty")
        return 0
    
    target_chars = set(target)
    target_blocks = [p for p in positions if p['block'] in target_chars]
    
    if not target_blocks:
        print(f"[calculate_player_progress] No target blocks found")
        return 0
    
    stacks = {}  
    for block in target_blocks:
        pos_key = (block['x'], block['y'])
        if pos_key not in stacks:
            stacks[pos_key] = []
        stacks[pos_key].append(block)
    
    max_stack = []
    max_height = 0
    for pos_key, blocks in stacks.items():
        if len(blocks) > max_height:
            max_height = len(blocks)
            max_stack = blocks
    
    if not max_stack:
        return 0
    
    max_stack.sort(key=lambda b: b['z'])
    
    reversed_target = list(reversed(target))
    correct_count = 0
    
    print(f"[calculate_player_progress] Target: {target}, reversed: {reversed_target}")
    print(f"[calculate_player_progress] Tallest stack position: ({max_stack[0]['x']}, {max_stack[0]['y']}), height: {len(max_stack)}")
    
    for i, block in enumerate(max_stack):
        expected_block = reversed_target[i] if i < len(reversed_target) else None
        if expected_block and block['block'] == expected_block:
            
            if abs(block['z'] - i) < 0.5:  
                correct_count += 1
                print(f"[calculate_player_progress]   ✓ {block['block']}  (z={block['z']})")
            else:
                print(f"[calculate_player_progress]   ✗ {block['block']}  ")
                break  
        else:
            print(f"[calculate_player_progress] ")
            break  
    
    print(f"[calculate_player_progress] Result: {correct_count}/{len(target)}")
    return correct_count

def calculate_ai_progress(positions, target):
    
    return calculate_player_progress(positions, target)

def validate_and_fix_positions(positions):
    
    if not positions:
        return positions
    
    position_map = {}  
    
    for p in positions:
        pos_key = (int(p['x']), int(p['y']), int(p['z']))
        if pos_key not in position_map:
            position_map[pos_key] = []
        position_map[pos_key].append(p['block'])
    
    conflicts = {pos: blocks for pos, blocks in position_map.items() if len(blocks) > 1}
    
    if not conflicts:
        
        return positions
    
    print(f"[PositionValidator] Detected {len(conflicts)} block overlap(s), fixing...")
    
    fixed_positions = [p.copy() for p in positions]
    
    for conflict_pos, conflict_blocks in conflicts.items():
        print(f"[PositionValidator] Position {conflict_pos} has {len(conflict_blocks)} overlapping block(s): {conflict_blocks}")
        
        blocks_to_move = conflict_blocks[1:]
        
        for block_name in blocks_to_move:
            
            for i, p in enumerate(fixed_positions):
                if p['block'] == block_name:
                    
                    found_empty = False
                    for x in range(20):
                        for y in range(20):
                            test_pos = (x, y, 0)
                            
                            occupied = any(
                                int(fp['x']) == x and int(fp['y']) == y and int(fp['z']) == 0
                                for fp in fixed_positions if fp['block'] != block_name
                            )
                            if not occupied:
                                print(f"[PositionValidator] Moving block {block_name} from {conflict_pos} to ({x}, {y}, 0)")
                                fixed_positions[i] = {
                                    'block': block_name,
                                    'x': x,
                                    'y': y,
                                    'z': 0
                                }
                                found_empty = True
                                break
                        if found_empty:
                            break
                    
                    if not found_empty:
                        print(f"[PositionValidator] Warning: cannot find an empty position for block {block_name}")
                    break
    
    return fixed_positions

def generate_deception_move(current_positions, ai_target, blocksamount):
    
    all_blocks = [p['block'] for p in current_positions]
    target_blocks = set(ai_target)
    non_target_blocks = [b for b in all_blocks if b not in target_blocks]
    
    if not non_target_blocks:
        
        return None
    
    decoy_block = random.choice(non_target_blocks)
    
    decoy_pos = None
    for p in current_positions:
        if p['block'] == decoy_block:
            decoy_pos = p.copy()
            break
    
    if not decoy_pos:
        return None
    
    def is_position_occupied(x, y, z, positions, exclude_block):
        
        for p in positions:
            if p['block'] == exclude_block:
                continue
            if p['x'] == x and p['y'] == y and p['z'] == z:
                return True
        return False
    
    strategies = [
        
        {'x': 10, 'y': 10, 'z': 0},
        {'x': 9, 'y': 10, 'z': 0},
        {'x': 11, 'y': 10, 'z': 0},
        {'x': 10, 'y': 9, 'z': 0},
        {'x': 10, 'y': 11, 'z': 0},
        {'x': 9, 'y': 9, 'z': 0},
        {'x': 11, 'y': 11, 'z': 0},
        {'x': 9, 'y': 11, 'z': 0},
        {'x': 11, 'y': 9, 'z': 0},
    ]
    
    for _ in range(10):
        strategies.append({
            'x': random.randint(0, 19), 
            'y': random.randint(0, 19), 
            'z': 0
        })
    
    random.shuffle(strategies)
    
    fake_target = None
    for candidate in strategies:
        if not is_position_occupied(candidate['x'], candidate['y'], candidate['z'], 
                                     current_positions, decoy_block):
            fake_target = candidate
            break
    
    if fake_target is None:
        print(f"[Deception] Warning: all candidate positions are occupied, searching for any empty position...")
        for x in range(20):
            for y in range(20):
                if not is_position_occupied(x, y, 0, current_positions, decoy_block):
                    fake_target = {'x': x, 'y': y, 'z': 0}
                    break
            if fake_target:
                break
    
    if fake_target is None:
        print(f"[Deception] Error: cannot find an empty position, cancelling deception")
        return None
    
    new_positions = [p.copy() for p in current_positions]
    for i, p in enumerate(new_positions):
        if p['block'] == decoy_block:
            new_positions[i] = {
                'block': decoy_block,
                'x': fake_target['x'],
                'y': fake_target['y'],
                'z': fake_target['z']
            }
            break
    
    print(f"[Deception] Moving non-target block {decoy_block} from ({decoy_pos['x']},{decoy_pos['y']},{decoy_pos['z']}) to ({fake_target['x']},{fake_target['y']},{fake_target['z']})")
    
    return [new_positions]

def apply_interference(current_positions, player_target):
    
    result = [pos.copy() for pos in current_positions]
    target_chars = set(player_target)
    target_blocks = [p for p in result if p['block'] in target_chars]
    
    if not target_blocks:
        return result
    
    highest_block = max(target_blocks, key=lambda p: p['z'])
    
    def is_position_occupied(x, y, z, positions, exclude_block):
        
        for p in positions:
            if p['block'] == exclude_block:
                continue
            if p['x'] == x and p['y'] == y and p['z'] == z:
                return True
        return False
    
    for pos in result:
        if pos['block'] == highest_block['block']:
            new_x, new_y = 19, 19
            
            if is_position_occupied(19, 19, 0, result, highest_block['block']):
                print(f"[Interference] Position (19, 19, 0) is occupied, searching for empty position...")
                found_empty = False
                
                for x in range(19, -1, -1):
                    for y in range(19, -1, -1):
                        if not is_position_occupied(x, y, 0, result, highest_block['block']):
                            new_x, new_y = x, y
                            found_empty = True
                            break
                    if found_empty:
                        break
            
            pos['x'] = new_x
            pos['y'] = new_y
            pos['z'] = 0
            break
    
    return result

def apply_interference_to_block(current_positions, player_target, target_block):
    
    result = [pos.copy() for pos in current_positions]
    
    target_chars = set(player_target)
    target_blocks = [p for p in result if p['block'] in target_chars]
    
    if not target_blocks:
        return result
    
    stacks = {}
    for block in target_blocks:
        pos_key = (block['x'], block['y'])
        if pos_key not in stacks:
            stacks[pos_key] = []
        stacks[pos_key].append(block)
    
    max_stack = []
    max_stack_pos = None
    for pos_key, blocks in stacks.items():
        if len(blocks) > len(max_stack):
            max_stack = blocks
            max_stack_pos = pos_key
    
    if not max_stack:
        return result
    
    max_stack.sort(key=lambda b: b['z'])
    
    target_in_stack = any(b['block'] == target_block for b in max_stack)
    
    block_to_move = None
    
    if target_in_stack:
        
        target_z = None
        for b in max_stack:
            if b['block'] == target_block:
                target_z = b['z']
                break
        
        has_blocks_above = any(b['z'] > target_z for b in max_stack)
        
        if has_blocks_above:
            
            block_to_move = max_stack[-1]['block']  
            print(f"[Interference Strategy] Target block {target_block} is buried, interfering with topmost block {block_to_move} instead")
        else:
            
            block_to_move = target_block
    else:
        
        block_to_move = max_stack[-1]['block']
        print(f"[Interference Strategy] Target block {target_block} is not in the stack, interfering with topmost block {block_to_move} instead")
    
    def is_position_occupied(x, y, z, positions, exclude_block):
        
        for p in positions:
            if p['block'] == exclude_block:
                continue
            if p['x'] == x and p['y'] == y and p['z'] == z:
                return True
        return False
    
    for i, pos in enumerate(result):
        if pos['block'] == block_to_move:
            
            if max_stack_pos:
                new_x = 19 - max_stack_pos[0]
                new_y = 19 - max_stack_pos[1]
            else:
                new_x = 19 - pos['x']
                new_y = 19 - pos['y']
            
            new_x = max(0, min(19, new_x))
            new_y = max(0, min(19, new_y))
            
            if is_position_occupied(new_x, new_y, 0, result, block_to_move):
                print(f"[Interference] Target position ({new_x}, {new_y}, 0) is occupied, searching for empty position...")
                found_empty = False
                
                for radius in range(1, 20):
                    for dx in range(-radius, radius + 1):
                        for dy in range(-radius, radius + 1):
                            test_x = max(0, min(19, new_x + dx))
                            test_y = max(0, min(19, new_y + dy))
                            if not is_position_occupied(test_x, test_y, 0, result, block_to_move):
                                new_x, new_y = test_x, test_y
                                found_empty = True
                                break
                        if found_empty:
                            break
                    if found_empty:
                        break
                
                if not found_empty:
                    print(f"[Interference] Warning: cannot find empty position, using original diagonal position")
            
            result[i] = {
                "block": block_to_move,
                "x": new_x,
                "y": new_y,
                "z": 0
            }
            print(f"[Interference] Moving block {block_to_move} from ({pos['x']}, {pos['y']}, {pos['z']}) to ({result[i]['x']}, {result[i]['y']}, 0)")
            break
    
    return result

def game_stack(positions, target, num_blocks):
    
    try:
        steps = heuristic_agent(positions, target, num_blocks)
        if steps and len(steps) > 0:
            return steps[-1]
        else:
            return positions
    except Exception as e:
        print(f"[AI Stack] Heuristic algorithm failed: {e}")
        return positions

@app.route('/get-dueler-next-move', methods=['POST'])
def get_dueler_next_move_api():
    
    data = request.get_json() or request.form
    game_id = data.get('gameid')
    positions = data.get('positions')
    player_move_history = data.get('player_move_history', [])
    
    if not all([game_id, positions]):
        return jsonify({
            "code": 400,
            "error": "Missing required fields: gameid and positions",
            "message": "Missing required parameters"
        }), 400
    
    try:
        result = get_vs_dueler_next_move(game_id, positions, player_move_history)
        
        if result['code'] == 200:
            return jsonify(result), 200
        elif result['code'] == 404:
            return jsonify(result), 404
        else:
            return jsonify(result), 500
    
    except Exception as e:
        print(f"API processing error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "code": 500,
            "error": str(e),
            "message": "Internal server error while processing request"
        }), 500

def generate_random_blocks(count):
    
    stack_height = {}
    blocks = []
    block_index = 0

    for _ in range(count):
        x = random.randint(0, 19)
        y = random.randint(0, 19)
        pos_key = (x, y)
        z = stack_height.get(pos_key, 0)

        letter = chr(65 + block_index)
        block_index += 1

        blocks.append({
            "block": letter,
            "x": x,
            "y": y,
            "z": z
        })

        stack_height[pos_key] = z + 1

    return blocks

def generate_blocks_with_obstacles(target_blocks, obstacle_count):
    
    stack_height = {}
    blocks = []
    
    target_letters = [chr(65 + i) for i in range(target_blocks)]
    for i in range(target_blocks):
        x = random.randint(0, 19)
        y = random.randint(0, 19)
        pos_key = (x, y)
        z = stack_height.get(pos_key, 0)
        
        blocks.append({
            "block": target_letters[i],
            "x": x,
            "y": y,
            "z": z
        })
        
        stack_height[pos_key] = z + 1
    
    for i in range(obstacle_count):
        obstacle_letter = chr(65 + target_blocks + i)  
        x = random.randint(0, 19)
        y = random.randint(0, 19)
        pos_key = (x, y)
        z = stack_height.get(pos_key, 0)
        
        blocks.append({
            "block": obstacle_letter,
            "x": x,
            "y": y,
            "z": z,
            "is_obstacle": True  
        })
        
        stack_height[pos_key] = z + 1
    
    return blocks, target_letters

@app.route('/get-next-move', methods=['POST'])
def get_next_move():
    
    data = request.get_json()
    if not data or 'positions' not in data:
        return jsonify({"error": "Missing 'positions' field in request body."}), 400

    current_positions = data['positions']
    num_blocks = data['blocks']
    target = data['target']
    game_id = data['gameid']

    try:
        print(f"Calculating solution for game {game_id}...")
        solution_steps = heuristic_agent(current_positions, target, num_blocks)
        print(f"Solution found: {len(solution_steps)} steps")

        return jsonify({
            "code": 200,
            "message": "Successfully calculated all steps",
            "data": {
                "steps": solution_steps,
                "total_steps": len(solution_steps)
            }
        })

    except Exception as e:
        print(f"Error processing request: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": "Internal server error while processing request."}), 500

def check_win(positions, target):
    
    print("\n--- Win Condition Check Start ---")
    print(f"Target sequence: '{target}'")
    print(f"All block positions: {positions}")

    if not target:
        print("Target sequence is empty, returning False.")
        return False

    blocks_on_ground = [block for block in positions if int(block['z']) == 0]
    print(f"Step 0 - Ground block count: {len(blocks_on_ground)} block(s) on the ground.")

    if len(blocks_on_ground) >= 2:
        print("Two or more blocks on the ground; stacking requirement not met, returning False.")
        print("--- Check End ---\n")
        return False

    target_chars = list(target)
    print(f"Step 1 - Split target: {target_chars}")

    filtered_blocks = [block for block in positions if block['block'] in target_chars]
    print(f"Step 2 - Filtered target blocks: {filtered_blocks}")

    if len(filtered_blocks) != len(target_chars):
        print(f"Error: found {len(filtered_blocks)} target block(s), but target length is {len(target_chars)}. Returning False.")
        return False

    sorted_blocks = sorted(filtered_blocks, key=lambda b: b['z'], reverse=True)


    result_str = ''.join([block['block'] for block in sorted_blocks])


    return result_str == target

@app.route('/init-position', methods=['GET'])
def init_position():
    
    game_id = request.args.get('gameid')
    player_type = request.args.get('type')

    if not game_id:
        return jsonify({"code": 400, "message": "Missing required field: gameid"}), 400

    target_game = next((game for game in game_hall if game['game_id'] == game_id), None)
    if not target_game:
        return jsonify({"code": 404, "message": "Game not found"}), 404

    blocksamount = target_game.get('blocksamount', 0)
    try:
        blocksamount = int(blocksamount)
        if blocksamount <= 0 or blocksamount > 26:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({"code": 400, "message": "Invalid block count (must be an integer 1-26)"}), 400

    if 'initial_positions' not in target_game:
        target_game['initial_positions'] = generate_random_blocks(blocksamount)

    return jsonify({
        "code": 200,
        "message": "Initial positions generated successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": target_game['initial_positions']
        }
    })

@app.route('/init-dueler-position', methods=['GET'])
def init_dueler_position():
    
    game_id = request.args.get('gameid')
    player_type = request.args.get('type')

    if not game_id:
        return jsonify({"code": 400, "message": "Missing required field: gameid"}), 400

    target_game = dueler_games.get(game_id)
    if not target_game:
        return jsonify({"code": 404, "message": "AI duel game not found"}), 404

    blocksamount = target_game.get('blocksamount', 0)
    try:
        blocksamount = int(blocksamount)
        if blocksamount <= 0 or blocksamount > 26:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({"code": 400, "message": "Invalid block count (must be an integer 1-26)"}), 400

    if 'initial_positions' not in target_game:
        target_game['initial_positions'] = generate_random_blocks(blocksamount)

    return jsonify({
        "code": 200,
        "message": "AI duel game initial positions generated successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": target_game['initial_positions']
        }
    })

@app.route('/create-game', methods=['POST'])
def create_game():
    
    data = request.form if request.form else request.json
    creator_name = data.get('name')
    blocksamount = data.get('blocksamount')
    mode = data.get('mode')

    all_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    
    game_id = str(uuid.uuid4())[:8]  
    
    if mode == 'vsmode':
        
        target_host = "".join(random.sample(all_letters[:int(blocksamount)], int(blocksamount))) if blocksamount else ""
        target_participant = "".join(random.sample(all_letters[:int(blocksamount)], int(blocksamount))) if blocksamount else ""
        
        while target_participant == target_host:
            target_participant = "".join(random.sample(all_letters[:int(blocksamount)], int(blocksamount)))
        
        new_game = {
            "game_id": game_id,
            "creator": creator_name,
            "blocksamount": blocksamount,
            "mode": mode,
            "target_host": target_host,
            "target_participant": target_participant,
            "status": "waiting",
            "participants": [],
            "current_turn": "host",  
            "block_positions": {
                "host": {"positions": [], "step": 0, "win": False},
                "participants": {"positions": [], "step": 0, "win": False}
            }
        }
    else:
        
        target = "".join(random.sample(all_letters[:int(blocksamount)], int(blocksamount))) if blocksamount else ""
        new_game = {
            "game_id": game_id,
            "creator": creator_name,
            "blocksamount": blocksamount,
            "mode": mode,
            "target": target,
            "status": "waiting",
            "participants": [],
            "block_positions": {
                "host": {"positions": [], "step": 0, "win": False},
                "participants": {"positions": [], "step": 0, "win": False}
            }
        }
    
    game_hall.append(new_game)

    return jsonify({
        "code": 200,
        "message": "Game created successfully",
        "data": new_game
    })

@app.route('/create-dueler-game', methods=['POST'])
def create_dueler_game():
    
    data = request.form if request.form else request.json
    creator_name = data.get('name')
    blocksamount = data.get('blocksamount')
    mode = data.get('mode', 'dueler')

    all_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    target = "".join(random.sample(all_letters[:int(blocksamount)], int(blocksamount))) if blocksamount else ""

    game_id = str(uuid.uuid4())[:8]
    new_game = {
        "game_id": game_id,
        "creator": creator_name,
        "blocksamount": blocksamount,
        "mode": mode,
        "target": target,
        "status": "started",
        "participants": [],
        "block_positions": {
            "player": {"positions": [], "step": 0, "win": False},
            "dueler": {"positions": [], "step": 0, "win": False}
        },
        "solution_steps": [],
        "current_step": 0
    }

    dueler_games[game_id] = new_game

    return jsonify({
        "code": 200,
        "message": "AI duel game created and started",
        "data": new_game
    })

@app.route('/create-vsai-game', methods=['POST'])
def create_vsai_game():
    
    data = request.form if request.form else request.json
    creator_name = data.get('name')
    blocksamount = data.get('blocksamount')
    mode = data.get('mode', 'vsai')
    
    target_block_count = int(blocksamount) if blocksamount else 3
    
    all_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    target_letters = list(all_letters[:target_block_count])
    
    TRAINED_TARGETS_5BLOCKS = [
        "ABCDE", "EDCBA", "ABCED", "ABDCE", "ABEDC",
        "ACBDE", "ACEDB", "BACED", "BACDE", "BDACE",
        "CBAED", "CBADE", "CDABE", "DABCE", "DBEAC",
        "EABCD", "EBACD", "ECABD", "EDABC", "DEABC"
    ]
    
    TRAINED_TARGETS_6BLOCKS = [
        "ABCDEF",  
        "FEDCBA",  
        "ABCDFE",  
        "ABCEDF",  
        "ABCFED",  
        "ABDCEF",  
        "ACBDEF",  
        "ABDEFC",  
        "BACDEF",  
        "BACEDF",  
        "BDEFCA",  
        "CBAEDF",  
        "CBADEF",  
        "CDABEF",  
        "DABCEF",  
        "DBFACE",  
        "EABCDF",  
        "EBACDF",  
        "ECABDF",  
        "EDABCF",  
        "DEABCF",  
        "FABCDE",  
        "FBACED",  
        "FCABDE",  
        "FDABCE",  
        "FEABCD",  
        "ABFCDE",  
        "ACFBDE",  
        "ADFBCE",  
        "AEFBCD"   
    ]
    
    TRAINED_TARGETS_7BLOCKS = [
        "ABCDEFG",  
        "GFEDCBA",  
        "ABCGDEF",  
        "ABCDEGF",  
        "ABCDFEG",  
        "ABCGFED",  
        "ABDCEFG",  
        "ACBDEFG",  
        "ABDEFGC",  
        "BACDEFG",  
        "BACDEGF",  
        "BDEFGCA",  
        "CBADEFG",  
        "CBDEFGA",  
        "CDABEFG",  
        "DABCEFG",  
        "DBFACEG",  
        "EABCDFG",  
        "EBACDFG",  
        "ECABDFG",  
        "EDABCFG",  
        "DEABCFG",  
        "FABCDEG",  
        "FBACEDG",  
        "FCABDEG",  
        "FDABCEG",  
        "FEABCDG",  
        "GABCDEF",  
        "GACBDEF",  
        "GDEFABC",  
        "CBDAEFG",  
        "DCBAEFG",  
        "EFGABCD",  
        "FGABCDE",  
        "GFABCDE",  
        "ABFGCDE",  
        "ACEGBDF",  
        "BDFACEG",  
        "CEGABDF",  
        "DEFGABC"   
    ]
    
    obstacle_count = random.randint(6, 16)
    
    if target_block_count == 7:
        player_target = random.choice(TRAINED_TARGETS_7BLOCKS)
        
        total_blocks_count = target_block_count + obstacle_count
        available_letters = list(all_letters[:total_blocks_count])
        ai_target_letters = random.sample(available_letters, 7)
        ai_target = "".join(ai_target_letters)
        
        while ai_target == player_target:
            ai_target_letters = random.sample(available_letters, 7)
            ai_target = "".join(ai_target_letters)
    elif target_block_count == 6:
        player_target = random.choice(TRAINED_TARGETS_6BLOCKS)
        
        total_blocks_count = target_block_count + obstacle_count
        available_letters = list(all_letters[:total_blocks_count])
        ai_target_letters = random.sample(available_letters, 6)
        ai_target = "".join(ai_target_letters)
        
        while ai_target == player_target:
            ai_target_letters = random.sample(available_letters, 6)
            ai_target = "".join(ai_target_letters)
    elif target_block_count == 5:
        player_target = random.choice(TRAINED_TARGETS_5BLOCKS)
        
        total_blocks_count = target_block_count + obstacle_count
        available_letters = list(all_letters[:total_blocks_count])
        ai_target_letters = random.sample(available_letters, 5)
        ai_target = "".join(ai_target_letters)
        
        while ai_target == player_target:
            ai_target_letters = random.sample(available_letters, 5)
            ai_target = "".join(ai_target_letters)
    else:
        
        player_target = "".join(random.sample(target_letters, target_block_count))
        ai_target = "".join(random.sample(target_letters, target_block_count))
        
        while ai_target == player_target:
            ai_target = "".join(random.sample(target_letters, target_block_count))
    
    game_id = str(uuid.uuid4())[:8]
    new_game = {
        "game_id": game_id,
        "creator": creator_name,
        "blocksamount": target_block_count,
        "mode": mode,
        "target_player": player_target,  
        "target_ai": ai_target,  
        "status": "started",
        "current_turn": "player",  
        "block_positions": {
            "player": {"positions": [], "step": 0, "win": False},
            "ai": {"positions": [], "step": 0, "win": False}
        },
        "obstacle_count": obstacle_count,  
        "target_blocks": target_letters  
    }
    
    vsai_games[game_id] = new_game
    
    return jsonify({
        "code": 200,
        "message": "VS AI game created successfully",
        "data": new_game
    })

@app.route('/init-vsai-position', methods=['GET'])
def init_vsai_position():
    
    game_id = request.args.get('gameid')
    player_type = request.args.get('type')

    if not game_id:
        return jsonify({"code": 400, "message": "Missing required field: gameid"}), 400

    target_game = vsai_games.get(game_id)
    if not target_game:
        return jsonify({"code": 404, "message": "VS AI game not found"}), 404

    if 'initial_positions' not in target_game:
        blocks, target_letters = generate_blocks_with_obstacles(
            target_game['blocksamount'],
            target_game['obstacle_count']
        )
        target_game['initial_positions'] = blocks
        target_game['total_blocks'] = len(blocks)

        print(f"Game {game_id}: generated {len(target_letters)} target block(s) {target_letters} and {target_game['obstacle_count']} obstacle block(s)")
        print(f"Player target: {target_game['target_player']}")
        print(f"AI target: {target_game['target_ai']}")

    return jsonify({
        "code": 200,
        "message": "VS AI game initial positions generated successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": target_game['initial_positions'],
            "target_player": target_game['target_player'],
            "target_ai": target_game['target_ai'],
            "current_turn": target_game['current_turn'],
            "total_blocks": target_game['total_blocks'],
            "obstacle_count": target_game['obstacle_count']
        }
    })

@app.route('/set-vsai-block-position', methods=['POST'])
def set_vsai_block_position():
    
    data = request.get_json() or request.form
    game_id = data.get('gameid')
    player_type = data.get('type')
    positions = data.get('positions')
    step = data.get('step')
    
    if game_id is None or player_type is None or positions is None or step is None:
        return jsonify({"code": 400, "message": "Missing required fields: gameid, type, positions and step"}), 400
    
    if player_type not in ['player', 'ai']:
        return jsonify({"code": 400, "message": "type must be 'player' or 'ai'"}), 400
    
    try:
        step = int(step)
        if step < 0:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({"code": 400, "message": "step must be a non-negative integer"}), 400
    
    target_game = vsai_games.get(game_id)
    if not target_game:
        return jsonify({"code": 404, "message": "VS AI game not found"}), 404
    
    if target_game['current_turn'] != player_type:
        return jsonify({
            "code": 400,
            "message": f"It is not {player_type}'s turn, please wait"
        }), 400
    
    target = target_game['target_player'] if player_type == 'player' else target_game['target_ai']
    win = check_win(positions, target)
    
    target_game['block_positions'][player_type] = {
        "positions": positions,
        "step": step,
        "win": win
    }
    
    if win:
        target_game['status'] = 'finished'
        target_game['winner'] = player_type
    else:
        
        target_game['current_turn'] = 'ai' if player_type == 'player' else 'player'
    
    return jsonify({
        "code": 200,
        "message": "Block positions updated successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": positions,
            "step": step,
            "win": win,
            "current_turn": target_game['current_turn'],
            "game_status": target_game['status']
        }
    })

@app.route('/get-vsai-block-position', methods=['GET'])
def get_vsai_block_position():
    
    game_id = request.args.get('gameid')
    player_type = request.args.get('type')
    
    if not all([game_id, player_type]):
        return jsonify({"code": 400, "message": "Missing required fields: gameid and type"}), 400
    
    if player_type not in ['player', 'ai']:
        return jsonify({"code": 400, "message": "type must be 'player' or 'ai'"}), 400
    
    target_game = vsai_games.get(game_id)
    if not target_game:
        return jsonify({"code": 404, "message": "VS AI game not found"}), 404
    
    block_info = target_game['block_positions'].get(player_type, {
        "positions": [],
        "step": 0,
        "win": False
    })
    
    return jsonify({
        "code": 200,
        "message": "Position queried successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": block_info['positions'],
            "step": block_info['step'],
            "win": block_info.get('win', False),
            "current_turn": target_game['current_turn'],
            "game_status": target_game['status']
        }
    })

@app.route('/set-block-position', methods=['POST'])
def set_block_position():
    
    data = request.get_json() or request.form
    game_id = data.get('gameid')
    player_type = data.get('type')
    positions = data.get('positions')
    step = data.get('step')

    if game_id is None or player_type is None or positions is None or step is None:
        return jsonify({"code": 400, "message": "Pass the gameid, type, positions, and step"}), 400

    if player_type not in ['host', 'participants']:
        return jsonify({"code": 400, "message": "type must be 'host' or 'participants'"}), 400

    try:
        step = int(step)
        if step < 0:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({"code": 400, "message": "step must be a nonnegative integer"}), 400

    target_game = next((game for game in game_hall if game['game_id'] == game_id), None)
    if not target_game:
        return jsonify({"code": 404, "message": "The game doesn't exist"}), 404

    if target_game.get('mode') == 'vsmode':
        
        target = target_game.get(f'target_{player_type}')  
    else:
        
        target = target_game.get('target')
    
    win = check_win(positions, target)

    target_game['block_positions'][player_type] = {
        "positions": positions,
        "step": step,
        "win": win
    }

    return jsonify({
        "code": 200,
        "message": "Block positions and step updated successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": positions,
            "step": step,
            "win": win
        }
    })

@app.route('/set-dueler-block-position', methods=['POST'])
def set_dueler_block_position():
    
    data = request.get_json() or request.form
    game_id = data.get('gameid')
    player_type = data.get('type')
    positions = data.get('positions')
    step = data.get('step')

    if game_id is None or player_type is None or positions is None or step is None:
        return jsonify({"code": 400, "message": "Missing required fields: gameid, type, positions and step"}), 400

    if player_type not in ['player', 'dueler']:
        return jsonify({"code": 400, "message": "type must be 'player' or 'dueler'"}), 400

    try:
        step = int(step)
        if step < 0:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({"code": 400, "message": "step must be a non-negative integer"}), 400

    target_game = dueler_games.get(game_id)
    if not target_game:
        return jsonify({"code": 404, "message": "AI duel game not found"}), 404

    win = check_win(positions, target_game['target'])

    target_game['block_positions'][player_type] = {
        "positions": positions,
        "step": step,
        "win": win
    }

    return jsonify({
        "code": 200,
        "message": "Block positions and step updated successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": positions,
            "step": step,
            "win": win
        }
    })

@app.route('/get-block-position', methods=['GET'])
def get_block_position():
    
    game_id = request.args.get('gameid')
    player_type = request.args.get('type')

    if not all([game_id, player_type]):
        return jsonify({"code": 400, "message": "Missing required fields: gameid and type"}), 400

    if player_type not in ['host', 'participants']:
        return jsonify({"code": 400, "message": "type must be 'host' or 'participants'"}), 400

    target_game = next((game for game in game_hall if game['game_id'] == game_id), None)
    if not target_game:
        return jsonify({"code": 404, "message": "Game not found"}), 404

    block_info = target_game['block_positions'].get(player_type, {
        "positions": [],
        "step": 0,
        "win": False
    })

    return jsonify({
        "code": 200,
        "message": "Position queried successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": block_info['positions'],
            "step": block_info['step'],
            "win": block_info.get('win', False)
        }
    })

@app.route('/get-dueler-block-position', methods=['GET'])
def get_dueler_block_position():
    
    game_id = request.args.get('gameid')
    player_type = request.args.get('type')

    if not all([game_id, player_type]):
        return jsonify({"code": 400, "message": "Missing required fields: gameid and type"}), 400

    if player_type not in ['player', 'dueler']:
        return jsonify({"code": 400, "message": "type must be 'player' or 'dueler'"}), 400

    target_game = dueler_games.get(game_id)
    if not target_game:
        return jsonify({"code": 404, "message": "AI duel game not found"}), 404

    block_info = target_game['block_positions'].get(player_type, {
        "positions": [],
        "step": 0,
        "win": False
    })

    return jsonify({
        "code": 200,
        "message": "Position queried successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": block_info['positions'],
            "step": block_info['step'],
            "win": block_info.get('win', False)
        }
    })

@app.route('/init-vsplayer-position', methods=['GET'])
def init_vsplayer_position():
    
    game_id = request.args.get('gameid')
    player_type = request.args.get('type')

    if not game_id:
        return jsonify({"code": 400, "message": "Pass gameid"}), 400

    target_game = next((game for game in game_hall if game['game_id'] == game_id), None)
    if not target_game:
        return jsonify({"code": 404, "message": "The game doesn't exist"}), 404

    if target_game.get('mode') != 'vsmode':
        return jsonify({"code": 400, "message": "The interface only supports vsmode games"}), 400

    blocksamount = target_game.get('blocksamount', 0)
    try:
        blocksamount = int(blocksamount)
        if blocksamount <= 0 or blocksamount > 26:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({"code": 400, "message": "Invalid number of blocks (must be an integer from 1-26)"}), 400

    if 'initial_positions' not in target_game:
        target_game['initial_positions'] = generate_random_blocks(blocksamount)

    return jsonify({
        "code": 200,
        "message": "The vsmode initial position was generated successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": target_game['initial_positions'],
            "current_turn": target_game.get('current_turn', 'host'),
            "target_host": target_game.get('target_host', ''),
            "target_participant": target_game.get('target_participant', '')
        }
    })

@app.route('/set-vsplayer-position', methods=['POST'])
def set_vsplayer_position():
    
    data = request.get_json() or request.form
    game_id = data.get('gameid')
    player_type = data.get('type')
    positions = data.get('positions')
    step = data.get('step')

    if game_id is None or player_type is None or positions is None or step is None:
        return jsonify({"code": 400, "message": "Missing required fields: gameid, type, positions and step"}), 400

    if player_type not in ['host', 'participants']:
        return jsonify({"code": 400, "message": "type must be 'host' or 'participants'"}), 400

    try:
        step = int(step)
        if step < 0:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({"code": 400, "message": "step must be a non-negative integer"}), 400

    target_game = next((game for game in game_hall if game['game_id'] == game_id), None)
    if not target_game:
        return jsonify({"code": 404, "message": "Game not found"}), 404

    if target_game.get('mode') != 'vsmode':
        return jsonify({"code": 400, "message": "This endpoint only supports vsmode games"}), 400

    current_turn = target_game.get('current_turn', 'host')
    if current_turn != player_type:
        return jsonify({
            "code": 200,
            "message": f"It is not {player_type}'s turn, please wait for opponent",
            "current_turn": current_turn
        }), 200

    target = target_game.get(f'target_{player_type}')  
    win = check_win(positions, target)

    target_game['block_positions'][player_type] = {
        "positions": positions,
        "step": step,
        "win": win
    }

    if win:
        target_game['status'] = 'finished'
        target_game['winner'] = player_type
    else:
        
        target_game['current_turn'] = 'participants' if player_type == 'host' else 'host'

    return jsonify({
        "code": 200,
        "message": "Block positions updated successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": positions,
            "step": step,
            "win": win,
            "current_turn": target_game.get('current_turn'),
            "game_status": target_game.get('status')
        }
    })

@app.route('/get-vsplayer-block-position', methods=['GET'])
def get_vsplayer_block_position():
    
    game_id = request.args.get('gameid')
    player_type = request.args.get('type')

    if not all([game_id, player_type]):
        return jsonify({"code": 400, "message": "Missing required fields: gameid and type"}), 400

    if player_type not in ['host', 'participants']:
        return jsonify({"code": 400, "message": "type must be 'host' or 'participants'"}), 400

    target_game = next((game for game in game_hall if game['game_id'] == game_id), None)
    if not target_game:
        return jsonify({"code": 404, "message": "Game not found"}), 404

    if target_game.get('mode') != 'vsmode':
        return jsonify({"code": 400, "message": "This endpoint only supports vsmode games"}), 400

    host_info = target_game['block_positions'].get('host', {
        "positions": [],
        "step": 0,
        "win": False
    })
    
    participants_info = target_game['block_positions'].get('participants', {
        "positions": [],
        "step": 0,
        "win": False
    })

    current_positions = []
    if host_info['step'] >= participants_info['step'] and host_info['positions']:
        current_positions = host_info['positions']
    elif participants_info['positions']:
        current_positions = participants_info['positions']

    current_turn = target_game.get('current_turn', 'host')
    is_my_turn = (current_turn == player_type)

    my_step = host_info['step'] if player_type == 'host' else participants_info['step']
    my_win = host_info.get('win', False) if player_type == 'host' else participants_info.get('win', False)
    opponent_step = participants_info['step'] if player_type == 'host' else host_info['step']
    opponent_win = participants_info.get('win', False) if player_type == 'host' else host_info.get('win', False)

    return jsonify({
        "code": 200,
        "message": "Position queried successfully",
        "data": {
            "game_id": game_id,
            "type": player_type,
            "positions": current_positions,
            "my_step": my_step,
            "my_win": my_win,
            "opponent_step": opponent_step,
            "opponent_win": opponent_win,
            "current_turn": current_turn,
            "is_my_turn": is_my_turn,
            "game_status": target_game.get('status', 'waiting'),
            "winner": target_game.get('winner', None)
        }
    })

@app.route('/game-hall', methods=['GET'])
def get_game_hall():
    return jsonify({
        "code": 200,
        "message": "Query successful",
        "data": game_hall
    })

@app.route('/cancel-game', methods=['POST'])
def cancel_game():
    data = request.form if request.form else request.json
    game_id = data.get('gameid')

    if not game_id:
        return jsonify({"code": 400, "message": "Missing required field: game ID"}), 400

    global game_hall
    remaining_games = [game for game in game_hall if game['game_id'] != game_id]

    game_hall = remaining_games
    return jsonify({
        "code": 200,
        "message": "Game cancelled successfully",
        "data": {"game_id": game_id}
    })

@app.route('/join-game', methods=['POST'])
def join_game():
    data = request.form if request.form else request.json
    game_id = data.get('gameid')
    player_name = data.get('playerName')
    user_id = data.get('userid')

    if not all([game_id, player_name, user_id]):
        return jsonify({"code": 400, "message": "Missing required fields: gameid, playerName and userid"}), 400

    target_game = next((game for game in game_hall if game['game_id'] == game_id), None)
    if not target_game:
        return jsonify({"code": 404, "message": "Game not found"}), 404

    if 'participants' not in target_game:
        target_game['participants'] = []

    if target_game['status'] != "waiting":
        return jsonify({"code": 400, "message": "Game already has a player, cannot join again"}), 400

    target_game['participants'].append({
        "playerName": player_name,
        "userid": user_id
    })
    target_game['status'] = "joined"

    response_data = {
        "game_id": game_id,
        "participant": {
            "playerName": player_name,
            "userid": user_id
        }
    }
    
    if target_game.get('mode') == 'vsmode':
        
        response_data['target_host'] = target_game.get('target_host', "")
        response_data['target_participant'] = target_game.get('target_participant', "")
    else:
        
        response_data['target'] = target_game.get('target', "")

    return jsonify({
        "code": 200,
        "message": "Joined game successfully",
        "data": response_data
    })

@app.route('/game-status', methods=['GET'])
def game_status():
    game_id = request.args.get('gameid')

    if not game_id:
        return jsonify({"code": 400, "message": "Pass gameid"}), 400

    target_game = next((game for game in game_hall if game['game_id'] == game_id), None)
    if not target_game:
        return jsonify({"code": 404, "message": "The game doesn't exist"}), 404

    participants = target_game.get('participants', [])
    
    response_data = {
        "game_id": game_id,
        "status": target_game['status'],
        "participants": participants,
        "block_positions": target_game.get('block_positions', {})
    }
    
    if target_game.get('mode') == 'vsmode':
        
        response_data['target_host'] = target_game.get('target_host', "")
        response_data['target_participant'] = target_game.get('target_participant', "")
    else:
        
        response_data['target'] = target_game.get('target', "")
    
    return jsonify({
        "code": 200,
        "message": "Status queried successfully",
        "data": response_data
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)