/* eslint-disable */
const { defineConfig } = require("@vue/cli-service");
const defaultSettings = require("./src/settings.js");
const path = require("path");

function resolve(dir) {
  return path.join(__dirname, dir);
}

const name = defaultSettings.title || "Block World"; // page title

const port = process.env.port || process.env.npm_config_port || 8888;

module.exports = defineConfig({
  // outputDir: "",
  publicPath: "/",

  lintOnSave: process.env.NODE_ENV === "development",
  productionSourceMap: false,
  devServer: {
    port: port,
    open: false,
    client: {
      overlay: {
        errors: true,
        warnings: false,
      },
    },

    proxy: {
      "/api/": {
        target: "http://127.0.0.1:5000/",

        logLevel: "debug",
        changeOrigin: true,
        ws: true,
        secure: false,
        pathRewrite: {
          "^/api/": "",
        },
      },
    },
  },
  configureWebpack: {
    resolve: {
      fallback: {
        path: require.resolve("path-browserify"),
      },
    },
  },
  chainWebpack(config) {
    config.plugin("html").tap((args) => {
      args[0].title = name;
      return args;
    });

    config.module.rule("svg").exclude.add(resolve("src/icons")).end();
    config.module
      .rule("icons")
      .test(/\.svg$/)
      .include.add(resolve("src/icons"))
      .end()
      .use("svg-sprite-loader")
      .loader("svg-sprite-loader")
      .options({
        symbolId: "icon-[name]",
      })
      .end();
  },
});
