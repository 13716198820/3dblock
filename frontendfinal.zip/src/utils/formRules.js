const positiveInteger = (rule, value, callback) => {
  var reg = /(^[0-9]\d*$)/;
  if (!reg.test(value)) {
    callback(new Error(""));
  } else {
    callback();
  }
};

const validatePhone = (rule, value, callback) => {
  var reg =
    /^(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|18[0|1|2|3|5|6|7|8|9])\d{8}$/;
  if (!reg.test(value)) {
    callback(new Error(""));
  } else {
    callback();
  }
};

const validateMail = (rule, value, callback) => {
  var reg = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
  if (!reg.test(value)) {
    callback(new Error(""));
  } else {
    callback();
  }
};

module.exports = {
  positiveInteger,
  validatePhone,
  validateMail,
};
