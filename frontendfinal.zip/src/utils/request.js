import axios from "axios";
import { Message, Loading } from "element-ui";

let loadingInstance = null;
let loadingOptions = {
  customClass: "loadingClass",
  text: "Loading......",
  spinner: "el-icon-loading",
  background: "rgba(0, 0, 0, 0.5)",
};

const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API, // url = base url + request url

  timeout: 600000,
});

service.interceptors.request.use(
  (config) => {
    loadingInstance = Loading.service(loadingOptions);
    return config;
  },
  (error) => {
    loadingInstance.close();

    return Promise.reject(error);
  }
);

service.interceptors.response.use(
  (res) => {
    loadingInstance && loadingInstance.close();

    const code = res.data.code || 200;
    if (code === 200) {
      return res.data;
    } else {
      Message({
        message: "Error",
        type: "error",
        duration: 5 * 1000,
      });
      return Promise.reject("error");
    }
  },
  (error) => {
    loadingInstance.close();

    Message({ message: "error", type: "error", duration: 5 * 1000 });
    return Promise.reject(error);
  }
);
export default service;
