export function getBaseInfo() {
  let target = "";
  let all = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

  const blocksamount = parseInt(localStorage.getItem("blocksamount")) || 0;

  if (blocksamount > 0 && blocksamount <= all.length) {
    const selectedLetters = all.substring(0, blocksamount);

    const lettersArray = selectedLetters.split("");

    for (let i = lettersArray.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [lettersArray[i], lettersArray[j]] = [lettersArray[j], lettersArray[i]];
    }

    target = lettersArray.join("");
  }

  return {
    name: localStorage.getItem("playerName"),
    blocksamount: localStorage.getItem("blocksamount"),
    target: target,
  };
}
export function getTarget(_blocksamount) {
  let target = "";
  let all = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

  const blocksamount = _blocksamount;

  if (blocksamount > 0 && blocksamount <= all.length) {
    const selectedLetters = all.substring(0, blocksamount);

    const lettersArray = selectedLetters.split("");

    for (let i = lettersArray.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [lettersArray[i], lettersArray[j]] = [lettersArray[j], lettersArray[i]];
    }

    target = lettersArray.join("");
  }

  return target;
}
