<template>
  <div class="confetti-container" v-if="active">
    <div
      v-for="(particle, index) in particles"
      :key="index"
      class="confetti-particle"
      :style="particle.style"
    ></div>
  </div>
</template>

<script>
export default {
  name: "Confetti",
  data() {
    return {
      active: false,
      particles: [],
      particleCount: 150,
      colors: [
        "#ff0000",
        "#00ff00",
        "#0000ff",
        "#ffff00",
        "#ff00ff",
        "#00ffff",
        "#ffa500",
        "#ff1493",
        "#7fff00",
        "#1e90ff",
      ],
    };
  },
  methods: {
    fire() {
      this.active = true;
      this.particles = [];
      this.createParticles();

      setTimeout(() => {
        this.active = false;
        this.particles = [];
      }, 5500);
    },

    createParticles() {
      for (let i = 0; i < this.particleCount; i++) {
        this.particles.push(this.createParticle("right"));
      }
    },

    createParticle(side) {
      const color = this.colors[Math.floor(Math.random() * this.colors.length)];
      const size = Math.random() * 10 + 5; //
      const duration = Math.random() * 2 + 3; //
      const delay = Math.random() * 0.5; //

      let startX, endX, endY;

      if (side === "left") {
        startX = Math.random() * 10; // 0-10%
        endX = Math.random() * 40 + 30; //
      } else {
        startX = Math.random() * 10 + 90; // 90-100%
        endX = Math.random() * 40 + 30; //
      }

      endY = Math.random() * 80 + 10; //

      const rotation = Math.random() * 720; //
      const spread = Math.random() * 240 - 120; //

      return {
        style: {
          left: `${startX}%`,
          bottom: "0%",
          width: `${size}px`,
          height: `${size}px`,
          backgroundColor: color,
          "--end-x": `${endX + spread}%`,
          "--end-y": `${endY}%`,
          "--rotation": `${rotation}deg`,
          animationDuration: `${duration}s`,
          animationDelay: `${delay}s`,
        },
      };
    },
  },
};
</script>

<style lang="scss" scoped>
.confetti-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 9999;
  overflow: hidden;
}

.confetti-particle {
  position: absolute;
  border-radius: 50%;
  opacity: 1;
  animation: confetti-fall 3s ease-out forwards;

  &:nth-child(3n) {
    border-radius: 0;
  }

  &:nth-child(5n) {
    border-radius: 3px;
  }
}

@keyframes confetti-fall {
  0% {
    transform: translate(0, 0) rotate(0deg);
    opacity: 1;
  }

  50% {
    opacity: 1;
  }

  100% {
    transform: translate(calc(var(--end-x) - 50vw), calc(-100vh + var(--end-y)))
      rotate(var(--rotation));
    opacity: 0;
  }
}
</style>
