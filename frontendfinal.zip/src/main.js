import Vue from "vue";
import App from "./App.vue";
import router from "./router";

import axios from "axios";

import ElementUI from "element-ui";
import "element-ui/lib/theme-chalk/index.css";
import "@/styles/element-variables.scss";
import "normalize.css/normalize.css";
import "@/styles/index.scss";

import plugins from "./plugins";

import "./router/routers-guards";

Vue.use(plugins);

Vue.use(ElementUI, {
  size: window.sessionStorage.getItem("size") || "small",
});

Vue.prototype.$axios = axios;
Vue.prototype.$message = ElementUI.Message;
Vue.prototype.$confirm = ElementUI.MessageBox.confirm;

Vue.prototype.$EventBus = new Vue();
Vue.config.productionTip = false;

new Vue({
  router,

  render: (h) => h(App),
}).$mount("#app");
