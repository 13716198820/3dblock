<template>
  <div class="bigScene" ref="sceneContainer">
    <!-- <div id="info">
      <a href="https://threejs.org" target="_blank" rel="noopener">three.js</a>
      - voxel painter - webgl<br />
      <strong>click</strong>: select voxel, <strong>shift + click</strong>:
      remove voxel<br />
      <strong>right click</strong>: deselect all, <strong>mouse drag</strong>:
      rotate view, <strong>mouse wheel</strong>: zoom<br />
      <strong>select + drag + click</strong>: move voxel
    </div> -->
    <div class="header">
      <span>Name: &nbsp;{{ name }}</span>
      <span>Steps:&nbsp; {{ step }}</span>
      <span style="display: none"
        >Target:&nbsp;{{ target
        }}<sup style="font-weight: bold">(Up to Down)</sup></span
      >
      <div class="control">
        <el-dropdown trigger="click" @command="handleCommand">
          <el-button icon="el-icon-s-tools" circle></el-button>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="restart">Restart</el-dropdown-item>
            <el-dropdown-item command="gohome">Gohome</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
      <div class="oneTarget">
        <div
          class="oneTargetBlock"
          v-for="(item, index) in target.split('')"
          :key="index"
        >
          {{ item }}
        </div>
      </div>
    </div>
    <Confetti ref="confetti" />
  </div>
</template>

<script>
/* eslint-disable */
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { FontLoader } from "three/examples/jsm/loaders/FontLoader.js";
import { TextGeometry } from "three/examples/jsm/geometries/TextGeometry.js";
import { getBaseInfo } from "@/utils/index.js";
import Confetti from "@/components/Confetti/index.vue";
export default {
  name: "home",
  components: { Confetti },
  data() {
    return {
      name: "",
      step: 0,
      target: "",
      blocksamount: 0,

      win: {},
      camera: null,
      scene: null,
      renderer: null,
      plane: null,
      pointer: null,
      raycaster: null,
      isShiftDown: false,
      cubeGeo: null,
      cubeMaterial: null,
      objects: [],
      eventListeners: {},
      controls: null,
      animationId: null,
      gridSize: 50,
      gridRange: 10,
      font: null,
      blockIndex: 0,
      selectedBlock: null,
      previewBlock: null,
      isDragging: false,
    };
  },

  mounted() {
    let info = getBaseInfo();
    this.name = info.name;
    this.target = info.target;
    this.blocksamount =
      parseInt(info.blocksamount) + Math.floor(Math.random() * 11) + 5;

    this.init();
  },

  beforeDestroy() {
    Object.values(this.eventListeners).forEach(({ target, type, listener }) => {
      target.removeEventListener(type, listener);
    });

    if (this.controls) {
      this.controls.dispose();
    }

    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }

    if (this.renderer) {
      this.renderer.dispose();
    }
  },

  methods: {
    init() {
      this.camera = new THREE.PerspectiveCamera(
        45,
        window.innerWidth / window.innerHeight,
        1,
        10000
      );
      this.camera.position.set(500, 800, 1300);
      this.camera.lookAt(0, 0, 0);

      this.scene = new THREE.Scene();
      this.scene.background = new THREE.Color(0xf0f0f0);

      this.cubeGeo = new THREE.BoxGeometry(
        this.gridSize,
        this.gridSize,
        this.gridSize
      );
      this.cubeMaterial = new THREE.MeshLambertMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.95,
      });

      const gridHelper = new THREE.GridHelper(1000, 20);
      this.scene.add(gridHelper);

      this.raycaster = new THREE.Raycaster();
      this.pointer = new THREE.Vector2();

      const geometry = new THREE.PlaneGeometry(1000, 1000);
      geometry.rotateX(-Math.PI / 2);

      this.plane = new THREE.Mesh(
        geometry,
        new THREE.MeshBasicMaterial({ visible: false })
      );
      this.scene.add(this.plane);
      this.objects.push(this.plane);

      const ambientLight = new THREE.AmbientLight(0x606060, 3);
      this.scene.add(ambientLight);

      const directionalLight = new THREE.DirectionalLight(0xffffff, 3);
      directionalLight.position.set(1, 0.75, 0.5).normalize();
      this.scene.add(directionalLight);

      this.renderer = new THREE.WebGLRenderer({ antialias: true });
      this.renderer.setPixelRatio(window.devicePixelRatio);
      this.renderer.setSize(window.innerWidth, window.innerHeight);
      this.$refs.sceneContainer.appendChild(this.renderer.domElement);

      this.controls = new OrbitControls(this.camera, this.renderer.domElement);
      this.controls.enableDamping = true;
      this.controls.dampingFactor = 0.05;
      this.controls.enableZoom = true;
      this.controls.zoomSpeed = 0.5;
      this.controls.enableRotate = true;
      this.controls.rotateSpeed = 0.5;
      this.controls.enablePan = false;

      this.addEventListener(document, "pointermove", this.onPointerMove);
      this.addEventListener(document, "pointerdown", this.onPointerDown);

      this.addEventListener(window, "resize", this.onWindowResize);

      this.addEventListener(document, "contextmenu", this.onRightClick);

      this.loadFont().then(() => {
        this.generateRandomBlocks(this.blocksamount);

        console.log(this.getAllBlockPositions());
        // setTimeout(() => {
        //   this.setAllBlockPositions([
        //     { block: "A", x: 1, y: 17, z: 0 },
        //     { block: "B", x: 7, y: 17, z: 0 },
        //     { block: "C", x: 0, y: 13, z: 0 },
        //   ]);
        // }, 1000);
      });

      this.animate();
    },

    loadFont() {
      return new Promise((resolve) => {
        const loader = new FontLoader();
        loader.load(
          "/fonts/helvetiker_regular.typeface.json",
          (font) => {
            this.font = font;
            resolve();
          },
          undefined,
          (error) => {
            console.warn("Font loading failed, using default font", error);
            resolve();
          }
        );
      });
    },

    //
    addTextToAllFaces(cube, letter) {
      if (!this.font) return;

      const textGeometry = new TextGeometry(letter, {
        font: this.font,
        size: 20,
        height: 1,
        curveSegments: 12,
        bevelEnabled: false,
      });

      textGeometry.computeBoundingBox();
      const textWidth =
        textGeometry.boundingBox.max.x - textGeometry.boundingBox.min.x;
      const textHeight =
        textGeometry.boundingBox.max.y - textGeometry.boundingBox.min.y;

      const textMaterial = new THREE.MeshLambertMaterial({ color: 0x000000 });

      const faces = [
        {
          position: [0, 0, this.gridSize / 2 + 1],
          rotation: [0, 0, 0],
          offset: [-textWidth / 2, -textHeight / 2, 0],
        },
      ];

      faces.forEach((face) => {
        const textMesh = new THREE.Mesh(
          textGeometry.clone(),
          textMaterial.clone()
        );
        textMesh.position.set(...face.position);
        textMesh.rotation.set(...face.rotation);
        textMesh.position.x += face.offset[0];
        textMesh.position.y += face.offset[1];
        textMesh.position.z += face.offset[2];
        textMesh.scale.set(1, 1, 0.005);
        cube.add(textMesh);
      });
    },

    generateRandomBlocks(count) {
      const heightMap = new Map();

      for (let i = 0; i < count; i++) {
        const gridX =
          Math.floor(Math.random() * (this.gridRange * 2)) - this.gridRange;
        const gridZ =
          Math.floor(Math.random() * (this.gridRange * 2)) - this.gridRange;
        const positionKey = `${gridX},${gridZ}`;
        const currentHeight = heightMap.get(positionKey) || 0;

        const x = gridX * this.gridSize + this.gridSize / 2;
        const z = gridZ * this.gridSize + this.gridSize / 2;
        const y = currentHeight * this.gridSize + this.gridSize / 2;

        const voxel = new THREE.Mesh(this.cubeGeo, this.cubeMaterial.clone());
        voxel.position.set(x, y, z);
        this.addBlockBorder(voxel);

        const letter = String.fromCharCode(65 + this.blockIndex);
        this.addTextToAllFaces(voxel, letter);
        this.blockIndex++;

        this.scene.add(voxel);
        this.objects.push(voxel);
        heightMap.set(positionKey, currentHeight + 1);
      }
    },

    addBlockBorder(block) {
      block.children = block.children.filter(
        (child) => !(child instanceof THREE.LineSegments)
      );
      const edges = new THREE.EdgesGeometry(this.cubeGeo);
      const lineMaterial = new THREE.LineBasicMaterial({
        color: 0x000000,
        linewidth: 1,
      });
      const wireframe = new THREE.LineSegments(edges, lineMaterial);
      block.add(wireframe);
    },

    addEventListener(target, type, listener) {
      const boundListener = listener.bind(this);
      target.addEventListener(type, boundListener);
      this.eventListeners[`${target}_${type}`] = {
        target,
        type,
        listener: boundListener,
      };
    },

    getAllBlockPositions() {
      const blockPositions = [];

      const heightMap = new Map();

      this.objects.forEach((obj, index) => {
        if (
          obj === this.plane ||
          obj === this.previewBlock ||
          obj === this.selectedBlock
        ) {
          return;
        }

        if (obj.geometry && obj.geometry.type === "BoxGeometry") {
          const position = obj.position;

          const gridX = Math.round(
            (position.x - this.gridSize / 2) / this.gridSize
          );
          const gridZ = Math.round(
            (position.z - this.gridSize / 2) / this.gridSize
          );

          const x = gridX + this.gridRange; // -10~10 -> 0~20
          const y = gridZ + this.gridRange; // -10~10 -> 0~20

          const positionKey = `${gridX},${gridZ}`;
          if (!heightMap.has(positionKey)) {
            heightMap.set(positionKey, []);
          }
          heightMap.get(positionKey).push({
            obj: obj,
            worldY: position.y,
            x: x,
            y: y,
          });
        }
      });

      heightMap.forEach((blocks, positionKey) => {
        blocks.sort((a, b) => a.worldY - b.worldY);

        blocks.forEach((blockData, index) => {
          const obj = blockData.obj;

          let blockLetter = "";
          obj.children.forEach((child) => {
            if (child.geometry && child.geometry.type === "TextGeometry") {
              const currentIndex = blockPositions.length;
              blockLetter = String.fromCharCode(65 + currentIndex);
              return;
            }
          });

          if (!blockLetter) {
            const currentIndex = blockPositions.length;
            blockLetter = String.fromCharCode(65 + currentIndex);
          }

          blockPositions.push({
            block: blockLetter,
            x: blockData.x,
            y: blockData.y,
            z: index,
          });
        });
      });

      return blockPositions;
    },

    setAllBlockPositions(blockPositions) {
      const blocksToRemove = [];
      this.objects.forEach((obj) => {
        if (
          obj !== this.plane &&
          obj.geometry &&
          obj.geometry.type === "BoxGeometry"
        ) {
          blocksToRemove.push(obj);
        }
      });

      blocksToRemove.forEach((block) => {
        this.scene.remove(block);
        const index = this.objects.indexOf(block);
        if (index !== -1) {
          this.objects.splice(index, 1);
        }
      });

      this.selectedBlock = null;
      if (this.previewBlock) {
        this.scene.remove(this.previewBlock);
        this.previewBlock = null;
      }

      const heightMap = new Map();

      const sortedPositions = [...blockPositions].sort((a, b) => a.z - b.z);

      sortedPositions.forEach((posData) => {
        const { block, x, y, z } = posData;

        const gridX = x - this.gridRange; // 0~20 -> -10~10
        const gridZ = y - this.gridRange; // 0~20 -> -10~10

        const worldX = gridX * this.gridSize + this.gridSize / 2;
        const worldZ = gridZ * this.gridSize + this.gridSize / 2;

        const worldY = z * this.gridSize + this.gridSize / 2;

        // Add new blocks based on the provided positions
        const voxel = new THREE.Mesh(this.cubeGeo, this.cubeMaterial.clone());
        voxel.position.set(worldX, worldY, worldZ);

        // Add block border
        this.addBlockBorder(voxel);

        // Add letter labels
        this.addTextToAllFaces(voxel, block);

        // Add to scene and objects list
        this.scene.add(voxel);
        this.objects.push(voxel);

        // Update height map
        const positionKey = `${gridX},${gridZ}`;
        heightMap.set(positionKey, (heightMap.get(positionKey) || 0) + 1);
      });
    },

    onWindowResize() {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    },

    // Calculate the grid alignment position
    getGridAlignedPosition(position) {
      const halfSize = this.gridSize / 2;
      const x =
        Math.round(position.x / this.gridSize) * this.gridSize + halfSize;
      const z =
        Math.round(position.z / this.gridSize) * this.gridSize + halfSize;

      // Calculate the appropriate y position (either on the y=0 plane or above existing modules)
      let y = halfSize; // Default y is half a grid size above the y=0 plane (center of the module)

      // Check if there are modules at the given x,z position, if so place on top of the highest module
      const positionKey = `${Math.round(
        (x - halfSize) / this.gridSize
      )},${Math.round((z - halfSize) / this.gridSize)}`;
      let maxY = 0;

      this.objects.forEach((obj) => {
        if (
          obj !== this.plane &&
          obj !== this.previewBlock &&
          obj !== this.selectedBlock
        ) {
          const objXKey = Math.round(
            (obj.position.x - halfSize) / this.gridSize
          );
          const objZKey = Math.round(
            (obj.position.z - halfSize) / this.gridSize
          );
          if (`${objXKey},${objZKey}` === positionKey) {
            if (obj.position.y > maxY) {
              maxY = obj.position.y;
            }
          }
        }
      });

      if (maxY > 0) {
        y = maxY + this.gridSize;
      }

      return new THREE.Vector3(x, y, z);
    },

    onPointerMove(event) {
      this.pointer.set(
        (event.clientX / window.innerWidth) * 2 - 1,
        -(event.clientY / window.innerHeight) * 2 + 1
      );

      this.raycaster.setFromCamera(this.pointer, this.camera);
      this.resetBlockColors();

      const intersects = this.raycaster.intersectObjects(this.objects, false);

      // If there are selected modules and they are not in preview state, the preview body is created
      if (this.selectedBlock && !this.previewBlock) {
        this.previewBlock = this.selectedBlock.clone();
        // Set preview block style (semi-transparent blue)
        this.previewBlock.material = new THREE.MeshLambertMaterial({
          color: 0x0000ff,
          transparent: true,
          opacity: 0.5,
        });
        this.addBlockBorder(this.previewBlock);
        this.scene.add(this.previewBlock);
      }

      // If there is a preview block, update its position
      if (this.previewBlock) {
        if (intersects.length > 0) {
          const intersectPoint = intersects[0].point;
          const alignedPos = this.getGridAlignedPosition(intersectPoint);
          this.previewBlock.position.copy(alignedPos);
        }
      } else if (intersects.length > 0) {
        const intersect = intersects[0];
        if (intersect.object !== this.plane) {
          const currentBlock = intersect.object;
          const blockPosition = currentBlock.position;
          const hasBlockAbove = this.checkBlockAbove(blockPosition);

          if (hasBlockAbove) {
            this.setBlockColor(currentBlock, 0xff0000);
          } else {
            this.setBlockColor(currentBlock, 0x00ff00);
          }
        }
      }
    },

    resetBlockColors() {
      this.objects.forEach((obj) => {
        if (obj !== this.plane && obj.material && obj.material.emissive) {
          obj.material.emissive.setHex(0x000000);
        }
      });
    },

    setBlockColor(block, color) {
      if (block.material && block.material.emissive) {
        block.material.emissive.setHex(color);
      }
    },

    checkBlockAbove(position) {
      const checkY = position.y + this.gridSize;
      return this.objects.some((obj) => {
        if (obj === this.plane) return false;
        const objPos = obj.position;
        return (
          Math.abs(objPos.x - position.x) < 1 &&
          Math.abs(objPos.z - position.z) < 1 &&
          Math.abs(objPos.y - checkY) < 1
        );
      });
    },

    onPointerDown(event) {
      if (event.button !== 0) return;

      this.pointer.set(
        (event.clientX / window.innerWidth) * 2 - 1,
        -(event.clientY / window.innerHeight) * 2 + 1
      );

      this.raycaster.setFromCamera(this.pointer, this.camera);
      const intersects = this.raycaster.intersectObjects(this.objects, false);

      // If you already have the selected module and preview body, move it
      if (this.selectedBlock && this.previewBlock) {
        // Move the selected block to the preview block position
        this.selectedBlock.position.copy(this.previewBlock.position);

        // Remove the preview block
        this.scene.remove(this.previewBlock);
        this.previewBlock = null;

        // Reset selected state style
        this.resetSelectedBlock();
        this.step++;
        // Check if won
        this.showWinDialog();
        return;
      }

      // The selection logic is handled only when a square is clicked
      if (intersects.length > 0 && intersects[0].object !== this.plane) {
        const currentBlock = intersects[0].object;
        const blockPosition = currentBlock.position;
        const hasBlockAbove = this.checkBlockAbove(blockPosition);

        // Reset previous selection state
        this.resetSelectedBlock();

        // Remove any existing preview block
        if (this.previewBlock) {
          this.scene.remove(this.previewBlock);
          this.previewBlock = null;
        }

        if (hasBlockAbove) {
          // Use Vue message to notify
          if (this.$message) this.$message.error("This block cannot be moved");
        } else {
          // Set new selection state
          this.selectBlock(currentBlock);
        }
      }
    },

    onRightClick(event) {
      event.preventDefault();
      this.resetSelectedBlock();
    },

    resetSelectedBlock() {
      if (this.selectedBlock) {
        this.selectedBlock.material = this.cubeMaterial.clone();
        this.addBlockBorder(this.selectedBlock);
        this.selectedBlock = null;
      }

      if (this.previewBlock) {
        this.scene.remove(this.previewBlock);
        this.previewBlock = null;
      }
    },

    selectBlock(block) {
      this.selectedBlock = block;
      const selectedMaterial = new THREE.MeshLambertMaterial({
        color: 0x00ff00,
        transparent: true,
        opacity: 0.5,
      });
      block.material = selectedMaterial;
      this.addBlockBorder(block);
    },

    handleCommand(command) {
      if (command === "restart") {
        // reload
        window.location.reload();
      } else if (command === "gohome") {
        // back to home
        this.$router.push("/main");
      }
    },

    checkWinCondition() {
      if (!this.target || this.target.length === 0) {
        return false;
      }

      const positionGroups = new Map();

      this.objects.forEach((obj) => {
        if (obj === this.plane || obj === this.previewBlock) {
          return;
        }

        if (obj.geometry && obj.geometry.type === "BoxGeometry") {
          const position = obj.position;

          const gridX = Math.round(
            (position.x - this.gridSize / 2) / this.gridSize
          );
          const gridZ = Math.round(
            (position.z - this.gridSize / 2) / this.gridSize
          );
          const posKey = `${gridX},${gridZ}`;

          if (!positionGroups.has(posKey)) {
            positionGroups.set(posKey, []);
          }

          const blockLetter = this.getBlockLetter(obj);

          positionGroups.get(posKey).push({
            obj: obj,
            y: position.y,
            letter: blockLetter,
          });
        }
      });

      for (let [posKey, blocks] of positionGroups) {
        if (blocks.length === this.target.length) {
          blocks.sort((a, b) => a.y - b.y);

          const towerSequence = blocks.map((block) => block.letter).join("");

          const expectedSequence = this.target.split("").reverse().join("");

          if (towerSequence === expectedSequence) {
            return true;
          }
        }
      }

      return false;
    },

    getBlockLetter(blockObj) {
      for (let child of blockObj.children) {
        if (child.geometry && child.geometry.type === "TextGeometry") {
          const objIndex = this.objects.indexOf(blockObj);
          if (objIndex !== -1) {
            let letterIndex = 0;
            for (let i = 0; i < objIndex; i++) {
              if (
                this.objects[i] !== this.plane &&
                this.objects[i].geometry &&
                this.objects[i].geometry.type === "BoxGeometry"
              ) {
                letterIndex++;
              }
            }
            return String.fromCharCode(65 + letterIndex);
          }
          break;
        }
      }
      return "A"; //
    },

    showWinDialog() {
      const isWin = this.checkWinCondition();

      if (isWin) {
        this.$refs.confetti.fire();
        this.$confirm(
          "Congratulations on completing the challenge! Do you want to start over or go back to the home page?",
          "Victory!",
          {
            confirmButtonText: "Restart",
            cancelButtonText: "Go Home",
            type: "success",
          }
        )
          .then(() => {
            window.location.reload();
          })
          .catch(() => {
            this.$router.push("/main");
          });
      }
    },

    animate() {
      this.animationId = requestAnimationFrame(this.animate.bind(this));
      this.controls.update();
      this.renderer.render(this.scene, this.camera);
    },
  },
};
</script>

<style lang="scss" scoped>
.bigScene {
  width: 100%;
  height: 100vh;
  position: relative;
  overflow: hidden;
  .header {
    position: absolute;
    top: 0;
    left: 0;
    height: 2.5rem;
    background-color: rgb(231, 231, 231);
    box-shadow: 0px 0px 3px black;
    display: flex;
    align-items: center;
    color: rgb(0, 124, 195);
    font-size: 0.875rem;
    padding-left: 1rem;
    width: 100%;
    span {
      margin-right: 2rem;
    }
    .control {
      position: absolute;
      width: auto;
      height: 100%;
      display: flex;
      align-items: center;
      font-size: 1rem;
      top: 0;
      right: 1rem;
    }
  }
}

#info {
  position: absolute;
  top: 10px;
  left: 10px;
  z-index: 100;
  color: #444;
  font-family: sans-serif;
  background: rgba(255, 255, 255, 0.8);
  padding: 8px 12px;
  border-radius: 4px;

  a {
    color: #08f;
    text-decoration: none;
  }
}
.oneTarget {
  position: absolute;
  top: 3.5rem;
  left: 1rem;
  width: 2.5rem;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  .oneTargetBlock {
    width: 2.5rem;
    height: 2.5rem;
    background-color: rgb(255, 255, 255);
    box-shadow: 0px 0px 3px black;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    color: rgb(0, 124, 195);
    font-weight: bold;
  }
}
</style>
