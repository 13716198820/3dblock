<template>
  <div>
    <h1 align="center">{{ errorMsg }}</h1>
  </div>
</template>
<script>
export default {
  data() {
    return {
      errorMsg: "Error!",
    };
  },
  mounted() {
    this.errorMsg =
      this.$route.query.errorMsg ||
      "Single sign-on expired, please contact the administrator";
  },
};
</script>
