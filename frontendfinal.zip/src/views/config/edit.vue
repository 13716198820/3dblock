<template>
  <el-dialog
    title="Config"
    :visible.sync="configDialogVisible"
    :close-on-click-modal="false"
    width="420px"
  >
    <el-form
      ref="configFormRef"
      :model="configForm"
      :rules="configRules"
      label-width="120px"
      size="mini"
    >
      <el-form-item label="Name" prop="playerName">
        <el-input
          v-model="configForm.playerName"
          placeholder="Enter player name"
          maxlength="16"
          style="width: 100%"
        />
      </el-form-item>
      <el-form-item label="Block Amount" prop="blockAmount">
        <el-select
          v-model="configForm.blockAmount"
          placeholder="Select block amount"
          style="width: 100%"
        >
          <el-option label="5" :value="5" />
          <el-option label="6" :value="6" />
          <el-option label="7" :value="7" />
        </el-select>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="closeDialog" style="margin-right: 0.625rem"
        >Cancel</el-button
      >
      <el-button type="primary" @click="saveConfig">Save</el-button>
    </div>
  </el-dialog>
</template>
<script>
export default {
  name: "ConfigEdit",
  data() {
    return {
      configDialogVisible: false,
      configForm: {
        playerName: "",
        blockAmount: 6,
      },
      configRules: {
        playerName: [
          {
            required: true,
            message: "Player name is required",
            trigger: "blur",
          },
          { min: 1, max: 16, message: "Length 1 to 16", trigger: "blur" },
        ],
        blockAmount: [
          {
            required: true,
            message: "Block amount is required",
            trigger: "change",
          },
          {
            validator: (rule, value, callback) => {
              if (value < 5 || value > 7) {
                callback(new Error("Block amount must be between 5 and 7"));
              } else {
                callback();
              }
            },
            trigger: "change",
          },
        ],
      },
    };
  },
  methods: {
    open() {
      this.loadConfig();
      this.configDialogVisible = true;
    },
    loadConfig() {
      const storedName = localStorage.getItem("playerName");
      const storedAmount = localStorage.getItem("initialBlockAmount");
      if (storedName) this.configForm.playerName = storedName;
      if (storedAmount) this.configForm.blockAmount = Number(storedAmount);
    },
    saveConfig() {
      this.$refs.configFormRef.validate((valid) => {
        if (!valid) return;
        localStorage.setItem("playerName", this.configForm.playerName.trim());
        localStorage.setItem(
          "blocksamount",
          String(this.configForm.blockAmount)
        );
        this.$message && this.$message.success("Configuration saved");
        this.closeDialog();
      });
    },
    closeDialog() {
      this.configDialogVisible = false;
    },
  },
};
</script>
