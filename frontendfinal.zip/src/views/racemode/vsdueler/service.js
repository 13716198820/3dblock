import request from "@/utils/request";

export function setPostionstoBackEnd(data) {
  return request({
    url: "/set-dueler-block-position",
    method: "post",
    data,
  });
}
export function getPostionsfromBackEnd(params) {
  return request({
    url: "/get-dueler-block-position",
    method: "get",
    params: params,
  });
}

export function getNextMove(data) {
  return request({
    url: "/get-next-move",
    method: "post",
    data,
  });
}

export function initPos(params) {
  return request({
    url: "/init-dueler-position",
    method: "get",
    params: params,
  });
}

export function cancel(data) {
  return request({
    url: "/cancel-game",
    method: "post",
    data,
  });
}
