<template>
  <div class="bigSceneHolder">
    <div class="control">
      <el-dropdown trigger="click" @command="handleCommand">
        <el-button icon="el-icon-s-tools" circle></el-button>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="gohome">Gohome</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
    <!-- <div id="info">
      <a href="https://threejs.org" target="_blank" rel="noopener">three.js</a>
      - voxel painter - webgl<br />
      <strong>click</strong>: select voxel, <strong>shift + click</strong>:
      remove voxel<br />
      <strong>right click</strong>: deselect all, <strong>mouse drag</strong>:
      rotate view, <strong>mouse wheel</strong>: zoom<br />
      <strong>select + drag + click</strong>: move voxel
    </div> -->

    <div class="playground host">
      <iframe
        width="100%"
        height="100%"
        frameborder="0"
        scrolling="false"
        :src="src1"
      ></iframe>
    </div>
    <div class="playground join">
      <div class="playground-cover">
        <i class="el-icon-coffee-cup"></i> Dueler
      </div>
      <iframe
        width="100%"
        height="100%"
        frameborder="0"
        scrolling="false"
        :src="src2"
      ></iframe>
    </div>
    <Confetti ref="confetti" />
  </div>
</template>

<script>
import { cancel } from "./service";
import Confetti from "@/components/Confetti/index.vue";
/* eslint-disable */
export default {
  name: "home",
  components: { Confetti },
  data() {
    return {
      type: "",
      src1: "",
      src2: "",
    };
  },

  mounted() {
    let type = this.$route.query.type;
    this.type = type;

    const fullUrl = window.location.href;

    if (fullUrl.includes("?")) {
      const queryString = fullUrl.split("?")[1];
      let src1 = "#/oneplayerraceduler?" + queryString;
      let src2 = "#/oneplayerraceduler?" + queryString;

      src1 += "&type=player";

      src2 += "&for=display&type=dueler";

      this.src1 = src1;
      this.src2 = src2;
    }

    window.addEventListener("message", this.handleMessage);
  },

  beforeDestroy() {
    window.removeEventListener("message", this.handleMessage);
  },

  methods: {
    handleMessage(event) {
      if (event.data && event.data.type === "showWinDialog") {
        this.showWinDialog(event.data.message);
      }
    },
    handleCommand(command) {
      if (command === "gohome") {
        cancel({
          gameid: this.$route.query.gameId,
        }).then(() => {
          this.$router.push("/main");
        });
      }
    },

    showWinDialog(txt) {
      this.$refs.confetti.fire();
      this.$alert(txt, "Notice", {
        confirmButtonText: "OK",
        callback: () => {
          cancel({
            gameid: this.$route.query.gameId,
          }).then(() => {
            this.$router.push("/main");
          });
        },
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.bigSceneHolder {
  width: 100%;
  height: 100vh;
  position: relative;
  overflow: hidden;
  .playground {
    width: calc(50% - 0.5rem - 0.25rem);
    height: calc(100% - 1rem);
    float: left;
    position: relative;
    margin-top: 0.5rem;

    &.host {
      border: 1px solid rgb(0, 124, 195);
      margin-right: 0.5rem;
      margin-left: 0.5rem;
    }
    &.join {
      border: 1px solid rgb(195, 0, 124);
    }

    .playground-cover {
      width: 100%;
      height: 100%;
      position: absolute;
      z-index: 1;
      background-color: rgba(0, 0, 0, 0.3);

      left: 0;
      top: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 1rem;
      color: white;
      i {
        font-size: 1.875rem;
        margin-right: 0.5rem;
      }
    }
  }
}
.control {
  position: absolute;
  width: auto;
  display: flex;
  align-items: center;
  font-size: 1rem;
  top: 1rem;
  right: 1rem;
  z-index: 100;
}
</style>
