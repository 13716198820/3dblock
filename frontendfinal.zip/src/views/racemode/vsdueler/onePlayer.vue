<template>
  <div class="bigScene" ref="sceneContainer">
    <div class="header">
      <div class="player" :class="player.type === 'participants' ? 'p2' : ''">
        <span>Name: &nbsp;{{ player.name }}</span>
        <span>Steps:&nbsp; {{ player.step }}</span>
        <span style="display: none"
          >Target:&nbsp;{{ player.target }}
          <sup style="font-weight: bold">(Up to Down)</sup></span
        >
      </div>
      <div class="oneTarget">
        <div
          class="oneTargetBlock"
          v-for="(item, index) in player.target.split('')"
          :key="index"
        >
          {{ item }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { FontLoader } from "three/examples/jsm/loaders/FontLoader.js";
import { TextGeometry } from "three/examples/jsm/geometries/TextGeometry.js";
import {
  setPostionstoBackEnd,
  getPostionsfromBackEnd,
  initPos,
  getNextMove,
  cancel,
} from "./service";
import { isEqual } from "lodash-es";
export default {
  name: "home",
  components: {},
  data() {
    return {
      player: {
        name: "",
        step: 0,
        target: "",
        type: "",
        userid: "",
      },
      blocksamount: 0,
      camera: null,
      scene: null,
      renderer: null,
      plane: null,
      pointer: null,
      raycaster: null,
      isShiftDown: false,
      cubeGeo: null,
      cubeMaterial: null,
      objects: [],
      eventListeners: {},
      controls: null,
      animationId: null,
      gridSize: 50,
      gridRange: 10,
      font: null,
      blockIndex: 0,
      selectedBlock: null,
      previewBlock: null,
      isDragging: false,
      resizeObserver: null,
      fordisplay: "",
      timer: null,
      dulerStep: 0,
      winDialogShown: false,
    };
  },

  mounted() {
    this.getParams();
    this.init();
    // this.getOppoMovement();
  },

  beforeDestroy() {
    Object.values(this.eventListeners).forEach(({ target, type, listener }) => {
      target.removeEventListener(type, listener);
    });

    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }

    if (this.controls) {
      this.controls.dispose();
    }

    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }

    if (this.renderer) {
      this.renderer.dispose();
    }
    if (this.timer) {
      clearInterval(this.timer);
    }
  },

  methods: {
    showWinDialog(txt) {
      if (window.parent) {
        window.parent.postMessage(
          {
            type: "showWinDialog",
            message: txt,
          },
          "*"
        );
      }
    },
    getOppoMovement() {
      if (this.fordisplay === "display") {
        getNextMove({
          blocks: this.player.target.length,
          positions: this.getAllBlockPositions(),
          target: this.player.target,
          gameid: this.$route.query.gameId,
        }).then((res) => {
          this.player.step = 0;
          this.dulerStep = res.data.steps;
          this.winDialogShown = false;
          for (let i = 0; i < this.dulerStep.length; i++) {
            setTimeout(() => {
              this.setAllBlockPositions(this.dulerStep[i]);
              this.player.step++;
              if (!this.winDialogShown && this.checkWinCondition()) {
                this.winDialogShown = true;
                this.showWinDialog("Dueler wins!");
              }
            }, i * 1000);
          }
        });
      }
    },

    getBlockLetter(block) {
      return block?.userData?.blockLetter || "";
    },

    checkWinCondition() {
      if (!this.player.target || this.player.target.length === 0) {
        return false;
      }

      const positionGroups = new Map();

      this.objects.forEach((obj) => {
        if (obj === this.plane || obj === this.previewBlock) {
          return;
        }

        if (obj.geometry && obj.geometry.type === "BoxGeometry") {
          const position = obj.position;
          const gridX = Math.round(
            (position.x - this.gridSize / 2) / this.gridSize
          );
          const gridZ = Math.round(
            (position.z - this.gridSize / 2) / this.gridSize
          );
          const posKey = `${gridX},${gridZ}`;

          if (!positionGroups.has(posKey)) {
            positionGroups.set(posKey, []);
          }

          const blockLetter = this.getBlockLetter(obj);

          positionGroups.get(posKey).push({
            obj: obj,
            y: position.y,
            letter: blockLetter,
          });
        }
      });

      for (let [, blocks] of positionGroups) {
        if (blocks.length === this.player.target.length) {
          blocks.sort((a, b) => a.y - b.y);
          const towerSequence = blocks.map((block) => block.letter).join("");
          const expectedSequence = this.player.target
            .split("")
            .reverse()
            .join("");

          if (towerSequence === expectedSequence) {
            return true;
          }
        }
      }

      return false;
    },

    comparePositions(oldPositions, newPositions) {
      if (!oldPositions || !newPositions) return false;
      if (oldPositions.length !== newPositions.length) return true;

      const sortFn = (a, b) => {
        if (a.block !== b.block)
          return a.block.charCodeAt(0) - b.block.charCodeAt(0);
        if (a.x !== b.x) return a.x - b.x;
        if (a.y !== b.y) return a.y - b.y;
        return a.z - b.z;
      };

      const sortedOld = [...oldPositions].sort(sortFn);
      const sortedNew = [...newPositions].sort(sortFn);

      return !isEqual(sortedOld, sortedNew);
    },
    getParams() {
      const query = this.$route.query;

      this.player.type = query.type;

      this.fordisplay = query.for;
      let infor;
      this.blocksamount = JSON.parse(query.host).blocksamount;
      this.player.target = query.target;

      if (this.fordisplay === "display") {
        infor = JSON.parse(query.host);
        this.player.name = "Dueler";
        return;
      }

      if (this.player.type === "player") {
        infor = JSON.parse(query.host);
        this.player.name = infor.name;
      }

      this.player.step = 0;
    },

    checkIfInIframe() {
      try {
        return window !== window.top;
      } catch (e) {
        return true;
      }
    },

    init() {
      const container = this.$refs.sceneContainer;
      const width = container.clientWidth;
      const height = container.clientHeight;

      this.camera = new THREE.PerspectiveCamera(45, width / height, 1, 10000);
      this.camera.position.set(500, 800, 1300);
      this.camera.lookAt(0, 0, 0);

      this.scene = new THREE.Scene();
      this.scene.background = new THREE.Color(0xf0f0f0);

      this.cubeGeo = new THREE.BoxGeometry(
        this.gridSize,
        this.gridSize,
        this.gridSize
      );
      this.cubeMaterial = new THREE.MeshLambertMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.95,
      });

      const gridHelper = new THREE.GridHelper(1000, 20);
      this.scene.add(gridHelper);

      this.raycaster = new THREE.Raycaster();
      this.pointer = new THREE.Vector2();

      const geometry = new THREE.PlaneGeometry(1000, 1000);
      geometry.rotateX(-Math.PI / 2);

      this.plane = new THREE.Mesh(
        geometry,
        new THREE.MeshBasicMaterial({ visible: false })
      );
      this.scene.add(this.plane);
      this.objects.push(this.plane);

      const ambientLight = new THREE.AmbientLight(0x606060, 3);
      this.scene.add(ambientLight);

      const directionalLight = new THREE.DirectionalLight(0xffffff, 3);
      directionalLight.position.set(1, 0.75, 0.5).normalize();
      this.scene.add(directionalLight);

      this.renderer = new THREE.WebGLRenderer({ antialias: true });
      this.renderer.setPixelRatio(window.devicePixelRatio);
      this.renderer.setSize(width, height);
      this.$refs.sceneContainer.appendChild(this.renderer.domElement);

      this.controls = new OrbitControls(this.camera, this.renderer.domElement);
      this.controls.enableDamping = true;
      this.controls.dampingFactor = 0.05;
      this.controls.enableZoom = true;
      this.controls.zoomSpeed = 0.5;
      this.controls.enableRotate = true;
      this.controls.rotateSpeed = 0.5;
      this.controls.enablePan = false;

      const isInIframe = this.checkIfInIframe();

      if (isInIframe) {
        this.addEventListener(document, "pointermove", this.onPointerMove);
        this.addEventListener(document, "pointerdown", this.onPointerDown);
        this.addEventListener(document, "keydown", this.onDocumentKeyDown);
        this.addEventListener(document, "keyup", this.onDocumentKeyUp);
        this.addEventListener(window, "resize", this.onWindowResize);

        this.addEventListener(document, "contextmenu", this.onRightClick);

        if (window.ResizeObserver) {
          this.resizeObserver = new ResizeObserver(() => {
            this.onWindowResize();
          });
          this.resizeObserver.observe(container);
        }
      } else {
      }

      this.loadFont().then(() => {
        getPostionsfromBackEnd({
          gameid: this.$route.query.gameId,
          type: this.player.type,
        }).then((res) => {
          if (!res.data.positions || res.data.positions.length === 0) {
            initPos({
              gameid: this.$route.query.gameId,
              type: this.player.type,
            }).then((res) => {
              this.step = res.data.step;
              this.setAllBlockPositions(res.data.positions);
              this.getOppoMovement();
              // this.setPostionstoSever();
            });

            // this.generateRandomBlocks(this.blocksamount);
          } else {
            this.setAllBlockPositions(res.data.positions);
            this.step = res.data.step;
          }
        });

        // console.log(this.getAllBlockPositions());
        // setTimeout(() => {
        //   this.setAllBlockPositions([
        //     { block: "A", x: 1, y: 17, z: 0 },
        //     { block: "B", x: 7, y: 17, z: 0 },
        //     { block: "C", x: 0, y: 13, z: 0 },
        //   ]);
        // }, 1000);
      });

      this.animate();
    },
    setPostionstoSever() {
      const blockPositions = this.getAllBlockPositions();
      setPostionstoBackEnd({
        gameid: this.$route.query.gameId,
        type: this.player.type,
        positions: blockPositions,
        step: this.player.step,
      }).then((res) => {
        if (res.data.win) {
          this.showWinDialog("Congratulations on your victory!");
        }
      });
    },

    loadFont() {
      return new Promise((resolve) => {
        const loader = new FontLoader();
        loader.load(
          "/fonts/helvetiker_regular.typeface.json",
          (font) => {
            this.font = font;
            resolve();
          },
          undefined,
          (error) => {
            console.warn("Font loading failed, using default font", error);
            resolve();
          }
        );
      });
    },

    addTextToAllFaces(cube, letter) {
      if (!this.font) return;

      cube.userData.blockLetter = letter;

      const textGeometry = new TextGeometry(letter, {
        font: this.font,
        size: 20,
        height: 1,
        curveSegments: 12,
        bevelEnabled: false,
      });

      textGeometry.computeBoundingBox();
      const textWidth =
        textGeometry.boundingBox.max.x - textGeometry.boundingBox.min.x;
      const textHeight =
        textGeometry.boundingBox.max.y - textGeometry.boundingBox.min.y;

      const textMaterial = new THREE.MeshLambertMaterial({ color: 0x000000 });

      const faces = [
        {
          position: [0, 0, this.gridSize / 2 + 1],
          rotation: [0, 0, 0],
          offset: [-textWidth / 2, -textHeight / 2, 0],
        },
      ];

      faces.forEach((face) => {
        const textMesh = new THREE.Mesh(
          textGeometry.clone(),
          textMaterial.clone()
        );
        textMesh.position.set(...face.position);
        textMesh.rotation.set(...face.rotation);
        textMesh.position.x += face.offset[0];
        textMesh.position.y += face.offset[1];
        textMesh.position.z += face.offset[2];
        textMesh.scale.set(1, 1, 0.005);
        cube.add(textMesh);
      });
    },

    generateRandomBlocks(count) {
      const heightMap = new Map();

      for (let i = 0; i < count; i++) {
        const gridX =
          Math.floor(Math.random() * (this.gridRange * 2)) - this.gridRange;
        const gridZ =
          Math.floor(Math.random() * (this.gridRange * 2)) - this.gridRange;
        const positionKey = `${gridX},${gridZ}`;
        const currentHeight = heightMap.get(positionKey) || 0;

        const x = gridX * this.gridSize + this.gridSize / 2;
        const z = gridZ * this.gridSize + this.gridSize / 2;
        const y = currentHeight * this.gridSize + this.gridSize / 2;

        const voxel = new THREE.Mesh(this.cubeGeo, this.cubeMaterial.clone());
        voxel.position.set(x, y, z);
        this.addBlockBorder(voxel);

        const letter = String.fromCharCode(65 + this.blockIndex);
        this.addTextToAllFaces(voxel, letter);
        this.blockIndex++;

        this.scene.add(voxel);
        this.objects.push(voxel);
        heightMap.set(positionKey, currentHeight + 1);
      }
    },

    addBlockBorder(block) {
      block.children = block.children.filter(
        (child) => !(child instanceof THREE.LineSegments)
      );
      const edges = new THREE.EdgesGeometry(this.cubeGeo);
      const lineMaterial = new THREE.LineBasicMaterial({
        color: 0x000000,
        linewidth: 1,
      });
      const wireframe = new THREE.LineSegments(edges, lineMaterial);
      block.add(wireframe);
    },

    addEventListener(target, type, listener) {
      const boundListener = listener.bind(this);
      target.addEventListener(type, boundListener);
      this.eventListeners[`${target}_${type}`] = {
        target,
        type,
        listener: boundListener,
      };
    },

    getAllBlockPositions() {
      const blockPositions = [];

      const heightMap = new Map();

      this.objects.forEach((obj, index) => {
        if (
          obj === this.plane ||
          obj === this.previewBlock ||
          obj === this.selectedBlock
        ) {
          return;
        }

        if (obj.geometry && obj.geometry.type === "BoxGeometry") {
          const position = obj.position;

          const gridX = Math.round(
            (position.x - this.gridSize / 2) / this.gridSize
          );
          const gridZ = Math.round(
            (position.z - this.gridSize / 2) / this.gridSize
          );

          const x = gridX + this.gridRange; // -10~10 -> 0~20
          const y = gridZ + this.gridRange; // -10~10 -> 0~20

          const blockLetter = obj.userData.blockLetter || "";

          const positionKey = `${gridX},${gridZ}`;
          if (!heightMap.has(positionKey)) {
            heightMap.set(positionKey, []);
          }
          heightMap.get(positionKey).push({
            obj: obj,
            worldY: position.y,
            x: x,
            y: y,
            letter: blockLetter,
          });
        }
      });

      heightMap.forEach((blocks, positionKey) => {
        blocks.sort((a, b) => a.worldY - b.worldY);

        blocks.forEach((blockData, index) => {
          blockPositions.push({
            block: blockData.letter,
            x: blockData.x,
            y: blockData.y,
            z: index,
          });
        });
      });

      return blockPositions;
    },

    setAllBlockPositions(blockPositions) {
      const blocksToRemove = [];
      this.objects.forEach((obj) => {
        if (
          obj !== this.plane &&
          obj.geometry &&
          obj.geometry.type === "BoxGeometry"
        ) {
          blocksToRemove.push(obj);
        }
      });

      blocksToRemove.forEach((block) => {
        this.scene.remove(block);
        const index = this.objects.indexOf(block);
        if (index !== -1) {
          this.objects.splice(index, 1);
        }
      });

      this.selectedBlock = null;
      if (this.previewBlock) {
        this.scene.remove(this.previewBlock);
        this.previewBlock = null;
      }

      const heightMap = new Map();

      const sortedPositions = [...blockPositions].sort((a, b) => a.z - b.z);

      sortedPositions.forEach((posData) => {
        const { block, x, y, z } = posData;

        const gridX = x - this.gridRange; // 0~20 -> -10~10
        const gridZ = y - this.gridRange; // 0~20 -> -10~10

        const worldX = gridX * this.gridSize + this.gridSize / 2;
        const worldZ = gridZ * this.gridSize + this.gridSize / 2;

        const worldY = z * this.gridSize + this.gridSize / 2;

        const voxel = new THREE.Mesh(this.cubeGeo, this.cubeMaterial.clone());
        voxel.position.set(worldX, worldY, worldZ);

        this.addBlockBorder(voxel);

        this.addTextToAllFaces(voxel, block);

        this.scene.add(voxel);
        this.objects.push(voxel);

        const positionKey = `${gridX},${gridZ}`;
        heightMap.set(positionKey, (heightMap.get(positionKey) || 0) + 1);
      });
    },

    onWindowResize() {
      const container = this.$refs.sceneContainer;
      if (container) {
        const width = container.clientWidth;
        const height = container.clientHeight;

        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(width, height);
      }
    },

    getGridAlignedPosition(position) {
      const halfSize = this.gridSize / 2;
      const x =
        Math.round(position.x / this.gridSize) * this.gridSize + halfSize;
      const z =
        Math.round(position.z / this.gridSize) * this.gridSize + halfSize;

      let y = halfSize;

      const positionKey = `${Math.round(
        (x - halfSize) / this.gridSize
      )},${Math.round((z - halfSize) / this.gridSize)}`;
      let maxY = 0;

      this.objects.forEach((obj) => {
        if (
          obj !== this.plane &&
          obj !== this.previewBlock &&
          obj !== this.selectedBlock
        ) {
          const objXKey = Math.round(
            (obj.position.x - halfSize) / this.gridSize
          );
          const objZKey = Math.round(
            (obj.position.z - halfSize) / this.gridSize
          );
          if (`${objXKey},${objZKey}` === positionKey) {
            if (obj.position.y > maxY) {
              maxY = obj.position.y;
            }
          }
        }
      });

      if (maxY > 0) {
        y = maxY + this.gridSize;
      }

      return new THREE.Vector3(x, y, z);
    },

    onPointerMove(event) {
      const canvas = this.renderer.domElement;
      const rect = canvas.getBoundingClientRect();

      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;

      this.pointer.set((x / rect.width) * 2 - 1, -(y / rect.height) * 2 + 1);

      this.raycaster.setFromCamera(this.pointer, this.camera);
      this.resetBlockColors();

      const intersects = this.raycaster.intersectObjects(this.objects, false);

      if (this.selectedBlock && !this.previewBlock) {
        this.previewBlock = this.selectedBlock.clone();

        this.previewBlock.material = new THREE.MeshLambertMaterial({
          color: 0x0000ff,
          transparent: true,
          opacity: 0.5,
        });
        this.addBlockBorder(this.previewBlock);
        this.scene.add(this.previewBlock);
      }

      if (this.previewBlock) {
        if (intersects.length > 0) {
          const intersectPoint = intersects[0].point;
          const alignedPos = this.getGridAlignedPosition(intersectPoint);
          this.previewBlock.position.copy(alignedPos);
        }
      } else if (intersects.length > 0) {
        const intersect = intersects[0];
        if (intersect.object !== this.plane) {
          const currentBlock = intersect.object;
          const blockPosition = currentBlock.position;
          const hasBlockAbove = this.checkBlockAbove(blockPosition);

          if (hasBlockAbove) {
            this.setBlockColor(currentBlock, 0xff0000);
          } else {
            this.setBlockColor(currentBlock, 0x00ff00);
          }
        }
      }
    },

    resetBlockColors() {
      this.objects.forEach((obj) => {
        if (obj !== this.plane && obj.material && obj.material.emissive) {
          obj.material.emissive.setHex(0x000000);
        }
      });
    },

    setBlockColor(block, color) {
      if (block.material && block.material.emissive) {
        block.material.emissive.setHex(color);
      }
    },

    checkBlockAbove(position) {
      const checkY = position.y + this.gridSize;
      return this.objects.some((obj) => {
        if (obj === this.plane) return false;
        const objPos = obj.position;
        return (
          Math.abs(objPos.x - position.x) < 1 &&
          Math.abs(objPos.z - position.z) < 1 &&
          Math.abs(objPos.y - checkY) < 1
        );
      });
    },

    onPointerDown(event) {
      if (event.button !== 0) return;

      const canvas = this.renderer.domElement;
      const rect = canvas.getBoundingClientRect();

      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;

      this.pointer.set((x / rect.width) * 2 - 1, -(y / rect.height) * 2 + 1);

      this.raycaster.setFromCamera(this.pointer, this.camera);
      const intersects = this.raycaster.intersectObjects(this.objects, false);

      if (this.isShiftDown) {
        if (intersects.length > 0 && intersects[0].object !== this.plane) {
          this.scene.remove(intersects[0].object);
          const index = this.objects.indexOf(intersects[0].object);
          if (index !== -1) {
            this.objects.splice(index, 1);
          }
          if (this.selectedBlock === intersects[0].object) {
            this.selectedBlock = null;

            if (this.previewBlock) {
              this.scene.remove(this.previewBlock);
              this.previewBlock = null;
            }
          }
        }
        return;
      }

      if (this.selectedBlock && this.previewBlock) {
        this.selectedBlock.position.copy(this.previewBlock.position);

        this.scene.remove(this.previewBlock);
        this.previewBlock = null;

        this.resetSelectedBlock();
        this.player.step++;
        this.setPostionstoSever();
        return;
      }

      if (intersects.length > 0 && intersects[0].object !== this.plane) {
        const currentBlock = intersects[0].object;
        const blockPosition = currentBlock.position;
        const hasBlockAbove = this.checkBlockAbove(blockPosition);

        this.resetSelectedBlock();

        if (this.previewBlock) {
          this.scene.remove(this.previewBlock);
          this.previewBlock = null;
        }

        if (hasBlockAbove) {
          if (this.$message) this.$message.error("cannot move this block");
        } else {
          this.selectBlock(currentBlock);
        }
      }
    },

    onRightClick(event) {
      event.preventDefault();
      this.resetSelectedBlock();
    },

    resetSelectedBlock() {
      if (this.selectedBlock) {
        this.selectedBlock.material = this.cubeMaterial.clone();
        this.addBlockBorder(this.selectedBlock);
        this.selectedBlock = null;
      }

      if (this.previewBlock) {
        this.scene.remove(this.previewBlock);
        this.previewBlock = null;
      }
    },

    selectBlock(block) {
      this.selectedBlock = block;
      const selectedMaterial = new THREE.MeshLambertMaterial({
        color: 0x00ff00,
        transparent: true,
        opacity: 0.5,
      });
      block.material = selectedMaterial;
      this.addBlockBorder(block);
    },

    onDocumentKeyDown(event) {
      if (event.keyCode === 16) {
        this.isShiftDown = true;
      }
    },

    onDocumentKeyUp(event) {
      if (event.keyCode === 16) {
        this.isShiftDown = false;
      }
    },

    animate() {
      this.animationId = requestAnimationFrame(this.animate.bind(this));
      this.controls.update();
      this.renderer.render(this.scene, this.camera);
    },
  },
};
</script>

<style lang="scss" scoped>
.bigScene {
  width: 100%;
  height: 100vh;
  position: relative;
  overflow: hidden;

  &:fullscreen {
    width: 100vw;
    height: 100vh;
  }
  .header {
    position: absolute;
    top: 0;
    left: 0;
    height: 2.5rem;
    background-color: rgb(231, 231, 231);
    box-shadow: 0px 0px 3px black;
    display: flex;
    align-items: center;
    color: rgb(0, 124, 195);
    font-size: 0.875rem;
    padding-left: 1rem;
    width: 100%;
    .player {
      width: 50%;
      height: 100%;
      float: left;
      display: flex;
      align-items: center;
    }
    .p2 {
      color: red;
    }
    span {
      margin-right: 2rem;
    }
    .control {
      position: absolute;
      width: auto;
      height: 100%;
      display: flex;
      align-items: center;
      font-size: 1rem;
      top: 0;
      right: 1rem;
    }
  }
}

#info {
  position: absolute;
  top: 10px;
  left: 10px;
  z-index: 100;
  color: #444;
  font-family: sans-serif;
  background: rgba(255, 255, 255, 0.8);
  padding: 8px 12px;
  border-radius: 4px;

  a {
    color: #08f;
    text-decoration: none;
  }
}
.oneTarget {
  position: absolute;
  top: 3.5rem;
  left: 1rem;
  width: 2.5rem;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  .oneTargetBlock {
    width: 2.5rem;
    height: 2.5rem;
    background-color: rgb(255, 255, 255);
    box-shadow: 0px 0px 3px black;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    color: rgb(0, 124, 195);
    font-weight: bold;
  }
}
</style>
