import request from "@/utils/request";

export function setPostionstoBackEnd(data) {
  return request({
    url: "/set-block-position",
    method: "post",
    data,
  });
}
export function getPostionsfromBackEnd(params) {
  return request({
    url: "/get-block-position",
    method: "get",
    params: params,
  });
}
export function initPos(params) {
  return request({
    url: "/init-position",
    method: "get",
    params: params,
  });
}
export function cancel(data) {
  return request({
    url: "/cancel-game",
    method: "post",
    data,
  });
}
