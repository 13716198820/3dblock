<template>
  <div class="game-room">
    <el-dialog
      title="Game Hall"
      :visible.sync="hallDialogVisible"
      :close-on-click-modal="false"
      width="800px"
      @opened="loadGameHall"
    >
      <el-table
        :data="gameList"
        v-loading="loading"
        style="width: 100%"
        :empty-text="'No games available'"
      >
        <el-table-column prop="creator" label="Name"> </el-table-column>

        <el-table-column prop="game_id" label="Game ID"> </el-table-column>
        <el-table-column prop="mode" label="Mode"> </el-table-column>

        <el-table-column prop="blocksamount" label="Blocks Amount">
        </el-table-column>
        <el-table-column prop="status" label="Status">
          <template slot-scope="scope">
            <el-tag
              :type="scope.row.status === 'waiting' ? 'success' : 'info'"
              size="small"
            >
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column label="Operate" width="120">
          <template slot-scope="scope">
            <el-button
              type="primary"
              size="mini"
              :disabled="scope.row.status !== 'waiting'"
              @click="joinGame(scope.row)"
            >
              Join
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div slot="footer" class="dialog-footer">
        <el-button @click="hallDialogVisible = false" style="margin-right: 10px"
          >Close</el-button
        >
        <el-button type="primary" @click="refreshGameHall">Refresh</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getHallAPI, joinGameAPI } from "./service";

export default {
  name: "GameRoom",
  data() {
    return {
      hallDialogVisible: false,
      loading: false,
      gameList: [],
      userid: "",
      gameMode: "race",
    };
  },
  methods: {
    open(userid, mode = "race") {
      this.userid = userid;
      this.gameMode = mode;
      this.hallDialogVisible = true;
      this.loadGameHall();
    },
    loadGameHall() {
      this.loading = true;

      getHallAPI().then((response) => {
        this.gameList = response.data || [];
        this.loading = false;
      });
    },

    refreshGameHall() {
      this.loadGameHall();
      this.$message.success("Game hall refreshed");
    },

    joinGame(game) {
      const playerName = localStorage.getItem("playerName");
      if (!playerName) {
        this.$message.error("Player name not found, please restart the game");
        return;
      }
      joinGameAPI({
        gameid: game.game_id,
        playerName: playerName,
        userid: this.userid,
      }).then((res) => {
        this.$message.success(`Successfully joined game ${game.game_id}`);
        console.log("Join game response:", res.data);

        // Jump to different pages depending on the game mode
        if (this.gameMode === "vsmode") {
          // VS mode
          this.$router.push({
            path: "/vsvsplayer",
            query: {
              gameId: res.data.game_id,
              host: JSON.stringify({
                name: game.creator,
                blocksamount: game.blocksamount,
              }),
              participants: JSON.stringify(res.data.participant),
              type: "participants",
              targetHost: res.data.target_host,
              targetParticipant: res.data.target_participant,
            },
          });
        } else {
          // Race
          this.$router.push({
            path: "/racevsplayer",
            query: {
              gameId: res.data.game_id,
              host: JSON.stringify({
                name: game.creator,
                blocksamount: game.blocksamount,
              }),
              participants: JSON.stringify(res.data.participant),
              type: "participants",
              target: res.data.target,
            },
          });
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.game-room {
  .dialog-footer {
    text-align: right;
  }
}
</style>
