<template>
  <div class="bigScene" ref="sceneContainer">
    <div class="menu">
      <div class="logo"></div>
      <el-button type="primary" round style="width: 100%" @click="goSingle"
        >SINGLE PLAY</el-button
      >
      <P>Race mode</P>
      <el-button
        type="success"
        round
        style="width: 100%; margin-bottom: 0.5rem"
        @click="handleVsPlayer"
        >VS PLAYER</el-button
      >
      <el-button type="danger" round style="width: 100%" @click="handleVsDueler"
        >VS Dueler</el-button
      >
      <P>VS mode</P>
      <el-button
        type="success"
        round
        style="width: 100%; margin-bottom: 0.5rem"
        @click="handleVsModeVsPlayer"
        >VS PLAYER</el-button
      >
      <el-button
        type="danger"
        round
        style="width: 100%"
        @click="hanldeVSVsDueler"
        >VS Dueler</el-button
      >
      <p></p>
      <el-button
        type="info"
        round
        style="width: 100%"
        icon="el-icon-s-tools"
        @click="openConfig"
        >CONFIG</el-button
      >
    </div>
    <configCom ref="configCom"></configCom>
    <roomCom ref="roomCom"></roomCom>

    <el-dialog
      title="Waiting for Player"
      :visible.sync="waitingDialogVisible"
      width="400px"
      center
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
    >
      <div style="text-align: center; padding: 20px 0">
        <i
          class="el-icon-loading"
          style="font-size: 48px; color: #409eff; margin-bottom: 20px"
        ></i>
        <p style="font-size: 16px; color: #606266; margin: 0">
          Waiting for another player...
        </p>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="cancelGame">Cancel</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
/* eslint-disable */
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { FontLoader } from "three/examples/jsm/loaders/FontLoader.js";
import { TextGeometry } from "three/examples/jsm/geometries/TextGeometry.js";
import {
  createGameAPI,
  cancelGameAPI,
  getGameStatus,
  createRaceGameVsDuelerAPI,
  createVSGameVsDuelerAPI,
} from "./service.js";
import { randomString } from "@/utils/globalFN";
export default {
  name: "home",
  components: {
    configCom: () => import("@/views/config/edit.vue"),
    roomCom: () => import("./room.vue"),
  },
  data() {
    return {
      userid: "",
      camera: null,
      scene: null,
      renderer: null,
      plane: null,
      pointer: null,
      raycaster: null,
      isShiftDown: false,
      cubeGeo: null,
      cubeMaterial: null,
      objects: [],
      eventListeners: {},
      controls: null,
      animationId: null,
      gridSize: 50,
      gridRange: 10,
      font: null,
      blockIndex: 0,
      selectedBlock: null,
      previewBlock: null,
      isDragging: false,
      waitingDialogVisible: false,
      currentGameId: null,
      timer: null,
      targetHost: null,
      targetParticipant: null,
    };
  },

  mounted() {
    this.init();
    let blocksamount = localStorage.getItem("blocksamount");
    if (!blocksamount) {
      blocksamount = 3;
      localStorage.setItem("blocksamount", blocksamount);
    }
    let userid = localStorage.getItem("userid");
    if (!userid) {
      userid = randomString(16);
      this.userid = userid;
    }
  },

  beforeDestroy() {
    Object.values(this.eventListeners).forEach(({ target, type, listener }) => {
      target.removeEventListener(type, listener);
    });

    if (this.controls) {
      this.controls.dispose();
    }

    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }

    if (this.renderer) {
      this.renderer.dispose();
    }
  },

  methods: {
    loopStatus() {
      this.timer = setInterval(() => {
        getGameStatus({ gameid: this.currentGameId }).then((res) => {
          if (res.data.status === "joined") {
            clearInterval(this.timer);
            let blocksamount = localStorage.getItem("blocksamount");
            let storedName = localStorage.getItem("playerName");
            this.$router.push({
              path: "/racevsplayer",
              query: {
                gameId: this.currentGameId,
                host: JSON.stringify({
                  name: storedName,
                  blocksamount: blocksamount,
                }),
                participants: JSON.stringify(res.data.participants),
                type: "host",
                target: res.data.target,
              },
            });
          }
        });
      }, 3000);
    },
    handleVsDueler() {
      createRaceGameVsDuelerAPI({
        name: localStorage.getItem("playerName"),
        blocksamount: localStorage.getItem("blocksamount"),
      }).then((res) => {
        this.$router.push({
          path: "/racevsdueler",
          query: {
            gameId: res.data.game_id,
            host: JSON.stringify({
              name: res.data.creator,
              blocksamount: res.data.blocksamount,
            }),
            target: res.data.target,
          },
        });
      });
    },
    hanldeVSVsDueler() {
      createVSGameVsDuelerAPI({
        name: localStorage.getItem("playerName"),
        blocksamount: localStorage.getItem("blocksamount"),
      }).then((res) => {
        this.$router.push({
          path: "/vsvsdueler",
          query: {
            gameId: res.data.game_id,
            host: JSON.stringify({
              name: res.data.creator,
              blocksamount: res.data.blocksamount,
            }),
            target: res.data.target,
          },
        });
      });
    },
    handleVsPlayer() {
      this.$confirm("Choose game mode", "VS Player", {
        distinguishCancelAndClose: true,
        confirmButtonText: "Host a Game",
        cancelButtonText: "Join a Game",
        type: "info",
      })
        .then(() => {
          // User chose to host a game
          this.hostGame();
        })
        .catch((action) => {
          if (action === "cancel") {
            // User chose to join a game
            this.joinGame();
          }
          // If action === 'close', user closed dialog, do nothing
        });
    },

    async hostGame() {
      // Get player name from localStorage or prompt
      let playerName = localStorage.getItem("playerName");
      if (!playerName) {
        const result = await this.$prompt("Enter player name", "Host Game", {
          confirmButtonText: "OK",
          cancelButtonText: "Cancel",
        });
        playerName = result.value.trim();
        if (!playerName) {
          this.$message.error("Name cannot be empty");
          return;
        }
        localStorage.setItem("playerName", playerName);
      }

      let blocksamount = localStorage.getItem("blocksamount");

      // Call create game API
      createGameAPI({
        name: playerName,
        blocksamount: blocksamount,
        mode: "race",
      })
        .then((response) => {
          this.$message.success("Game created successfully!");
          // Save the game ID and display the wait dialog
          this.currentGameId = response.data.game_id;

          this.waitingDialogVisible = true;
          this.loopStatus();
          // this.$router.push({ path: "/racevsplayer" });
          // this.$router.push({ path: '/game-room', query: { gameId: response.data.game_id } });
        })
        .catch((error) => {
          this.$message.error(
            "Failed to create game: " + (error.message || error)
          );
        });
    },

    joinGame() {
      // TODO: Implement join game logic
      this.$refs.roomCom.open(this.userid);
    },

    cancelGame() {
      if (!this.currentGameId) {
        this.waitingDialogVisible = false;
        return;
      }

      cancelGameAPI({ gameid: this.currentGameId }).then((response) => {
        this.$message.success("Game cancelled successfully!");
        this.waitingDialogVisible = false;
        this.currentGameId = null;
        clearInterval(this.timer);
      });
    },

    // VS Mode - VS Player
    handleVsModeVsPlayer() {
      this.$confirm("Choose game mode", "VS Player (VS Mode)", {
        distinguishCancelAndClose: true,
        confirmButtonText: "Host a Game",
        cancelButtonText: "Join a Game",
        type: "info",
      })
        .then(() => {
          // User chose to host a game
          this.hostVsModeGame();
        })
        .catch((action) => {
          if (action === "cancel") {
            // User chose to join a game
            this.joinVsModeGame();
          }
          // If action === 'close', user closed dialog, do nothing
        });
    },

    async hostVsModeGame() {
      // Get player name from localStorage or prompt
      let playerName = localStorage.getItem("playerName");
      if (!playerName) {
        const result = await this.$prompt("Enter player name", "Host Game", {
          confirmButtonText: "OK",
          cancelButtonText: "Cancel",
        });
        playerName = result.value.trim();
        if (!playerName) {
          this.$message.error("Name cannot be empty");
          return;
        }
        localStorage.setItem("playerName", playerName);
      }

      let blocksamount = localStorage.getItem("blocksamount");

      // Call create game API with vsmode
      createGameAPI({
        name: playerName,
        blocksamount: blocksamount,
        mode: "vsmode", // VS mode
      })
        .then((response) => {
          this.$message.success("VS Mode game created successfully!");

          this.currentGameId = response.data.game_id;
          this.targetHost = response.data.target_host;
          this.targetParticipant = response.data.target_participant;

          this.waitingDialogVisible = true;
          this.loopVsModeStatus();
        })
        .catch((error) => {
          this.$message.error(
            "Failed to create game: " + (error.message || error)
          );
        });
    },

    joinVsModeGame() {
      // Open room component to join VS mode game
      this.$refs.roomCom.open(this.userid, "vsmode");
    },

    loopVsModeStatus() {
      this.timer = setInterval(() => {
        getGameStatus({ gameid: this.currentGameId }).then((res) => {
          if (res.data.status === "joined") {
            clearInterval(this.timer);
            let blocksamount = localStorage.getItem("blocksamount");
            let storedName = localStorage.getItem("playerName");
            this.$router.push({
              path: "/vsvsplayer",
              query: {
                gameId: this.currentGameId,
                host: JSON.stringify({
                  name: storedName,
                  blocksamount: blocksamount,
                }),
                participants: JSON.stringify(res.data.participants),
                type: "host",
                targetHost: res.data.target_host,
                targetParticipant: res.data.target_participant,
              },
            });
          }
        });
      }, 3000);
    },

    openConfig() {
      this.$refs.configCom.open();
    },
    goSingle() {
      // Read player name from localStorage
      let storedName = localStorage.getItem("playerName");
      if (!storedName) {
        this.$prompt("Enter player name", "Player Name", {
          confirmButtonText: "OK",
          cancelButtonText: "Cancel",
        })
          .then(({ value }) => {
            const name = value.trim();
            if (!name) {
              this.$message && this.$message.error("Name cannot be empty");
              return; // Do not navigate
            }
            localStorage.setItem("playerName", name);
            this.$message && this.$message.success("Welcome, " + name);
            this.$router.push({ path: "/home" });
          })
          .catch(() => {
            // Cancelled input, stay on page
            this.$message && this.$message.info("Input cancelled");
          });
      } else {
        // Existing name, navigate directly
        this.$router.push({ path: "/home" });
      }
    },
    init() {
      this.camera = new THREE.PerspectiveCamera(
        45,
        window.innerWidth / window.innerHeight,
        1,
        10000
      );
      this.camera.position.set(500, 800, 1300);
      this.camera.lookAt(0, 0, 0);

      this.scene = new THREE.Scene();
      this.scene.background = new THREE.Color(0xf0f0f0);

      this.cubeGeo = new THREE.BoxGeometry(
        this.gridSize,
        this.gridSize,
        this.gridSize
      );
      this.cubeMaterial = new THREE.MeshLambertMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.95,
      });

      const gridHelper = new THREE.GridHelper(1000, 20);
      this.scene.add(gridHelper);

      this.raycaster = new THREE.Raycaster();
      this.pointer = new THREE.Vector2();

      const geometry = new THREE.PlaneGeometry(1000, 1000);
      geometry.rotateX(-Math.PI / 2);

      this.plane = new THREE.Mesh(
        geometry,
        new THREE.MeshBasicMaterial({ visible: false })
      );
      this.scene.add(this.plane);
      this.objects.push(this.plane);

      const ambientLight = new THREE.AmbientLight(0x606060, 3);
      this.scene.add(ambientLight);

      const directionalLight = new THREE.DirectionalLight(0xffffff, 3);
      directionalLight.position.set(1, 0.75, 0.5).normalize();
      this.scene.add(directionalLight);

      this.renderer = new THREE.WebGLRenderer({ antialias: true });
      this.renderer.setPixelRatio(window.devicePixelRatio);
      this.renderer.setSize(window.innerWidth, window.innerHeight);
      this.$refs.sceneContainer.appendChild(this.renderer.domElement);

      this.controls = new OrbitControls(this.camera, this.renderer.domElement);
      this.controls.enableDamping = true;
      this.controls.dampingFactor = 0.05;
      this.controls.enableZoom = true;
      this.controls.zoomSpeed = 0.5;
      this.controls.enableRotate = true;
      this.controls.rotateSpeed = 0.5;
      this.controls.enablePan = false;

      // this.addEventListener(document, "pointermove", this.onPointerMove);
      // this.addEventListener(document, "pointerdown", this.onPointerDown);
      // this.addEventListener(document, "keydown", this.onDocumentKeyDown);
      // this.addEventListener(document, "keyup", this.onDocumentKeyUp);
      // this.addEventListener(window, "resize", this.onWindowResize);

      // this.addEventListener(document, "contextmenu", this.onRightClick);
      this.loadFont().then(() => {
        this.generateRandomBlocks(10); // BLOCKWORLD
      });
      this.animate();
    },

    loadFont() {
      return new Promise((resolve) => {
        const loader = new FontLoader();
        loader.load(
          "/fonts/helvetiker_regular.typeface.json",
          (font) => {
            this.font = font;
            resolve();
          },
          undefined,
          (error) => {
            console.warn("Font loading failed, using default font", error);
            resolve();
          }
        );
      });
    },

    addTextToAllFaces(cube, letter, color = 0x000000) {
      if (!this.font) return;

      const textGeometry = new TextGeometry(letter, {
        font: this.font,
        size: 20,
        height: 1,
        curveSegments: 12,
        bevelEnabled: false,
      });

      textGeometry.computeBoundingBox();
      const textWidth =
        textGeometry.boundingBox.max.x - textGeometry.boundingBox.min.x;
      const textHeight =
        textGeometry.boundingBox.max.y - textGeometry.boundingBox.min.y;

      const textMaterial = new THREE.MeshLambertMaterial({ color: color });

      const faces = [
        {
          position: [0, 0, this.gridSize / 2 + 1],
          rotation: [0, 0, 0],
          offset: [-textWidth / 2, -textHeight / 2, 0],
        },
      ];

      faces.forEach((face) => {
        const textMesh = new THREE.Mesh(
          textGeometry.clone(),
          textMaterial.clone()
        );
        textMesh.position.set(...face.position);
        textMesh.rotation.set(...face.rotation);
        textMesh.position.x += face.offset[0];
        textMesh.position.y += face.offset[1];
        textMesh.position.z += face.offset[2];
        textMesh.scale.set(1, 1, 0.005);
        cube.add(textMesh);
      });
    },

    generateRandomBlocks(count) {
      const text = "BLOCKWORLD";
      const textLength = Math.min(count, text.length);

      for (let i = 0; i < textLength; i++) {
        const x = (i - textLength / 2) * this.gridSize + this.gridSize / 2;
        const z = this.gridSize / 2;
        const y = this.gridSize / 2;

        const voxel = new THREE.Mesh(this.cubeGeo, this.cubeMaterial.clone());
        voxel.position.set(x, y, z);
        this.addBlockBorder(voxel);

        const letter = text[i];

        const randomColor = Math.floor(Math.random() * 0xffffff);
        this.addTextToAllFaces(voxel, letter, randomColor);

        this.scene.add(voxel);
        this.objects.push(voxel);
      }
    },

    addBlockBorder(block) {
      block.children = block.children.filter(
        (child) => !(child instanceof THREE.LineSegments)
      );
      const edges = new THREE.EdgesGeometry(this.cubeGeo);
      const lineMaterial = new THREE.LineBasicMaterial({
        color: 0x000000,
        linewidth: 1,
      });
      const wireframe = new THREE.LineSegments(edges, lineMaterial);
      block.add(wireframe);
    },

    addEventListener(target, type, listener) {
      const boundListener = listener.bind(this);
      target.addEventListener(type, boundListener);
      this.eventListeners[`${target}_${type}`] = {
        target,
        type,
        listener: boundListener,
      };
    },

    onWindowResize() {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    },

    getGridAlignedPosition(position) {
      const halfSize = this.gridSize / 2;
      const x =
        Math.round(position.x / this.gridSize) * this.gridSize + halfSize;
      const z =
        Math.round(position.z / this.gridSize) * this.gridSize + halfSize;

      let y = halfSize;

      const positionKey = `${Math.round(
        (x - halfSize) / this.gridSize
      )},${Math.round((z - halfSize) / this.gridSize)}`;
      let maxY = 0;

      this.objects.forEach((obj) => {
        if (
          obj !== this.plane &&
          obj !== this.previewBlock &&
          obj !== this.selectedBlock
        ) {
          const objXKey = Math.round(
            (obj.position.x - halfSize) / this.gridSize
          );
          const objZKey = Math.round(
            (obj.position.z - halfSize) / this.gridSize
          );
          if (`${objXKey},${objZKey}` === positionKey) {
            if (obj.position.y > maxY) {
              maxY = obj.position.y;
            }
          }
        }
      });

      if (maxY > 0) {
        y = maxY + this.gridSize;
      }

      return new THREE.Vector3(x, y, z);
    },

    onPointerMove(event) {
      this.pointer.set(
        (event.clientX / window.innerWidth) * 2 - 1,
        -(event.clientY / window.innerHeight) * 2 + 1
      );

      this.raycaster.setFromCamera(this.pointer, this.camera);
      this.resetBlockColors();

      const intersects = this.raycaster.intersectObjects(this.objects, false);

      if (this.selectedBlock && !this.previewBlock) {
        this.previewBlock = this.selectedBlock.clone();

        this.previewBlock.material = new THREE.MeshLambertMaterial({
          color: 0x0000ff,
          transparent: true,
          opacity: 0.5,
        });
        this.addBlockBorder(this.previewBlock);
        this.scene.add(this.previewBlock);
      }

      if (this.previewBlock) {
        if (intersects.length > 0) {
          const intersectPoint = intersects[0].point;
          const alignedPos = this.getGridAlignedPosition(intersectPoint);
          this.previewBlock.position.copy(alignedPos);
        }
      } else if (intersects.length > 0) {
        const intersect = intersects[0];
        if (intersect.object !== this.plane) {
          const currentBlock = intersect.object;
          const blockPosition = currentBlock.position;
          const hasBlockAbove = this.checkBlockAbove(blockPosition);

          if (hasBlockAbove) {
            this.setBlockColor(currentBlock, 0xff0000);
          } else {
            this.setBlockColor(currentBlock, 0x00ff00);
          }
        }
      }
    },

    resetBlockColors() {
      this.objects.forEach((obj) => {
        if (obj !== this.plane && obj.material && obj.material.emissive) {
          obj.material.emissive.setHex(0x000000);
        }
      });
    },

    setBlockColor(block, color) {
      if (block.material && block.material.emissive) {
        block.material.emissive.setHex(color);
      }
    },

    checkBlockAbove(position) {
      const checkY = position.y + this.gridSize;
      return this.objects.some((obj) => {
        if (obj === this.plane) return false;
        const objPos = obj.position;
        return (
          Math.abs(objPos.x - position.x) < 1 &&
          Math.abs(objPos.z - position.z) < 1 &&
          Math.abs(objPos.y - checkY) < 1
        );
      });
    },

    onPointerDown(event) {
      if (event.button !== 0) return;

      this.pointer.set(
        (event.clientX / window.innerWidth) * 2 - 1,
        -(event.clientY / window.innerHeight) * 2 + 1
      );

      this.raycaster.setFromCamera(this.pointer, this.camera);
      const intersects = this.raycaster.intersectObjects(this.objects, false);

      if (this.isShiftDown) {
        if (intersects.length > 0 && intersects[0].object !== this.plane) {
          this.scene.remove(intersects[0].object);
          const index = this.objects.indexOf(intersects[0].object);
          if (index !== -1) {
            this.objects.splice(index, 1);
          }
          if (this.selectedBlock === intersects[0].object) {
            this.selectedBlock = null;

            if (this.previewBlock) {
              this.scene.remove(this.previewBlock);
              this.previewBlock = null;
            }
          }
        }
        return;
      }

      if (this.selectedBlock && this.previewBlock) {
        this.selectedBlock.position.copy(this.previewBlock.position);

        this.scene.remove(this.previewBlock);
        this.previewBlock = null;

        this.resetSelectedBlock();
        return;
      }

      if (intersects.length > 0 && intersects[0].object !== this.plane) {
        const currentBlock = intersects[0].object;
        const blockPosition = currentBlock.position;
        const hasBlockAbove = this.checkBlockAbove(blockPosition);

        this.resetSelectedBlock();

        if (this.previewBlock) {
          this.scene.remove(this.previewBlock);
          this.previewBlock = null;
        }

        if (hasBlockAbove) {
          if (this.$message)
            this.$message.error("cannot select block with another block above");
        } else {
          this.selectBlock(currentBlock);
        }
      }
    },

    onRightClick(event) {
      event.preventDefault();
      this.resetSelectedBlock();
    },

    resetSelectedBlock() {
      if (this.selectedBlock) {
        this.selectedBlock.material = this.cubeMaterial.clone();
        this.addBlockBorder(this.selectedBlock);
        this.selectedBlock = null;
      }

      if (this.previewBlock) {
        this.scene.remove(this.previewBlock);
        this.previewBlock = null;
      }
    },

    selectBlock(block) {
      this.selectedBlock = block;
      const selectedMaterial = new THREE.MeshLambertMaterial({
        color: 0x00ff00,
        transparent: true,
        opacity: 0.5,
      });
      block.material = selectedMaterial;
      this.addBlockBorder(block);
    },

    onDocumentKeyDown(event) {
      if (event.keyCode === 16) {
        this.isShiftDown = true;
      }
    },

    onDocumentKeyUp(event) {
      if (event.keyCode === 16) {
        this.isShiftDown = false;
      }
    },

    animate() {
      this.animationId = requestAnimationFrame(this.animate.bind(this));

      const radius = Math.sqrt(
        Math.pow(this.camera.position.x, 2) +
          Math.pow(this.camera.position.z, 2)
      );
      const rotationSpeed = 0.001;

      const angle = Math.atan2(this.camera.position.z, this.camera.position.x);
      const newAngle = angle + rotationSpeed;

      this.camera.position.x = radius * Math.cos(newAngle);
      this.camera.position.z = radius * Math.sin(newAngle);
      this.camera.lookAt(0, 0, 0);

      this.controls.update();
      this.renderer.render(this.scene, this.camera);
    },
  },
};
</script>

<style lang="scss" scoped>
.bigScene {
  width: 100%;
  height: 100vh;
  position: relative;
  overflow: hidden;
  .menu {
    width: 15.75rem;
    height: auto;
    display: flex;
    flex-direction: column;
    position: absolute;
    left: 10%;
    top: 10%;
    border-radius: 0.625rem;
    background-color: rgba(255, 255, 255, 0.8);
    box-shadow: 0 0 3px black;
    padding: 1rem;
    justify-content: center;
    align-items: center;
    p {
      font-weight: bold;
    }
    .logo {
      width: 6.25rem;
      height: 6.25rem;
      background-size: contain;
      background-repeat: no-repeat;
      background-position: center center;
      background-image: url("@/assets/images/logo.png");
    }
  }
}
</style>
