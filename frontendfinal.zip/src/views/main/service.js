import request from "@/utils/request";

export function createGameAPI(data) {
  return request({
    url: "/create-game",
    method: "post",
    data,
  });
}
export function createRaceGameVsDuelerAPI(data) {
  return request({
    url: "/create-dueler-game",
    method: "post",
    data,
  });
}
export function createVSGameVsDuelerAPI(data) {
  return request({
    url: "/create-vsai-game",
    method: "post",
    data,
  });
}
export function getHallAPI(data) {
  return request({
    url: "/game-hall",
    method: "get",
    data,
  });
}

export function cancelGameAPI(data) {
  return request({
    url: "/cancel-game",
    method: "post",
    data,
  });
}
export function joinGameAPI(data) {
  return request({
    url: "/join-game",
    method: "post",
    data,
  });
}
export function getGameStatus(params) {
  return request({
    url: "/game-status",
    method: "get",
    params: params,
  });
}
