import request from "@/utils/request";

export function setPostionstoBackEnd(data) {
  return request({
    url: "/set-vsplayer-position",
    method: "post",
    data,
  });
}
export function getPostionsfromBackEnd(params) {
  return request({
    url: "/get-vsplayer-block-position",
    method: "get",
    params: params,
  });
}

export function initPos(params) {
  return request({
    url: "/init-vsplayer-position",
    method: "get",
    params: params,
  });
}

export function cancel(data) {
  return request({
    url: "/cancel-game",
    method: "post",
    data,
  });
}
