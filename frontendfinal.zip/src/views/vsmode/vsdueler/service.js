import request from "@/utils/request";

export function setPostionstoBackEnd(data) {
  return request({
    url: "/set-vsai-block-position",
    method: "post",
    data,
  });
}
export function getPostionsfromBackEnd(params) {
  return request({
    url: "/get-vsai-block-position",
    method: "get",
    params: params,
  });
}

export function getNextMove(data) {
  return request({
    url: "/get-dueler-next-move",
    method: "post",
    data,
  });
}

export function initPos(params) {
  return request({
    url: "/init-vsai-position",
    method: "get",
    params: params,
  });
}

export function cancel(data) {
  return request({
    url: "/cancel-game",
    method: "post",
    data,
  });
}
