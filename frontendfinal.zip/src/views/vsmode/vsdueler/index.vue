<template>
  <div class="bigSceneHolder">
    <div class="control">
      <el-dropdown trigger="click" @command="handleCommand">
        <el-button icon="el-icon-s-tools" circle></el-button>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="gohome">Gohome</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
    <!-- <div id="info">
      <a href="https://threejs.org" target="_blank" rel="noopener">three.js</a>
      - voxel painter - webgl<br />
      <strong>click</strong>: select voxel, <strong>shift + click</strong>:
      remove voxel<br />
      <strong>right click</strong>: deselect all, <strong>mouse drag</strong>:
      rotate view, <strong>mouse wheel</strong>: zoom<br />
      <strong>select + drag + click</strong>: move voxel
    </div> -->

    <div class="playground host">
      <iframe
        width="100%"
        height="100%"
        frameborder="0"
        scrolling="false"
        :src="src1"
      ></iframe>
    </div>

    <Confetti ref="confetti" />
  </div>
</template>

<script>
import { cancel } from "./service";
import Confetti from "@/components/Confetti/index.vue";
/* eslint-disable */
export default {
  name: "home",
  components: {
    Confetti,
  },
  data() {
    return {
      type: "",
      src1: "",
      src2: "",
    };
  },

  mounted() {
    let type = this.$route.query.type;
    this.type = type;

    const fullUrl = window.location.href;

    if (fullUrl.includes("?")) {
      const queryString = fullUrl.split("?")[1];
      let src1 = "#/oneplayervsduler?" + queryString;

      src1 += "&type=player";

      this.src1 = src1;
    }

    window.addEventListener("message", this.handleMessage);
  },

  beforeDestroy() {
    window.removeEventListener("message", this.handleMessage);
  },

  methods: {
    handleCommand(command) {
      if (command === "gohome") {
        cancel({
          gameid: this.$route.query.gameId,
        }).then(() => {
          this.$router.push("/main");
        });
      }
    },

    handleMessage(event) {
      if (event.data && event.data.type === "showWinDialog") {
        this.showWinDialog(event.data.message);
      }
    },

    showWinDialog(txt) {
      this.$refs.confetti.fire();
      this.$alert(txt, "Notice", {
        confirmButtonText: "OK",
        callback: () => {
          cancel({
            gameid: this.$route.query.gameId,
          }).then(() => {
            this.$router.push("/main");
          });
        },
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.bigSceneHolder {
  width: 100%;
  height: 100vh;
  position: relative;
  overflow: hidden;
  .playground {
    width: calc(100%);
    height: calc(100%);

    position: relative;
  }
}
.control {
  position: absolute;
  width: auto;
  display: flex;
  align-items: center;
  font-size: 1rem;
  top: 0.2rem;
  right: 1rem;
  z-index: 100;
}
</style>
