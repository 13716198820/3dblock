<template>
  <div class="app-wrapper" :class="classObj">
    <app-main></app-main>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import AppMain from "./components/AppMain.vue";

export default {
  name: "LayoutView",
  components: {
    AppMain,
  },
  data() {
    return {};
  },
  computed: {
    ...mapGetters({
      sidebar: "sidebar",
      settingOptions: "settingOptions",
    }),
    classObj() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened,
        closeSidebar: this.sidebar.closed,
        uncloseSidebar: !this.sidebar.closed,
      };
    },
    showSettings() {
      return this.settingOptions.showSettings;
    },
    sidebarMenu() {
      return this.settingOptions.sidebarMenu;
    },
    hasHeader() {
      return this.settingOptions.hasHeader;
    },
    fullHeader() {
      return this.settingOptions.fullHeader;
    },
    fixedHeader() {
      return this.settingOptions.fixedHeader;
    },
  },
  mounted() {},
  methods: {},
};
</script>
<style lang="scss" scoped>
@import "~@/styles/mixin.scss";
@import "~@/styles/variables.module.scss";
.app-wrapper {
  @include clearfix;
  width: 100%;
  height: 100%;
  position: relative;
}
.sidebar-menu-hide {
  margin-left: 0 !important;
}
.fixed-header {
  position: fixed;
  top: 0;
  right: 0;
  z-index: 9;
  width: calc(100% - $sideBarWidth);
  transition: width 0.28s;
}
.full-header {
  padding: 0;
  z-index: 1004;
}
.hideSidebar .fixed-header {
  width: calc(100% - $navbarHeight);
}
</style>
