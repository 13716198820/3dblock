<template>
  <section class="app-main">
    <router-view />
  </section>
</template>
<script>
import { mapGetters } from "vuex";

export default {
  name: "AppMain",
  components: {},
  computed: {
    ...mapGetters({
      settingOptions: "settingOptions",
    }),
    key() {
      return this.$route.path;
    },

    needTagsView() {
      return this.settingOptions.tagsView;
    },
    fixedHeader() {
      return this.settingOptions.fixedHeader;
    },
  },
  data() {
    return {
      currentYear: new Date().getFullYear(),

      isDev: process.env.NODE_ENV === "development",
    };
  },
};
</script>
<style lang="scss" scoped>
@import "~@/styles/variables.module.scss";
$footerHeight: 20px;
.app-main {
  width: 100%;
  min-height: calc(100vh);
  position: relative;
  overflow: hidden;
  background-color: #f0f2f5;
}
.fixed-header + .app-main {
  padding-top: $navbarHeight;
}
.fixed-tags {
  width: calc(100% - $sideBarWidth);
  position: fixed;
  z-index: 1001;
  transition: width 0.28s;
}
.routerView-content {
  height: calc(100vh - $navbarHeight);
  background-color: #edf2f8;
  overflow: hidden;
}
.routerView-content-in {
  height: calc(100% - $footerHeight - 12px);
  width: calc(100% - 20px);
  background-color: #edf2f8;
  border: 1px solid #ebeef5;
  margin: 0 10px;
  margin-top: 12px;
  overflow-x: hidden;
  overflow-y: auto;
}
.fixed-tags + .routerView-content {
  padding: 40px 0px 0px;
}
.footer {
  height: $footerHeight;
  font-size: 12px;
  color: #3c3b3b;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
<style lang="scss">
.routerView-content-in {
  & > div {
    height: 100%;
    display: flex;
    flex-direction: column;
  }
}
</style>
