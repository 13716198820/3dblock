module.exports = {
  title: "Block World",
  logoTitle: "Block World",
};
