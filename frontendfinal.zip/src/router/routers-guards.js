import router from "@/router";

import NProgress from "nprogress";
import "nprogress/nprogress.css";
// import { Message } from "element-ui";

NProgress.configure({ showSpinner: false });

router.afterEach(() => {
  NProgress.done();
});
