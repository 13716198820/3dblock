import Vue from "vue";
import VueRouter from "vue-router";
Vue.use(VueRouter);

/* Layout */
import Layout from "@/layout";

export const constantRoutes = [
  {
    path: "/",
    hidden: true,
    redirect: "/main",
  },
  {
    hidden: true,
    path: "/redirect",
    component: Layout,
    children: [
      {
        path: "/redirect/:path(.*)",
        component: () =>
          import(
            /* webpackChunkName: "constantRoutes" */ "@/views/redirect/index"
          ),
      },
    ],
  },

  {
    path: "/home",
    name: "home",
    hidden: true,
    component: () =>
      import(/* webpackChunkName: "constantRoutes" */ "@/views/home/index.vue"),
  },
  {
    path: "/main",
    name: "main",
    hidden: true,
    component: () =>
      import(/* webpackChunkName: "constantRoutes" */ "@/views/main/index.vue"),
  },

  {
    path: "/racevsplayer",
    name: "racevsplayer",
    hidden: true,
    component: () =>
      import(
        /* webpackChunkName: "constantRoutes" */ "@/views/racemode/vsplayer/index.vue"
      ),
  },
  {
    path: "/racevsdueler",
    name: "racevsdueler",
    hidden: true,
    component: () =>
      import(
        /* webpackChunkName: "constantRoutes" */ "@/views/racemode/vsdueler/index.vue"
      ),
  },
  {
    path: "/vsvsdueler",
    name: "vsvsdueler",
    hidden: true,
    component: () =>
      import(
        /* webpackChunkName: "constantRoutes" */ "@/views/vsmode/vsdueler/index.vue"
      ),
  },
  {
    path: "/vsvsplayer",
    name: "vsvsplayer",
    hidden: true,
    component: () =>
      import(
        /* webpackChunkName: "constantRoutes" */ "@/views/vsmode/vsplayer/index.vue"
      ),
  },
  {
    path: "/oneplayer",
    name: "oneplayer",
    hidden: true,
    component: () =>
      import(
        /* webpackChunkName: "constantRoutes" */ "@/views/racemode/vsplayer/onePlayer.vue"
      ),
  },
  {
    path: "/vsplayer",
    name: "vsplayer",
    hidden: true,
    component: () =>
      import(
        /* webpackChunkName: "constantRoutes" */ "@/views/vsmode/vsplayer/onePlayer.vue"
      ),
  },
  {
    path: "/oneplayerraceduler",
    name: "oneplayerraceduler",
    hidden: true,
    component: () =>
      import(
        /* webpackChunkName: "constantRoutes" */ "@/views/racemode/vsdueler/onePlayer.vue"
      ),
  },
  {
    path: "/oneplayervsduler",
    name: "oneplayervsduler",
    hidden: true,
    component: () =>
      import(
        /* webpackChunkName: "constantRoutes" */ "@/views/vsmode/vsdueler/onePlayer.vue"
      ),
  },
  {
    path: "/oneplayervsplayer",
    name: "oneplayervsplayer",
    hidden: true,
    component: () =>
      import(
        /* webpackChunkName: "constantRoutes" */ "@/views/vsmode/vsplayer/onePlayer.vue"
      ),
  },

  {
    path: "/404",
    name: "404",
    hidden: true,
    component: () =>
      import(/* webpackChunkName: "constantRoutes" */ "@/views/error/404.vue"),
  },
  {
    hidden: true,
    path: "/403",
    name: "error403",
    component: () =>
      import(/* webpackChunkName: "constantRoutes" */ "@/views/error/403.vue"),
  },
];

const createRouter = () =>
  new VueRouter({
    mode: "hash",
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRoutes,
  });
const router = createRouter();

const originalPush = VueRouter.prototype.push;

VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch((err) => err);
};

export default router;
